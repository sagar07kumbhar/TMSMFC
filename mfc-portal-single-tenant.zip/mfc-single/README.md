# 🚛 MFC Portal — Single Tenant v1.0
### Transport Management System for One Business Owner

---

## 📦 Project Structure

```
mfc-single/
├── backend/
│   ├── config/db.js
│   ├── middleware/auth.js
│   ├── routes/
│   │   ├── auth.js         login, me, change-password
│   │   ├── settings.js     business settings
│   │   ├── trips.js        owned + brokerage trips
│   │   ├── trucks.js       fleet management
│   │   ├── drivers.js      driver management
│   │   ├── tripExpenses.js expenses per trip
│   │   ├── consignees.js   customers/clients
│   │   ├── invoices.js     invoice management
│   │   ├── maintenance.js  service/fuel/repair logs
│   │   ├── tyres.js        per-position tyre tracking
│   │   ├── dashboard.js    stats & charts
│   │   └── ai.js           Claude AI assistant
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── context/AuthContext.jsx
│   │   ├── components/Layout.jsx   sidebar + appbar
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── Dashboard.jsx       charts + KPIs
│   │   │   ├── Trips.jsx           owned + brokerage
│   │   │   ├── Fleet.jsx           trucks + loan tracker
│   │   │   ├── Drivers.jsx         doc expiry alerts
│   │   │   ├── Consignees.jsx
│   │   │   ├── Invoices.jsx
│   │   │   ├── Maintenance.jsx     tabbed logs
│   │   │   ├── AIAssistant.jsx     Claude chat
│   │   │   └── Settings.jsx        owner details
│   │   ├── utils/api.js
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── database/
    └── schema.sql          10 tables, no company_id
```

---

## 🔧 TECH STACK

### Backend
| Package | Version | What it does |
|---------|---------|-------------|
| Node.js | 18+ | Runtime — runs JavaScript on server |
| Express | 4.18 | Web framework — creates API routes |
| mysql2 | 3.9 | MySQL driver — talks to database |
| bcryptjs | 2.4 | Password hashing — secure login |
| jsonwebtoken | 9.0 | JWT tokens — session management |
| dotenv | 16.4 | Loads .env config file |
| @anthropic-ai/sdk | 0.20 | Claude AI API |
| nodemon | 3.1 | Auto-restart server on file save (dev only) |

### Frontend
| Package | Version | What it does |
|---------|---------|-------------|
| React | 18.3 | UI framework |
| Vite | 5.2 | Build tool + dev server |
| @mui/material | 5.15 | UI components (buttons, tables, dialogs) |
| @mui/icons-material | 5.15 | Icons |
| @emotion/react | 11.11 | CSS-in-JS (required by MUI) |
| @emotion/styled | 11.11 | Styled components (required by MUI) |
| recharts | 2.12 | Charts (bar chart on dashboard) |
| axios | 1.7 | HTTP client — calls the API |
| react-router-dom | 6.23 | Page routing / navigation |

---

## 🖥️ LOCAL SETUP — STEP BY STEP

### Prerequisites — Install These First

**1. Node.js (v18 or higher)**
- Download: https://nodejs.org/en/download
- Choose "LTS" version
- After install, verify: open terminal → `node --version` → should show v18.x.x

**2. MySQL (v8.0)**
- Download: https://dev.mysql.com/downloads/mysql/
- During install, set a root password — remember it!
- After install, verify: `mysql --version`

---

### STEP 1 — Setup the Database

**Option A — Command Line:**
```bash
mysql -u root -p
# Enter your password when prompted
# Then run:
source /path/to/mfc-single/database/schema.sql
# Or:
exit
mysql -u root -p < database/schema.sql
```

**Option B — MySQL Workbench (easier):**
1. Open MySQL Workbench
2. Connect to localhost
3. File → Open SQL Script → select `database/schema.sql`
4. Click the lightning bolt ⚡ to run it
5. You'll see `mfc_db` appear in the left panel

**Option C — TablePlus / DBeaver:**
1. Connect to localhost with your root password
2. Open a new query tab
3. Paste the contents of `schema.sql` and run

---

### STEP 2 — Configure Backend

```bash
cd backend
cp .env.example .env
```

Open `.env` in any text editor (Notepad, VS Code) and fill in:

```env
DB_PASSWORD=your_mysql_root_password   ← the one you set during MySQL install
JWT_SECRET=any_random_long_string_here ← type anything, e.g. mfc2024secretkey99
ANTHROPIC_API_KEY=sk-ant-...           ← optional, only for AI chat feature
```

---

### STEP 3 — Install & Start Backend

```bash
cd backend
npm install
npm run dev
```

✅ **You should see:**
```
✅ MySQL connected successfully
🚛 MFC Portal running on http://localhost:5000
🔍 Health: http://localhost:5000/api/health
```

Test: Open http://localhost:5000/api/health in your browser — should show `{"status":"ok"}`

---

### STEP 4 — Install & Start Frontend

Open a **new terminal** (keep backend running):

```bash
cd frontend
npm install
npm run dev
```

✅ **You should see:**
```
  VITE v5.x  ready in 500ms
  ➜  Local:   http://localhost:5173/
```

---

### STEP 5 — Open the App

Go to: **http://localhost:5173**

**Default Login:**
- Email: `admin@mfc.com`
- Password: `admin123`

---

## 🗄️ MYSQL UI OPTIONS

Here are the best options to view and manage your MySQL database visually:

### 1. MySQL Workbench (Free — Official)
- **Download:** https://dev.mysql.com/downloads/workbench/
- **Best for:** Full database management, running queries, schema design
- **Made by:** MySQL/Oracle (official tool)
- ✅ Free, trusted, works on Windows/Mac/Linux

### 2. TablePlus (Recommended — Paid, free tier available)
- **Download:** https://tableplus.com
- **Best for:** Clean modern UI, fast, easy to use
- **Free tier:** Limited tabs but fully functional
- ✅ Best looking UI, great for day-to-day use

### 3. DBeaver (Free — Most popular)
- **Download:** https://dbeaver.io/download/
- **Best for:** Works with MySQL, PostgreSQL, SQLite, and 100+ databases
- ✅ Free, open source, very powerful

### 4. phpMyAdmin (Free — Web-based)
- **Best for:** If you're on a server (like Hostinger)
- Install via: `sudo apt install phpmyadmin` on Ubuntu
- Access: http://localhost/phpmyadmin
- ✅ Already familiar if you've used web hosting before

### 5. VS Code Extension: MySQL (Free)
- **Install:** Search "MySQL" by weijan chen in VS Code extensions
- **Best for:** If you want everything in one editor
- ✅ No separate app needed

**My recommendation for you:** Use **TablePlus** — it's the cleanest and most intuitive. The free version is enough for this project.

---

## 🔑 Login Credentials

After running schema.sql:
- **Email:** admin@mfc.com
- **Password:** admin123

To change the password, go to the Settings page → change password option, or update the hash in MySQL.

---

## 🚀 Deploying to a New Client

For each new client, the steps are:
1. Set up their VPS (Hostinger KVM)
2. Install Node.js + MySQL on the server
3. Upload this folder via FileZilla/SCP
4. Run `schema.sql` once — creates fresh empty database
5. Edit `.env` with their MySQL password
6. Run `npm install` in both backend and frontend folders
7. Run `npm run build` in frontend
8. Set up PM2 + Nginx (see below)
9. Update `database/schema.sql` seed data with their business details

---

## 🌐 VPS Deployment (Hostinger)

```bash
# 1. Upload files
scp -r mfc-single/ root@YOUR_VPS_IP:/var/www/

# 2. SSH into server
ssh root@YOUR_VPS_IP

# 3. Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 4. Setup database
mysql -u root -p < /var/www/mfc-single/database/schema.sql

# 5. Install backend dependencies
cd /var/www/mfc-single/backend
npm install --production

# 6. Build frontend
cd /var/www/mfc-single/frontend
npm install && npm run build

# 7. Start with PM2
npm install -g pm2
cd /var/www/mfc-single/backend
pm2 start server.js --name mfc-portal
pm2 save && pm2 startup

# 8. Nginx config
nano /etc/nginx/sites-available/mfc
```

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    root /var/www/mfc-single/frontend/dist;
    index index.html;

    location / { try_files $uri $uri/ /index.html; }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/mfc /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# 9. Free SSL
certbot --nginx -d yourdomain.com
```

---

## 💰 SaaS Pricing Model

| Tier | Setup | Monthly | Annual |
|------|-------|---------|--------|
| First 5 clients | ₹18,000 | ₹2,500 | ₹24,000 |
| After 5 clients | ₹25,000 | ₹3,000 | ₹30,000 |

Each client gets: their own installation, their own domain/subdomain, their own database.
