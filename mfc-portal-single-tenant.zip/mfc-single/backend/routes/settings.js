const router = require('express').Router();
const db = require('../config/db');
const { auth, adminOnly } = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
  const [rows] = await db.query('SELECT * FROM settings LIMIT 1');
  res.json(rows[0] || {});
});

router.put('/', auth, adminOnly, async (req, res) => {
  const { business_name, owner_name, gstin, pan, address, city, state, phone, email,
    bank_name, bank_account, bank_ifsc, invoice_prefix, trip_number_prefix,
    driver_pay_per_km, default_commission_percent, gst_default } = req.body;
  try {
    await db.query(`UPDATE settings SET business_name=?, owner_name=?, gstin=?, pan=?,
      address=?, city=?, state=?, phone=?, email=?, bank_name=?, bank_account=?, bank_ifsc=?,
      invoice_prefix=?, trip_number_prefix=?, driver_pay_per_km=?, default_commission_percent=?, gst_default=?
      WHERE id = 1`,
      [business_name, owner_name, gstin, pan, address, city, state, phone, email,
       bank_name, bank_account, bank_ifsc, invoice_prefix, trip_number_prefix,
       driver_pay_per_km, default_commission_percent, gst_default]);
    res.json({ message: 'Settings saved' });
  } catch { res.status(500).json({ error: 'Failed to save settings' }); }
});

module.exports = router;
