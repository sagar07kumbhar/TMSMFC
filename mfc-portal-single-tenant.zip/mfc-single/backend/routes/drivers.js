const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/', async (req, res) => {
  const [r] = await db.query('SELECT * FROM drivers WHERE is_active=1 ORDER BY name');
  res.json(r);
});
router.get('/:id', async (req, res) => {
  const [r] = await db.query('SELECT * FROM drivers WHERE id=?', [req.params.id]);
  r.length ? res.json(r[0]) : res.status(404).json({ error: 'Not found' });
});
router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    'INSERT INTO drivers (name,phone,license_number,license_expiry,badge_expiry,address) VALUES (?,?,?,?,?,?)',
    [d.name, d.phone, d.license_number, d.license_expiry||null, d.badge_expiry||null, d.address]);
  res.status(201).json({ id: r.insertId });
});
router.put('/:id', async (req, res) => {
  const d = req.body;
  await db.query(
    'UPDATE drivers SET name=?,phone=?,license_number=?,license_expiry=?,badge_expiry=?,address=? WHERE id=?',
    [d.name,d.phone,d.license_number,d.license_expiry||null,d.badge_expiry||null,d.address,req.params.id]);
  res.json({ message: 'Updated' });
});
router.delete('/:id', async (req, res) => {
  await db.query('UPDATE drivers SET is_active=0 WHERE id=?', [req.params.id]);
  res.json({ message: 'Deactivated' });
});
module.exports = router;
