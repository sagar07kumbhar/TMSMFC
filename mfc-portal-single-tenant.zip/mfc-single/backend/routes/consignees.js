const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/', async (req, res) => {
  const [r] = await db.query('SELECT * FROM consignees WHERE is_active=1 ORDER BY name');
  res.json(r);
});
router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    'INSERT INTO consignees (name,gstin,address,city,state,phone,email) VALUES (?,?,?,?,?,?,?)',
    [d.name,d.gstin,d.address,d.city,d.state,d.phone,d.email]);
  res.status(201).json({ id: r.insertId });
});
router.put('/:id', async (req, res) => {
  const d = req.body;
  await db.query(
    'UPDATE consignees SET name=?,gstin=?,address=?,city=?,state=?,phone=?,email=? WHERE id=?',
    [d.name,d.gstin,d.address,d.city,d.state,d.phone,d.email,req.params.id]);
  res.json({ message: 'Updated' });
});
router.delete('/:id', async (req, res) => {
  await db.query('UPDATE consignees SET is_active=0 WHERE id=?', [req.params.id]);
  res.json({ message: 'Deleted' });
});
module.exports = router;
