const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/truck/:truckId', async (req, res) => {
  const [r] = await db.query('SELECT * FROM tyre_logs WHERE truck_id=? ORDER BY event_date DESC', [req.params.truckId]);
  res.json(r);
});

router.get('/truck/:truckId/current', async (req, res) => {
  const [r] = await db.query(`
    SELECT t1.* FROM tyre_logs t1
    INNER JOIN (
      SELECT position, MAX(event_date) AS latest FROM tyre_logs WHERE truck_id=? GROUP BY position
    ) t2 ON t1.position=t2.position AND t1.event_date=t2.latest
    WHERE t1.truck_id=? ORDER BY t1.position`, [req.params.truckId, req.params.truckId]);
  res.json(r);
});

router.get('/analytics/brands', async (req, res) => {
  const [r] = await db.query(`
    SELECT tyre_brand, COUNT(*) AS total_tyres, AVG(km_run) AS avg_km,
      AVG(purchase_cost) AS avg_cost, SUM(purchase_cost) AS total_cost,
      CASE WHEN AVG(km_run)>0 THEN AVG(purchase_cost)/AVG(km_run) ELSE 0 END AS cost_per_km
    FROM tyre_logs WHERE km_run>0 AND tyre_brand IS NOT NULL
    GROUP BY tyre_brand ORDER BY avg_km DESC`);
  res.json(r);
});

router.post('/', async (req, res) => {
  const d = req.body;
  let km_run = 0;
  if (d.event_type === 'removal') {
    const [prev] = await db.query(
      `SELECT odometer_reading FROM tyre_logs WHERE truck_id=? AND position=? AND event_type='new_fit' ORDER BY event_date DESC LIMIT 1`,
      [d.truck_id, d.position]);
    if (prev.length) km_run = (+d.odometer_reading||0) - (prev[0].odometer_reading||0);
  }
  const [r] = await db.query(
    `INSERT INTO tyre_logs (truck_id,position,event_type,event_date,odometer_reading,
      tyre_brand,tyre_serial,tyre_size,purchase_cost,km_run,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [d.truck_id,d.position,d.event_type,d.event_date,d.odometer_reading||0,
     d.tyre_brand,d.tyre_serial,d.tyre_size,d.purchase_cost||0,km_run,d.notes]);
  res.status(201).json({ id: r.insertId, km_run });
});

router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM tyre_logs WHERE id=?', [req.params.id]);
  res.json({ message: 'Deleted' });
});

module.exports = router;
