const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/', async (req, res) => {
  const { truck_id, log_type, from_date, to_date } = req.query;
  let where = 'WHERE 1=1'; const p = [];
  if (truck_id)  { where += ' AND m.truck_id=?';       p.push(truck_id); }
  if (log_type)  { where += ' AND m.log_type=?';       p.push(log_type); }
  if (from_date) { where += ' AND m.service_date>=?';  p.push(from_date); }
  if (to_date)   { where += ' AND m.service_date<=?';  p.push(to_date); }
  const [r] = await db.query(
    `SELECT m.*, t.truck_number FROM maintenance_logs m JOIN trucks t ON m.truck_id=t.id ${where} ORDER BY m.service_date DESC`, p);
  res.json(r);
});

router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    `INSERT INTO maintenance_logs (truck_id,log_type,description,cost,odometer_reading,
      service_date,next_service_date,vendor_name,doc_type,doc_expiry,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [d.truck_id,d.log_type,d.description,d.cost||0,d.odometer_reading||null,
     d.service_date,d.next_service_date||null,d.vendor_name,d.doc_type,d.doc_expiry||null,d.notes]);
  res.status(201).json({ id: r.insertId });
});

router.put('/:id', async (req, res) => {
  const d = req.body;
  await db.query(
    `UPDATE maintenance_logs SET log_type=?,description=?,cost=?,odometer_reading=?,
      service_date=?,next_service_date=?,vendor_name=?,notes=? WHERE id=?`,
    [d.log_type,d.description,d.cost||0,d.odometer_reading||null,
     d.service_date,d.next_service_date||null,d.vendor_name,d.notes,req.params.id]);
  res.json({ message: 'Updated' });
});

router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM maintenance_logs WHERE id=?', [req.params.id]);
  res.json({ message: 'Deleted' });
});

router.get('/summary/:truckId', async (req, res) => {
  const [r] = await db.query(
    `SELECT DATE_FORMAT(service_date,'%Y-%m') AS month, log_type, SUM(cost) AS total
     FROM maintenance_logs WHERE truck_id=?
     GROUP BY month, log_type ORDER BY month DESC LIMIT 24`, [req.params.truckId]);
  res.json(r);
});

module.exports = router;
