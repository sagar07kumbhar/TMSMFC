const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.post('/chat', async (req, res) => {
  const { message, history = [] } = req.body;
  if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY.startsWith('sk-ant-your')) {
    return res.status(503).json({ error: 'AI not configured. Add ANTHROPIC_API_KEY to .env file.' });
  }
  try {
    const Anthropic = require('@anthropic-ai/sdk');
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const [[rev]]    = await db.query(`SELECT COALESCE(SUM(freight_amount),0) AS r FROM trips WHERE MONTH(trip_date)=MONTH(CURDATE()) AND status!='cancelled'`);
    const [[trucks]] = await db.query(`SELECT COUNT(*) AS c FROM trucks WHERE is_active=1`);
    const [[drivers]]= await db.query(`SELECT COUNT(*) AS c FROM drivers WHERE is_active=1`);
    const [settings] = await db.query('SELECT business_name FROM settings LIMIT 1');
    const biz = settings[0]?.business_name || 'this transport company';

    const response = await client.messages.create({
      model: 'claude-sonnet-4-6', max_tokens: 1024,
      system: `You are a smart business assistant for ${biz}, an Indian road transport company.
Current snapshot: This month revenue ₹${rev.r}, Active trucks: ${trucks.c}, Active drivers: ${drivers.c}.
Help with: trip analysis, route profitability, expense patterns, fleet health, invoices, business advice.
Keep responses concise and practical. Use ₹ for currency. Use Indian transport terms (LR, freight, consignee, kata, etc.).`,
      messages: [...history.slice(-10).map(h => ({ role: h.role, content: h.content })), { role: 'user', content: message }]
    });
    res.json({ reply: response.content[0].text });
  } catch (err) { console.error(err); res.status(500).json({ error: 'AI unavailable' }); }
});

module.exports = router;
