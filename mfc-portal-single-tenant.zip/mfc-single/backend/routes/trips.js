const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');

router.use(auth);

// GET /api/trips
router.get('/', async (req, res) => {
  const { trip_type, status, from_date, to_date, page = 1, limit = 20 } = req.query;
  let where = 'WHERE 1=1';
  const params = [];

  if (trip_type) { where += ' AND t.trip_type = ?'; params.push(trip_type); }
  if (status)    { where += ' AND t.status = ?';    params.push(status); }
  if (from_date) { where += ' AND t.trip_date >= ?'; params.push(from_date); }
  if (to_date)   { where += ' AND t.trip_date <= ?'; params.push(to_date); }

  const offset = (page - 1) * limit;
  try {
    const [rows] = await db.query(`
      SELECT t.*,
        tr.truck_number, d.name AS driver_name, c.name AS consignee_name,
        COALESCE((SELECT SUM(amount) FROM trip_expenses WHERE trip_id = t.id), 0) AS total_expenses
      FROM trips t
      LEFT JOIN trucks tr ON t.truck_id = tr.id
      LEFT JOIN drivers d  ON t.driver_id = d.id
      LEFT JOIN consignees c ON t.consignee_id = c.id
      ${where} ORDER BY t.trip_date DESC LIMIT ? OFFSET ?
    `, [...params, +limit, +offset]);

    const [[{ total }]] = await db.query(`SELECT COUNT(*) AS total FROM trips t ${where}`, params);
    res.json({ data: rows, total, page: +page, pages: Math.ceil(total / limit) });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

// GET /api/trips/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT t.*, tr.truck_number, d.name AS driver_name,
        c.name AS consignee_name, c.gstin AS consignee_gstin, c.city, c.state
      FROM trips t
      LEFT JOIN trucks tr ON t.truck_id = tr.id
      LEFT JOIN drivers d  ON t.driver_id = d.id
      LEFT JOIN consignees c ON t.consignee_id = c.id
      WHERE t.id = ?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    const [expenses] = await db.query('SELECT * FROM trip_expenses WHERE trip_id = ?', [req.params.id]);
    res.json({ ...rows[0], expenses });
  } catch { res.status(500).json({ error: 'Failed' }); }
});

// POST /api/trips
router.post('/', async (req, res) => {
  const d = req.body;
  const commission_amount = d.trip_type === 'brokerage'
    ? ((+d.freight_amount || 0) * (+d.commission_percent || 0) / 100).toFixed(2) : 0;
  const driver_extra_pay = d.trip_type === 'owned' && d.distance_km
    ? (+d.distance_km * 5).toFixed(2) : 0;
  const gst_amount = (+d.freight_amount || 0) * (+d.gst_rate || 0) / 100;

  try {
    const [r] = await db.query(`
      INSERT INTO trips (trip_number, lr_number, trip_date, trip_type,
        truck_id, driver_id,
        broker_owner_name, broker_owner_phone, broker_truck_number, broker_driver_name,
        commission_percent, commission_amount,
        consignee_id, from_location, to_location, distance_km, weight_tons,
        freight_amount, advance_paid,
        detention_charges, kata_charges, loading_charges, unloading_charges,
        gst_type, gst_rate, gst_amount, driver_extra_pay, status, notes)
      VALUES (?,?,?,?, ?,?, ?,?,?,?, ?,?, ?,?,?,?,?, ?,?, ?,?,?,?, ?,?,?,?,?,?)`,
      [d.trip_number, d.lr_number, d.trip_date, d.trip_type || 'owned',
       d.truck_id || null, d.driver_id || null,
       d.broker_owner_name || null, d.broker_owner_phone || null,
       d.broker_truck_number || null, d.broker_driver_name || null,
       d.commission_percent || 0, commission_amount,
       d.consignee_id || null, d.from_location, d.to_location,
       d.distance_km || 0, d.weight_tons || 0,
       d.freight_amount || 0, d.advance_paid || 0,
       d.detention_charges || 0, d.kata_charges || 0,
       d.loading_charges || 0, d.unloading_charges || 0,
       d.gst_type || 'exempt', d.gst_rate || 0, gst_amount, driver_extra_pay,
       d.status || 'planned', d.notes || '']);
    res.status(201).json({ id: r.insertId, message: 'Trip created' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed to create trip' }); }
});

// PUT /api/trips/:id
router.put('/:id', async (req, res) => {
  const d = req.body;
  const commission_amount = d.trip_type === 'brokerage'
    ? ((+d.freight_amount || 0) * (+d.commission_percent || 0) / 100).toFixed(2) : 0;
  const driver_extra_pay = d.trip_type === 'owned' && d.distance_km
    ? (+d.distance_km * 5).toFixed(2) : 0;
  const gst_amount = (+d.freight_amount || 0) * (+d.gst_rate || 0) / 100;

  try {
    await db.query(`
      UPDATE trips SET trip_number=?, lr_number=?, trip_date=?, trip_type=?,
        truck_id=?, driver_id=?,
        broker_owner_name=?, broker_owner_phone=?, broker_truck_number=?, broker_driver_name=?,
        commission_percent=?, commission_amount=?,
        consignee_id=?, from_location=?, to_location=?, distance_km=?, weight_tons=?,
        freight_amount=?, advance_paid=?,
        detention_charges=?, kata_charges=?, loading_charges=?, unloading_charges=?,
        gst_type=?, gst_rate=?, gst_amount=?, driver_extra_pay=?, status=?, notes=?
      WHERE id = ?`,
      [d.trip_number, d.lr_number, d.trip_date, d.trip_type,
       d.truck_id || null, d.driver_id || null,
       d.broker_owner_name || null, d.broker_owner_phone || null,
       d.broker_truck_number || null, d.broker_driver_name || null,
       d.commission_percent || 0, commission_amount,
       d.consignee_id || null, d.from_location, d.to_location,
       d.distance_km || 0, d.weight_tons || 0,
       d.freight_amount || 0, d.advance_paid || 0,
       d.detention_charges || 0, d.kata_charges || 0,
       d.loading_charges || 0, d.unloading_charges || 0,
       d.gst_type || 'exempt', d.gst_rate || 0, gst_amount, driver_extra_pay,
       d.status || 'planned', d.notes || '',
       req.params.id]);
    res.json({ message: 'Trip updated' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

// DELETE /api/trips/:id
router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM trips WHERE id = ?', [req.params.id]);
  res.json({ message: 'Deleted' });
});

module.exports = router;
