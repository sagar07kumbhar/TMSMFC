const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/stats', async (req, res) => {
  const m = req.query.month || new Date().getMonth() + 1;
  const y = req.query.year  || new Date().getFullYear();
  try {
    const [[owned]]    = await db.query(`SELECT COALESCE(SUM(freight_amount+detention_charges+kata_charges),0) AS rev FROM trips WHERE trip_type='owned' AND MONTH(trip_date)=? AND YEAR(trip_date)=? AND status!='cancelled'`, [m,y]);
    const [[brokerage]]= await db.query(`SELECT COALESCE(SUM(commission_amount),0) AS rev FROM trips WHERE trip_type='brokerage' AND MONTH(trip_date)=? AND YEAR(trip_date)=? AND status!='cancelled'`, [m,y]);
    const [[expenses]] = await db.query(`SELECT COALESCE(SUM(te.amount),0) AS total FROM trip_expenses te JOIN trips t ON te.trip_id=t.id WHERE MONTH(t.trip_date)=? AND YEAR(t.trip_date)=?`, [m,y]);
    const [[trips]]    = await db.query(`SELECT COUNT(*) AS total FROM trips WHERE MONTH(trip_date)=? AND YEAR(trip_date)=?`, [m,y]);
    const [[trucks]]   = await db.query(`SELECT COUNT(*) AS total FROM trucks WHERE is_active=1`);
    const [[drivers]]  = await db.query(`SELECT COUNT(*) AS total FROM drivers WHERE is_active=1`);
    const [[pending]]  = await db.query(`SELECT COUNT(*) AS count, COALESCE(SUM(total_amount-amount_paid),0) AS amount FROM invoices WHERE payment_status!='paid'`);
    const [[expiring]] = await db.query(`SELECT COUNT(*) AS count FROM (
      SELECT id FROM trucks WHERE rc_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
        OR puc_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
        OR fitness_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
        OR insurance_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
      UNION
      SELECT id FROM drivers WHERE license_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
    ) AS alerts`);
    const [trend] = await db.query(`
      SELECT DATE_FORMAT(trip_date,'%b %Y') AS month_label,
        SUM(CASE WHEN trip_type='owned' THEN freight_amount ELSE 0 END) AS owned_revenue,
        SUM(CASE WHEN trip_type='brokerage' THEN commission_amount ELSE 0 END) AS brokerage_commission,
        COUNT(*) AS trips
      FROM trips WHERE trip_date>=DATE_SUB(CURDATE(),INTERVAL 6 MONTH) AND status!='cancelled'
      GROUP BY DATE_FORMAT(trip_date,'%Y-%m'), DATE_FORMAT(trip_date,'%b %Y')
      ORDER BY MIN(trip_date)`);
    const [routes] = await db.query(`
      SELECT CONCAT(from_location,' → ',to_location) AS route, COUNT(*) AS trips, SUM(freight_amount) AS revenue
      FROM trips WHERE status='completed'
      GROUP BY from_location, to_location ORDER BY revenue DESC LIMIT 5`);

    res.json({
      monthly: {
        owned_revenue: +owned.rev, brokerage_commission: +brokerage.rev,
        total_revenue: +owned.rev + +brokerage.rev,
        expenses: +expenses.total,
        net_profit: +owned.rev + +brokerage.rev - +expenses.total,
        trips: trips.total
      },
      fleet: { trucks: trucks.total, drivers: drivers.total },
      pending_invoices: { count: pending.count, amount: +pending.amount },
      expiring_docs: expiring.count,
      trend, top_routes: routes
    });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

module.exports = router;
