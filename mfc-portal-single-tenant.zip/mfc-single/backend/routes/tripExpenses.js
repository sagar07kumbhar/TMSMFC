const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/trip/:tripId', async (req, res) => {
  const [r] = await db.query('SELECT * FROM trip_expenses WHERE trip_id=? ORDER BY expense_date', [req.params.tripId]);
  res.json(r);
});
router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    'INSERT INTO trip_expenses (trip_id,expense_type,amount,description,expense_date) VALUES (?,?,?,?,?)',
    [d.trip_id, d.expense_type, d.amount, d.description, d.expense_date || new Date()]);
  res.status(201).json({ id: r.insertId });
});
router.put('/:id', async (req, res) => {
  const d = req.body;
  await db.query(
    'UPDATE trip_expenses SET expense_type=?,amount=?,description=?,expense_date=? WHERE id=?',
    [d.expense_type, d.amount, d.description, d.expense_date, req.params.id]);
  res.json({ message: 'Updated' });
});
router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM trip_expenses WHERE id=?', [req.params.id]);
  res.json({ message: 'Deleted' });
});
module.exports = router;
