const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/', async (req, res) => {
  const [r] = await db.query('SELECT * FROM trucks WHERE is_active=1 ORDER BY truck_number');
  res.json(r);
});
router.get('/:id', async (req, res) => {
  const [r] = await db.query('SELECT * FROM trucks WHERE id=?', [req.params.id]);
  r.length ? res.json(r[0]) : res.status(404).json({ error: 'Not found' });
});
router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    `INSERT INTO trucks (truck_number,truck_type,wheel_count,make,model,year,
      rc_expiry,puc_expiry,fitness_expiry,insurance_expiry,permit_expiry,
      loan_amount,loan_emi,loan_start_date,loan_tenure_months)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [d.truck_number,d.truck_type,d.wheel_count||'10',d.make,d.model,d.year,
     d.rc_expiry||null,d.puc_expiry||null,d.fitness_expiry||null,d.insurance_expiry||null,d.permit_expiry||null,
     d.loan_amount||0,d.loan_emi||0,d.loan_start_date||null,d.loan_tenure_months||0]);
  res.status(201).json({ id: r.insertId });
});
router.put('/:id', async (req, res) => {
  const d = req.body;
  await db.query(
    `UPDATE trucks SET truck_number=?,truck_type=?,wheel_count=?,make=?,model=?,year=?,
      rc_expiry=?,puc_expiry=?,fitness_expiry=?,insurance_expiry=?,permit_expiry=?,
      loan_amount=?,loan_emi=?,loan_start_date=?,loan_tenure_months=?,loan_paid_emis=?
     WHERE id=?`,
    [d.truck_number,d.truck_type,d.wheel_count,d.make,d.model,d.year,
     d.rc_expiry||null,d.puc_expiry||null,d.fitness_expiry||null,d.insurance_expiry||null,d.permit_expiry||null,
     d.loan_amount||0,d.loan_emi||0,d.loan_start_date||null,d.loan_tenure_months||0,d.loan_paid_emis||0,
     req.params.id]);
  res.json({ message: 'Updated' });
});
router.delete('/:id', async (req, res) => {
  await db.query('UPDATE trucks SET is_active=0 WHERE id=?', [req.params.id]);
  res.json({ message: 'Deactivated' });
});
module.exports = router;
