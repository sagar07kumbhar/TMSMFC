const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

router.get('/', async (req, res) => {
  const [r] = await db.query(`
    SELECT i.*, c.name AS consignee_name
    FROM invoices i LEFT JOIN consignees c ON i.consignee_id=c.id
    ORDER BY i.invoice_date DESC`);
  res.json(r);
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.query(`
    SELECT i.*, c.name AS consignee_name, c.gstin AS consignee_gstin,
      c.address AS consignee_address, c.city AS consignee_city, c.state AS consignee_state,
      s.business_name, s.gstin AS company_gstin, s.pan, s.address AS company_address,
      s.bank_name, s.bank_account, s.bank_ifsc, s.phone AS company_phone
    FROM invoices i
    LEFT JOIN consignees c ON i.consignee_id=c.id
    CROSS JOIN settings s
    WHERE i.id=?`, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  const inv = rows[0];
  if (inv.trip_ids) {
    const ids = JSON.parse(inv.trip_ids);
    if (ids.length) {
      const [trips] = await db.query(
        'SELECT t.*, tr.truck_number FROM trips t LEFT JOIN trucks tr ON t.truck_id=tr.id WHERE t.id IN (?)', [ids]);
      inv.trips = trips;
    }
  }
  res.json(inv);
});

router.post('/', async (req, res) => {
  const d = req.body;
  const [r] = await db.query(
    'INSERT INTO invoices (invoice_number,invoice_date,consignee_id,trip_ids,subtotal,gst_amount,total_amount,notes) VALUES (?,?,?,?,?,?,?,?)',
    [d.invoice_number, d.invoice_date, d.consignee_id, JSON.stringify(d.trip_ids||[]),
     d.subtotal, d.gst_amount||0, d.total_amount, d.notes]);
  res.status(201).json({ id: r.insertId });
});

router.put('/:id/payment', async (req, res) => {
  const { amount_paid } = req.body;
  const [rows] = await db.query('SELECT total_amount FROM invoices WHERE id=?', [req.params.id]);
  const status = amount_paid >= rows[0].total_amount ? 'paid' : amount_paid > 0 ? 'partial' : 'unpaid';
  await db.query('UPDATE invoices SET amount_paid=?,payment_status=? WHERE id=?', [amount_paid, status, req.params.id]);
  res.json({ payment_status: status });
});

module.exports = router;
