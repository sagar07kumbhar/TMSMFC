import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Box, Drawer, AppBar, Toolbar, Typography, List, ListItem,
  ListItemButton, ListItemIcon, ListItemText, IconButton,
  Avatar, Menu, MenuItem, Divider
} from '@mui/material';
import {
  Dashboard, LocalShipping, DirectionsBus, People, Receipt,
  Business, Build, SmartToy, Settings, Menu as MenuIcon, Logout
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

const W = 240;
const NAV = [
  { label: 'Dashboard',   icon: <Dashboard />,      path: '/dashboard' },
  { label: 'Trips',       icon: <LocalShipping />,   path: '/trips' },
  { label: 'Fleet',       icon: <DirectionsBus />,   path: '/fleet' },
  { label: 'Drivers',     icon: <People />,          path: '/drivers' },
  { label: 'Invoices',    icon: <Receipt />,         path: '/invoices' },
  { label: 'Consignees',  icon: <Business />,        path: '/consignees' },
  { label: 'Maintenance', icon: <Build />,           path: '/maintenance' },
  { label: 'AI Assistant',icon: <SmartToy />,        path: '/ai' },
  { label: 'Settings',    icon: <Settings />,        path: '/settings' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchor, setAnchor] = useState(null);

  const sidebar = (
    <Box sx={{ height: '100%', bgcolor: '#1a3a5c', color: '#fff', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ p: 2.5, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
        <Typography variant="h6" fontWeight={700}>🚛 MFC Portal</Typography>
        <Typography variant="caption" sx={{ opacity: 0.6 }}>{user?.name}</Typography>
      </Box>
      <List sx={{ pt: 1, flex: 1 }}>
        {NAV.map(item => (
          <ListItem key={item.path} disablePadding>
            <ListItemButton
              selected={loc.pathname === item.path}
              onClick={() => { nav(item.path); setMobileOpen(false); }}
              sx={{
                mx: 1, mb: 0.5, borderRadius: 2, color: 'rgba(255,255,255,0.75)',
                '&.Mui-selected': { bgcolor: 'rgba(255,255,255,0.15)', color: '#fff' },
                '&:hover': { bgcolor: 'rgba(255,255,255,0.08)' }
              }}
            >
              <ListItemIcon sx={{ color: 'inherit', minWidth: 36 }}>{item.icon}</ListItemIcon>
              <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14 }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <Drawer variant="permanent" sx={{ width: W, flexShrink: 0, '& .MuiDrawer-paper': { width: W, border: 'none' }, display: { xs: 'none', sm: 'block' } }}>
        {sidebar}
      </Drawer>
      <Drawer variant="temporary" open={mobileOpen} onClose={() => setMobileOpen(false)} sx={{ '& .MuiDrawer-paper': { width: W }, display: { sm: 'none' } }}>
        {sidebar}
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, minWidth: 0, width: { sm: `calc(100% - ${W}px)` } }}>
        <AppBar position="sticky" elevation={0} sx={{ bgcolor: '#fff', borderBottom: '1px solid #e8e8e8' }}>
          <Toolbar variant="dense">
            <IconButton onClick={() => setMobileOpen(true)} sx={{ mr: 1, display: { sm: 'none' } }}><MenuIcon /></IconButton>
            <Typography variant="h6" sx={{ flexGrow: 1, color: '#1a3a5c', fontWeight: 600, fontSize: 16 }}>
              {NAV.find(n => n.path === loc.pathname)?.label || 'MFC Portal'}
            </Typography>
            <IconButton onClick={e => setAnchor(e.currentTarget)}>
              <Avatar sx={{ bgcolor: '#1a3a5c', width: 32, height: 32, fontSize: 13 }}>
                {user?.name?.[0] || 'A'}
              </Avatar>
            </IconButton>
            <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)}>
              <MenuItem disabled><Typography variant="caption">{user?.name} · {user?.role}</Typography></MenuItem>
              <Divider />
              <MenuItem onClick={() => { logout(); nav('/login'); }}>
                <Logout fontSize="small" sx={{ mr: 1 }} />Logout
              </MenuItem>
            </Menu>
          </Toolbar>
        </AppBar>
        <Box sx={{ p: 3 }}><Outlet /></Box>
      </Box>
    </Box>
  );
}
