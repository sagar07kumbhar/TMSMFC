import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Button, Card, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Grid, Alert, Tabs, Tab
} from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import api from '../utils/api';

const STATUS_COLOR = { planned: 'default', in_progress: 'info', completed: 'success', cancelled: 'error' };
const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;
const BLANK = { trip_number:'', lr_number:'', trip_date: new Date().toISOString().slice(0,10), trip_type:'owned',
  truck_id:'', driver_id:'', broker_owner_name:'', broker_owner_phone:'', broker_truck_number:'', broker_driver_name:'',
  commission_percent:10, consignee_id:'', from_location:'', to_location:'', distance_km:'', weight_tons:'',
  freight_amount:'', advance_paid:'', detention_charges:0, kata_charges:0, loading_charges:0, unloading_charges:0,
  gst_type:'exempt', gst_rate:0, status:'planned', notes:'' };

export default function Trips() {
  const [trips, setTrips] = useState([]);
  const [trucks, setTrucks] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [consignees, setConsignees] = useState([]);
  const [tab, setTab] = useState('all');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(BLANK);
  const [editing, setEditing] = useState(null);

  const load = async () => {
    const [t, tr, d, c] = await Promise.all([api.get('/trips'), api.get('/trucks'), api.get('/drivers'), api.get('/consignees')]);
    setTrips(t.data.data || []); setTrucks(tr.data); setDrivers(d.data); setConsignees(c.data);
  };
  useEffect(() => { load(); }, []);

  const openForm = (trip = null) => {
    setEditing(trip?.id || null);
    setForm(trip ? { ...trip } : { ...BLANK, trip_number: `TRIP-${Date.now().toString().slice(-6)}` });
    setOpen(true);
  };
  const save = async () => {
    try {
      editing ? await api.put(`/trips/${editing}`, form) : await api.post('/trips', form);
      setOpen(false); load();
    } catch (e) { alert(e.response?.data?.error || 'Save failed'); }
  };
  const del = async id => { if (confirm('Delete trip?')) { await api.delete(`/trips/${id}`); load(); } };
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const filtered = tab === 'all' ? trips : trips.filter(t => t.trip_type === tab);

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h5" fontWeight={700}>Trips</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => openForm()}>Add Trip</Button>
      </Box>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab label="All" value="all" /><Tab label="Own Fleet" value="owned" /><Tab label="Brokerage" value="brokerage" />
      </Tabs>
      <Card>
        <TableContainer>
          <Table size="small">
            <TableHead><TableRow sx={{ bgcolor: '#f5f7fa' }}>
              <TableCell>Trip #</TableCell><TableCell>Date</TableCell><TableCell>Type</TableCell>
              <TableCell>Route</TableCell><TableCell>Vehicle</TableCell><TableCell>Consignee</TableCell>
              <TableCell align="right">Freight</TableCell><TableCell>Status</TableCell><TableCell>Actions</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {filtered.map(t => (
                <TableRow key={t.id} hover>
                  <TableCell><b>{t.trip_number}</b><br/><small style={{color:'#999'}}>{t.lr_number}</small></TableCell>
                  <TableCell>{new Date(t.trip_date).toLocaleDateString('en-IN')}</TableCell>
                  <TableCell><Chip label={t.trip_type} size="small" color={t.trip_type==='owned'?'primary':'warning'} /></TableCell>
                  <TableCell style={{fontSize:13}}>{t.from_location} → {t.to_location}</TableCell>
                  <TableCell>{t.truck_number || t.broker_truck_number || '-'}</TableCell>
                  <TableCell>{t.consignee_name || '-'}</TableCell>
                  <TableCell align="right">
                    {fmt(t.freight_amount)}
                    {t.trip_type==='brokerage' && <><br/><small style={{color:'#e67e22'}}>Comm: {fmt(t.commission_amount)}</small></>}
                  </TableCell>
                  <TableCell><Chip label={t.status} size="small" color={STATUS_COLOR[t.status]} /></TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => openForm(t)}><Edit fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={() => del(t.id)}><Delete fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
              {!filtered.length && <TableRow><TableCell colSpan={9} align="center" sx={{ py: 4, color: '#aaa' }}>No trips found</TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editing ? 'Edit Trip' : 'New Trip'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid item xs={6}><TextField label="Trip Number" fullWidth value={form.trip_number} onChange={e=>f('trip_number',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="LR Number" fullWidth value={form.lr_number} onChange={e=>f('lr_number',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Date" type="date" fullWidth value={form.trip_date} onChange={e=>f('trip_date',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={6}><TextField select label="Trip Type" fullWidth value={form.trip_type} onChange={e=>f('trip_type',e.target.value)}>
              <MenuItem value="owned">Owned (Own Fleet)</MenuItem>
              <MenuItem value="brokerage">Brokerage (External)</MenuItem>
            </TextField></Grid>

            {form.trip_type==='owned' ? <>
              <Grid item xs={6}><TextField select label="Truck" fullWidth value={form.truck_id} onChange={e=>f('truck_id',e.target.value)}>
                {trucks.map(t=><MenuItem key={t.id} value={t.id}>{t.truck_number}</MenuItem>)}
              </TextField></Grid>
              <Grid item xs={6}><TextField select label="Driver" fullWidth value={form.driver_id} onChange={e=>f('driver_id',e.target.value)}>
                {drivers.map(d=><MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
              </TextField></Grid>
            </> : <>
              <Grid item xs={6}><TextField label="Owner Name" fullWidth value={form.broker_owner_name} onChange={e=>f('broker_owner_name',e.target.value)} /></Grid>
              <Grid item xs={6}><TextField label="Owner Phone" fullWidth value={form.broker_owner_phone} onChange={e=>f('broker_owner_phone',e.target.value)} /></Grid>
              <Grid item xs={6}><TextField label="Truck Number" fullWidth value={form.broker_truck_number} onChange={e=>f('broker_truck_number',e.target.value)} /></Grid>
              <Grid item xs={4}><TextField label="Driver Name" fullWidth value={form.broker_driver_name} onChange={e=>f('broker_driver_name',e.target.value)} /></Grid>
              <Grid item xs={2}><TextField label="Comm %" type="number" fullWidth value={form.commission_percent} onChange={e=>f('commission_percent',e.target.value)} /></Grid>
            </>}

            <Grid item xs={12}><TextField select label="Consignee" fullWidth value={form.consignee_id} onChange={e=>f('consignee_id',e.target.value)}>
              {consignees.map(c=><MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={5}><TextField label="From" fullWidth value={form.from_location} onChange={e=>f('from_location',e.target.value)} /></Grid>
            <Grid item xs={5}><TextField label="To" fullWidth value={form.to_location} onChange={e=>f('to_location',e.target.value)} /></Grid>
            <Grid item xs={2}><TextField label="KM" type="number" fullWidth value={form.distance_km} onChange={e=>f('distance_km',e.target.value)} /></Grid>
            <Grid item xs={4}><TextField label="Weight (tons)" type="number" fullWidth value={form.weight_tons} onChange={e=>f('weight_tons',e.target.value)} /></Grid>
            <Grid item xs={4}><TextField select label="GST Type" fullWidth value={form.gst_type} onChange={e=>f('gst_type',e.target.value)}>
              <MenuItem value="exempt">Exempt</MenuItem>
              <MenuItem value="cgst_sgst">CGST+SGST (Intra)</MenuItem>
              <MenuItem value="igst">IGST (Inter)</MenuItem>
            </TextField></Grid>
            <Grid item xs={4}><TextField label="GST %" type="number" fullWidth value={form.gst_rate} onChange={e=>f('gst_rate',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Freight ₹" type="number" fullWidth value={form.freight_amount} onChange={e=>f('freight_amount',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Advance Paid ₹" type="number" fullWidth value={form.advance_paid} onChange={e=>f('advance_paid',e.target.value)} /></Grid>
            <Grid item xs={3}><TextField label="Detention ₹" type="number" fullWidth value={form.detention_charges} onChange={e=>f('detention_charges',e.target.value)} /></Grid>
            <Grid item xs={3}><TextField label="Kata ₹" type="number" fullWidth value={form.kata_charges} onChange={e=>f('kata_charges',e.target.value)} /></Grid>
            <Grid item xs={3}><TextField label="Loading ₹" type="number" fullWidth value={form.loading_charges} onChange={e=>f('loading_charges',e.target.value)} /></Grid>
            <Grid item xs={3}><TextField label="Unloading ₹" type="number" fullWidth value={form.unloading_charges} onChange={e=>f('unloading_charges',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField select label="Status" fullWidth value={form.status} onChange={e=>f('status',e.target.value)}>
              {['planned','in_progress','completed','cancelled'].map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={6}><TextField label="Notes" fullWidth value={form.notes} onChange={e=>f('notes',e.target.value)} /></Grid>

            {form.trip_type==='owned' && +form.distance_km>0 && (
              <Grid item xs={12}><Alert severity="info">Driver extra pay: ₹{(+form.distance_km*5).toLocaleString('en-IN')} ({form.distance_km} km × ₹5/km)</Alert></Grid>
            )}
            {form.trip_type==='brokerage' && +form.freight_amount>0 && (
              <Grid item xs={12}><Alert severity="warning">
                Commission: ₹{((+form.freight_amount*(+form.commission_percent||0))/100).toLocaleString('en-IN')} |
                Pay to owner: ₹{((+form.freight_amount) - (+form.freight_amount*(+form.commission_percent||0)/100)).toLocaleString('en-IN')}
              </Alert></Grid>
            )}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={save}>Save Trip</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
