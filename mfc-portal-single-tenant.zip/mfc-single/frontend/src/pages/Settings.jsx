import React, { useEffect, useState } from 'react';
import { Box, Typography, Card, CardContent, Grid, TextField, Button, MenuItem, Alert, Divider } from '@mui/material';
import { Save } from '@mui/icons-material';
import api from '../utils/api';
export default function Settings() {
  const [form, setForm] = useState({});
  const [saved, setSaved] = useState(false);
  useEffect(() => { api.get('/settings').then(r=>setForm(r.data)); }, []);
  const save = async () => {
    await api.put('/settings', form);
    setSaved(true); setTimeout(()=>setSaved(false), 3000);
  };
  const f=(k,v)=>setForm(p=>({...p,[k]:v}));
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={2}>Settings</Typography>
      {saved && <Alert severity="success" sx={{mb:2}}>Settings saved successfully!</Alert>}
      <Card>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={600} mb={2}>Business Details</Typography>
          <Grid container spacing={2}>
            <Grid item xs={6}><TextField label="Business Name" fullWidth value={form.business_name||''} onChange={e=>f('business_name',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="Owner Name" fullWidth value={form.owner_name||''} onChange={e=>f('owner_name',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="GSTIN" fullWidth value={form.gstin||''} onChange={e=>f('gstin',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="PAN" fullWidth value={form.pan||''} onChange={e=>f('pan',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="Phone" fullWidth value={form.phone||''} onChange={e=>f('phone',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="Email" fullWidth value={form.email||''} onChange={e=>f('email',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="City" fullWidth value={form.city||''} onChange={e=>f('city',e.target.value)}/></Grid>
            <Grid item xs={6}><TextField label="State" fullWidth value={form.state||''} onChange={e=>f('state',e.target.value)}/></Grid>
            <Grid item xs={12}><TextField label="Address" fullWidth multiline rows={2} value={form.address||''} onChange={e=>f('address',e.target.value)}/></Grid>
          </Grid>
          <Divider sx={{my:3}}/>
          <Typography variant="subtitle1" fontWeight={600} mb={2}>Bank Details</Typography>
          <Grid container spacing={2}>
            <Grid item xs={4}><TextField label="Bank Name" fullWidth value={form.bank_name||''} onChange={e=>f('bank_name',e.target.value)}/></Grid>
            <Grid item xs={4}><TextField label="Account Number" fullWidth value={form.bank_account||''} onChange={e=>f('bank_account',e.target.value)}/></Grid>
            <Grid item xs={4}><TextField label="IFSC Code" fullWidth value={form.bank_ifsc||''} onChange={e=>f('bank_ifsc',e.target.value)}/></Grid>
          </Grid>
          <Divider sx={{my:3}}/>
          <Typography variant="subtitle1" fontWeight={600} mb={2}>Business Rules</Typography>
          <Grid container spacing={2}>
            <Grid item xs={4}><TextField label="Driver Pay per KM (₹)" type="number" fullWidth value={form.driver_pay_per_km||5} onChange={e=>f('driver_pay_per_km',e.target.value)}/></Grid>
            <Grid item xs={4}><TextField label="Default Commission %" type="number" fullWidth value={form.default_commission_percent||10} onChange={e=>f('default_commission_percent',e.target.value)}/></Grid>
            <Grid item xs={4}><TextField select label="Default GST Type" fullWidth value={form.gst_default||'exempt'} onChange={e=>f('gst_default',e.target.value)}>
              <MenuItem value="exempt">Exempt</MenuItem>
              <MenuItem value="cgst_sgst">CGST+SGST</MenuItem>
              <MenuItem value="igst">IGST</MenuItem>
            </TextField></Grid>
            <Grid item xs={4}><TextField label="Invoice Prefix" fullWidth value={form.invoice_prefix||'INV'} onChange={e=>f('invoice_prefix',e.target.value)}/></Grid>
            <Grid item xs={4}><TextField label="Trip Number Prefix" fullWidth value={form.trip_number_prefix||'TRIP'} onChange={e=>f('trip_number_prefix',e.target.value)}/></Grid>
          </Grid>
          <Box sx={{mt:3}}>
            <Button variant="contained" startIcon={<Save/>} onClick={save} size="large">Save Settings</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
