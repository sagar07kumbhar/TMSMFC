import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Button, Grid, Card, CardContent, LinearProgress,
  Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, MenuItem
} from '@mui/material';
import { Add, Edit } from '@mui/icons-material';
import api from '../utils/api';

const docChip = date => {
  if (!date) return <Chip label="N/A" size="small" />;
  const days = Math.ceil((new Date(date) - new Date()) / 86400000);
  if (days < 0)   return <Chip label="EXPIRED" color="error" size="small" />;
  if (days <= 30) return <Chip label={`${days}d`} color="warning" size="small" />;
  return <Chip label={new Date(date).toLocaleDateString('en-IN')} color="success" size="small" />;
};

export default function Fleet() {
  const [trucks, setTrucks] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);

  const load = () => api.get('/trucks').then(r => setTrucks(r.data));
  useEffect(() => { load(); }, []);

  const openForm = (t = null) => {
    setEditing(t?.id || null);
    setForm(t || { truck_number:'', truck_type:'', wheel_count:'10', make:'', model:'', year: new Date().getFullYear(), loan_amount:0, loan_emi:0, loan_tenure_months:0, loan_paid_emis:0 });
    setOpen(true);
  };
  const save = async () => {
    editing ? await api.put(`/trucks/${editing}`, form) : await api.post('/trucks', form);
    setOpen(false); load();
  };
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  return (
    <Box>
      <Box sx={{ display:'flex', justifyContent:'space-between', mb:2 }}>
        <Typography variant="h5" fontWeight={700}>Fleet</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => openForm()}>Add Truck</Button>
      </Box>
      <Grid container spacing={2.5}>
        {trucks.map(t => {
          const pct = t.loan_tenure_months ? Math.min(100, ((t.loan_paid_emis||0)/t.loan_tenure_months)*100) : 0;
          return (
            <Grid item xs={12} md={6} lg={4} key={t.id}>
              <Card>
                <CardContent>
                  <Box sx={{ display:'flex', justifyContent:'space-between', mb:1 }}>
                    <Typography variant="h6" fontWeight={700}>{t.truck_number}</Typography>
                    <IconButton size="small" onClick={() => openForm(t)}><Edit fontSize="small" /></IconButton>
                  </Box>
                  <Typography variant="body2" color="text.secondary" mb={1.5}>{t.make} {t.model} {t.year} · {t.wheel_count}-wheel</Typography>
                  <Box sx={{ display:'flex', flexWrap:'wrap', gap:0.5, mb:2 }}>
                    {[['RC',t.rc_expiry],['PUC',t.puc_expiry],['Fitness',t.fitness_expiry],['Ins',t.insurance_expiry]].map(([l,d])=>(
                      <Box key={l} sx={{ display:'flex', alignItems:'center', gap:0.3 }}>
                        <Typography variant="caption" color="text.secondary">{l}:</Typography>
                        {docChip(d)}
                      </Box>
                    ))}
                  </Box>
                  {t.loan_tenure_months > 0 && (
                    <Box>
                      <Box sx={{ display:'flex', justifyContent:'space-between' }}>
                        <Typography variant="caption" fontWeight={600}>LOAN</Typography>
                        <Typography variant="caption">{t.loan_paid_emis}/{t.loan_tenure_months} EMIs</Typography>
                      </Box>
                      <LinearProgress variant="determinate" value={pct} sx={{ height:7, borderRadius:4, my:0.5 }} />
                      <Typography variant="caption" color="text.secondary">EMI ₹{(t.loan_emi||0).toLocaleString('en-IN')}/mo</Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editing ? 'Edit Truck' : 'Add Truck'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt:0.5 }}>
            <Grid item xs={6}><TextField label="Truck Number" fullWidth value={form.truck_number||''} onChange={e=>f('truck_number',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Type" fullWidth value={form.truck_type||''} onChange={e=>f('truck_type',e.target.value)} placeholder="14-Wheeler Heavy" /></Grid>
            <Grid item xs={4}><TextField select label="Wheels" fullWidth value={form.wheel_count||'10'} onChange={e=>f('wheel_count',e.target.value)}>
              {['4','6','10','14'].map(w=><MenuItem key={w} value={w}>{w} Wheel</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={4}><TextField label="Make" fullWidth value={form.make||''} onChange={e=>f('make',e.target.value)} /></Grid>
            <Grid item xs={4}><TextField label="Model" fullWidth value={form.model||''} onChange={e=>f('model',e.target.value)} /></Grid>
            <Grid item xs={4}><TextField label="Year" type="number" fullWidth value={form.year||''} onChange={e=>f('year',e.target.value)} /></Grid>
            <Grid item xs={4}><TextField label="RC Expiry" type="date" fullWidth value={form.rc_expiry||''} onChange={e=>f('rc_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={4}><TextField label="PUC Expiry" type="date" fullWidth value={form.puc_expiry||''} onChange={e=>f('puc_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={4}><TextField label="Fitness Expiry" type="date" fullWidth value={form.fitness_expiry||''} onChange={e=>f('fitness_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={4}><TextField label="Insurance Expiry" type="date" fullWidth value={form.insurance_expiry||''} onChange={e=>f('insurance_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={4}><TextField label="Permit Expiry" type="date" fullWidth value={form.permit_expiry||''} onChange={e=>f('permit_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={12}><Typography variant="subtitle2" mt={1} color="text.secondary">Loan Details (optional)</Typography></Grid>
            <Grid item xs={6}><TextField label="Loan Amount ₹" type="number" fullWidth value={form.loan_amount||''} onChange={e=>f('loan_amount',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="EMI ₹/mo" type="number" fullWidth value={form.loan_emi||''} onChange={e=>f('loan_emi',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Tenure (months)" type="number" fullWidth value={form.loan_tenure_months||''} onChange={e=>f('loan_tenure_months',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="EMIs Paid" type="number" fullWidth value={form.loan_paid_emis||''} onChange={e=>f('loan_paid_emis',e.target.value)} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={save}>Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
