import React, { useState, useRef, useEffect } from 'react';
import { Box, Typography, TextField, Button, Paper, Avatar, CircularProgress, Chip, Alert } from '@mui/material';
import { Send, SmartToy, Person } from '@mui/icons-material';
import api from '../utils/api';
const HINTS = ['Revenue this month?','Most profitable route?','Expense summary','Trucks needing maintenance?','Brokerage commission this month?'];
export default function AIAssistant() {
  const [msgs, setMsgs] = useState([{ role:'assistant', content:"Hello! I'm your business assistant. Ask me about trips, revenue, fleet, or anything about your transport operations." }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');
  const ref = useRef(null);
  useEffect(() => { ref.current?.scrollIntoView({ behavior:'smooth' }); }, [msgs]);
  const send = async text => {
    const msg = text || input.trim(); if (!msg) return;
    setInput(''); setApiError('');
    const next = [...msgs, { role:'user', content:msg }];
    setMsgs(next); setLoading(true);
    try {
      const r = await api.post('/ai/chat', { message: msg, history: msgs.slice(-10) });
      setMsgs([...next, { role:'assistant', content: r.data.reply }]);
    } catch (e) {
      const err = e.response?.data?.error || 'AI unavailable';
      setApiError(err);
      setMsgs([...next, { role:'assistant', content: `⚠️ ${err}` }]);
    } finally { setLoading(false); }
  };
  return (
    <Box sx={{ height:'calc(100vh - 140px)', display:'flex', flexDirection:'column' }}>
      <Typography variant="h5" fontWeight={700} mb={1}>AI Business Assistant</Typography>
      {apiError.includes('configured') && <Alert severity="warning" sx={{mb:1}}>Add your ANTHROPIC_API_KEY to backend/.env to enable AI chat.</Alert>}
      <Box sx={{ display:'flex', gap:1, mb:1.5, flexWrap:'wrap' }}>
        {HINTS.map(h=><Chip key={h} label={h} size="small" onClick={()=>send(h)} sx={{cursor:'pointer'}} />)}
      </Box>
      <Paper sx={{ flex:1, overflow:'auto', p:2, mb:1.5, bgcolor:'#f8f9fa' }}>
        {msgs.map((m,i)=>(
          <Box key={i} sx={{ display:'flex', gap:1.5, mb:2, flexDirection: m.role==='user'?'row-reverse':'row' }}>
            <Avatar sx={{ bgcolor: m.role==='assistant'?'#1a3a5c':'#e67e22', width:32, height:32 }}>
              {m.role==='assistant'?<SmartToy sx={{fontSize:18}}/>:<Person sx={{fontSize:18}}/>}
            </Avatar>
            <Paper sx={{ p:1.5, maxWidth:'75%', borderRadius:2, bgcolor:m.role==='user'?'#1a3a5c':'white', color:m.role==='user'?'white':'inherit' }}>
              <Typography variant="body2" sx={{ whiteSpace:'pre-wrap' }}>{m.content}</Typography>
            </Paper>
          </Box>
        ))}
        {loading && <Box sx={{display:'flex',gap:1.5}}><Avatar sx={{bgcolor:'#1a3a5c',width:32,height:32}}><SmartToy sx={{fontSize:18}}/></Avatar><Paper sx={{p:1.5,borderRadius:2}}><CircularProgress size={16}/></Paper></Box>}
        <div ref={ref}/>
      </Paper>
      <Box sx={{ display:'flex', gap:1 }}>
        <TextField fullWidth placeholder="Ask about your business..." value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&send()} />
        <Button variant="contained" onClick={()=>send()} disabled={loading||!input.trim()}><Send/></Button>
      </Box>
    </Box>
  );
}
