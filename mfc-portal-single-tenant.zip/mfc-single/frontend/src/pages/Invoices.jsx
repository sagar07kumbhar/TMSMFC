import React, { useEffect, useState } from 'react';
import { Box, Typography, Card, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Chip } from '@mui/material';
import api from '../utils/api';
const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;
const PC = { unpaid:'error', partial:'warning', paid:'success' };
export default function Invoices() {
  const [list, setList] = useState([]);
  useEffect(() => { api.get('/invoices').then(r=>setList(r.data)); }, []);
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={2}>Invoices</Typography>
      <Card><TableContainer><Table size="small">
        <TableHead><TableRow sx={{bgcolor:'#f5f7fa'}}><TableCell>Invoice #</TableCell><TableCell>Date</TableCell><TableCell>Consignee</TableCell><TableCell align="right">Total</TableCell><TableCell align="right">Paid</TableCell><TableCell>Status</TableCell></TableRow></TableHead>
        <TableBody>
          {list.map(i=>(
            <TableRow key={i.id} hover>
              <TableCell><b>{i.invoice_number}</b></TableCell>
              <TableCell>{new Date(i.invoice_date).toLocaleDateString('en-IN')}</TableCell>
              <TableCell>{i.consignee_name}</TableCell>
              <TableCell align="right">{fmt(i.total_amount)}</TableCell>
              <TableCell align="right">{fmt(i.amount_paid)}</TableCell>
              <TableCell><Chip label={i.payment_status} size="small" color={PC[i.payment_status]} /></TableCell>
            </TableRow>
          ))}
          {!list.length&&<TableRow><TableCell colSpan={6} align="center" sx={{py:4,color:'#aaa'}}>No invoices yet</TableCell></TableRow>}
        </TableBody>
      </Table></TableContainer></Card>
    </Box>
  );
}
