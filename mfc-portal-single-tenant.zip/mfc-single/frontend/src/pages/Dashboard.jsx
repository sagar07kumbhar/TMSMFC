import React, { useEffect, useState } from 'react';
import { Grid, Card, CardContent, Typography, Box, Chip, CircularProgress, Alert } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import api from '../utils/api';

const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;

function Stat({ title, value, sub, color = '#1a3a5c' }) {
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Typography variant="caption" color="text.secondary" display="block">{title}</Typography>
        <Typography variant="h4" fontWeight={700} sx={{ color, my: 0.5 }}>{value}</Typography>
        {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    api.get('/dashboard/stats').then(r => setData(r.data)).catch(() => setErr('Failed to load'));
  }, []);

  if (!data && !err) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  if (err) return <Alert severity="error">{err}</Alert>;

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={3}>Dashboard</Typography>

      <Grid container spacing={2.5} mb={2.5}>
        <Grid item xs={6} md={3}><Stat title="This Month Revenue" value={fmt(data.monthly.total_revenue)} sub={`Owned: ${fmt(data.monthly.owned_revenue)}`} /></Grid>
        <Grid item xs={6} md={3}><Stat title="Net Profit" value={fmt(data.monthly.net_profit)} sub={`Expenses: ${fmt(data.monthly.expenses)}`} color="#27ae60" /></Grid>
        <Grid item xs={6} md={3}><Stat title="Brokerage Commission" value={fmt(data.monthly.brokerage_commission)} sub="This month" color="#e67e22" /></Grid>
        <Grid item xs={6} md={3}><Stat title="Trips This Month" value={data.monthly.trips} color="#8e44ad" /></Grid>
      </Grid>

      <Grid container spacing={2.5} mb={2.5}>
        <Grid item xs={6} md={3}><Stat title="Active Trucks" value={data.fleet.trucks} color="#2980b9" /></Grid>
        <Grid item xs={6} md={3}><Stat title="Active Drivers" value={data.fleet.drivers} color="#16a085" /></Grid>
        <Grid item xs={6} md={3}><Stat title="Pending Invoices" value={fmt(data.pending_invoices.amount)} sub={`${data.pending_invoices.count} invoices`} color="#c0392b" /></Grid>
        <Grid item xs={6} md={3}><Stat title="Docs Expiring (30d)" value={data.expiring_docs} color={data.expiring_docs > 0 ? '#e74c3c' : '#27ae60'} /></Grid>
      </Grid>

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={600} mb={2}>Revenue — Last 6 Months</Typography>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={data.trend} margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month_label" tick={{ fontSize: 12 }} />
                  <YAxis tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={v => [`₹${(+v).toLocaleString('en-IN')}`, '']} />
                  <Legend />
                  <Bar dataKey="owned_revenue" name="Own Trucks" fill="#1a3a5c" radius={[4,4,0,0]} />
                  <Bar dataKey="brokerage_commission" name="Brokerage" fill="#e67e22" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight={600} mb={2}>Top Routes</Typography>
              {data.top_routes.map((r, i) => (
                <Box key={i} mb={1.5}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" fontWeight={500}>{r.route}</Typography>
                    <Chip label={`${r.trips} trips`} size="small" sx={{ height: 20, fontSize: 11 }} />
                  </Box>
                  <Typography variant="caption" color="text.secondary">{fmt(r.revenue)}</Typography>
                </Box>
              ))}
              {!data.top_routes.length && <Typography variant="body2" color="text.secondary">No completed trips yet</Typography>}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
