import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Card, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, Tabs, Tab, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Grid } from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import api from '../utils/api';
const TYPES = ['servicing','fuel','repair','document','other'];
const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;
export default function Maintenance() {
  const [logs, setLogs] = useState([]);
  const [trucks, setTrucks] = useState([]);
  const [tab, setTab] = useState('all');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);
  const load = async () => { const [l,t] = await Promise.all([api.get('/maintenance'),api.get('/trucks')]); setLogs(l.data); setTrucks(t.data); };
  useEffect(() => { load(); }, []);
  const openForm = (l=null) => { setEditing(l?.id||null); setForm(l||{truck_id:'',log_type:'servicing',description:'',cost:0,odometer_reading:'',service_date:new Date().toISOString().slice(0,10),vendor_name:'',notes:''}); setOpen(true); };
  const save = async () => { editing ? await api.put(`/maintenance/${editing}`,form) : await api.post('/maintenance',form); setOpen(false); load(); };
  const f=(k,v)=>setForm(p=>({...p,[k]:v}));
  const filtered = tab==='all' ? logs : logs.filter(l=>l.log_type===tab);
  return (
    <Box>
      <Box sx={{display:'flex',justifyContent:'space-between',mb:2}}>
        <Typography variant="h5" fontWeight={700}>Maintenance</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={()=>openForm()}>Add Log</Button>
      </Box>
      <Tabs value={tab} onChange={(_,v)=>setTab(v)} sx={{mb:2}}>
        <Tab label="All" value="all"/>
        {TYPES.map(t=><Tab key={t} label={t.charAt(0).toUpperCase()+t.slice(1)} value={t}/>)}
      </Tabs>
      <Card><TableContainer><Table size="small">
        <TableHead><TableRow sx={{bgcolor:'#f5f7fa'}}><TableCell>Date</TableCell><TableCell>Truck</TableCell><TableCell>Type</TableCell><TableCell>Description</TableCell><TableCell>Odometer</TableCell><TableCell align="right">Cost</TableCell><TableCell>Vendor</TableCell><TableCell>Actions</TableCell></TableRow></TableHead>
        <TableBody>
          {filtered.map(l=>(
            <TableRow key={l.id} hover>
              <TableCell>{new Date(l.service_date).toLocaleDateString('en-IN')}</TableCell>
              <TableCell>{l.truck_number}</TableCell>
              <TableCell><Chip label={l.log_type} size="small"/></TableCell>
              <TableCell>{l.description}</TableCell>
              <TableCell>{l.odometer_reading ? `${l.odometer_reading.toLocaleString()} km` : '-'}</TableCell>
              <TableCell align="right">{fmt(l.cost)}</TableCell>
              <TableCell>{l.vendor_name||'-'}</TableCell>
              <TableCell>
                <IconButton size="small" onClick={()=>openForm(l)}><Edit fontSize="small"/></IconButton>
                <IconButton size="small" color="error" onClick={async()=>{if(confirm('Delete?')){await api.delete(`/maintenance/${l.id}`);load();}}}><Delete fontSize="small"/></IconButton>
              </TableCell>
            </TableRow>
          ))}
          {!filtered.length&&<TableRow><TableCell colSpan={8} align="center" sx={{py:4,color:'#aaa'}}>No logs</TableCell></TableRow>}
        </TableBody>
      </Table></TableContainer></Card>
      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editing?'Edit Log':'Add Log'}</DialogTitle>
        <DialogContent><Grid container spacing={2} sx={{mt:0.5}}>
          <Grid item xs={6}><TextField select label="Truck" fullWidth value={form.truck_id||''} onChange={e=>f('truck_id',e.target.value)}>
            {trucks.map(t=><MenuItem key={t.id} value={t.id}>{t.truck_number}</MenuItem>)}
          </TextField></Grid>
          <Grid item xs={6}><TextField select label="Type" fullWidth value={form.log_type||'servicing'} onChange={e=>f('log_type',e.target.value)}>
            {TYPES.map(t=><MenuItem key={t} value={t}>{t}</MenuItem>)}
          </TextField></Grid>
          <Grid item xs={6}><TextField label="Date" type="date" fullWidth value={form.service_date||''} onChange={e=>f('service_date',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
          <Grid item xs={6}><TextField label="Odometer (km)" type="number" fullWidth value={form.odometer_reading||''} onChange={e=>f('odometer_reading',e.target.value)}/></Grid>
          <Grid item xs={12}><TextField label="Description" fullWidth multiline rows={2} value={form.description||''} onChange={e=>f('description',e.target.value)}/></Grid>
          <Grid item xs={6}><TextField label="Cost ₹" type="number" fullWidth value={form.cost||''} onChange={e=>f('cost',e.target.value)}/></Grid>
          <Grid item xs={6}><TextField label="Vendor" fullWidth value={form.vendor_name||''} onChange={e=>f('vendor_name',e.target.value)}/></Grid>
          <Grid item xs={6}><TextField label="Next Service" type="date" fullWidth value={form.next_service_date||''} onChange={e=>f('next_service_date',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
        </Grid></DialogContent>
        <DialogActions><Button onClick={()=>setOpen(false)}>Cancel</Button><Button variant="contained" onClick={save}>Save</Button></DialogActions>
      </Dialog>
    </Box>
  );
}
