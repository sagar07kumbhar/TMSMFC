import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Card, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Grid } from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import api from '../utils/api';

const expChip = d => {
  if (!d) return '-';
  const days = Math.ceil((new Date(d) - new Date()) / 86400000);
  if (days < 0)   return <Chip label="EXPIRED" color="error" size="small" />;
  if (days <= 30) return <Chip label={`${days}d left`} color="warning" size="small" />;
  return new Date(d).toLocaleDateString('en-IN');
};

export default function Drivers() {
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);

  const load = () => api.get('/drivers').then(r => setList(r.data));
  useEffect(() => { load(); }, []);

  const openForm = (d = null) => { setEditing(d?.id||null); setForm(d||{name:'',phone:'',license_number:'',license_expiry:'',badge_expiry:'',address:''}); setOpen(true); };
  const save = async () => { editing ? await api.put(`/drivers/${editing}`, form) : await api.post('/drivers', form); setOpen(false); load(); };
  const f = (k,v) => setForm(p=>({...p,[k]:v}));

  return (
    <Box>
      <Box sx={{ display:'flex', justifyContent:'space-between', mb:2 }}>
        <Typography variant="h5" fontWeight={700}>Drivers</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => openForm()}>Add Driver</Button>
      </Box>
      <Card>
        <TableContainer>
          <Table size="small">
            <TableHead><TableRow sx={{bgcolor:'#f5f7fa'}}>
              <TableCell>Name</TableCell><TableCell>Phone</TableCell><TableCell>License No</TableCell><TableCell>License Expiry</TableCell><TableCell>Badge Expiry</TableCell><TableCell>Actions</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {list.map(d=>(
                <TableRow key={d.id} hover>
                  <TableCell><b>{d.name}</b></TableCell><TableCell>{d.phone}</TableCell><TableCell>{d.license_number}</TableCell>
                  <TableCell>{expChip(d.license_expiry)}</TableCell><TableCell>{expChip(d.badge_expiry)}</TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={()=>openForm(d)}><Edit fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={async()=>{if(confirm('Deactivate?')){await api.delete(`/drivers/${d.id}`);load();}}}><Delete fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
              {!list.length && <TableRow><TableCell colSpan={6} align="center" sx={{py:4,color:'#aaa'}}>No drivers</TableCell></TableRow>}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editing?'Edit Driver':'Add Driver'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{mt:0.5}}>
            <Grid item xs={6}><TextField label="Name" fullWidth value={form.name||''} onChange={e=>f('name',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Phone" fullWidth value={form.phone||''} onChange={e=>f('phone',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="License No" fullWidth value={form.license_number||''} onChange={e=>f('license_number',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="License Expiry" type="date" fullWidth value={form.license_expiry||''} onChange={e=>f('license_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={6}><TextField label="Badge Expiry" type="date" fullWidth value={form.badge_expiry||''} onChange={e=>f('badge_expiry',e.target.value)} InputLabelProps={{shrink:true}} /></Grid>
            <Grid item xs={12}><TextField label="Address" fullWidth multiline rows={2} value={form.address||''} onChange={e=>f('address',e.target.value)} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions><Button onClick={()=>setOpen(false)}>Cancel</Button><Button variant="contained" onClick={save}>Save</Button></DialogActions>
      </Dialog>
    </Box>
  );
}
