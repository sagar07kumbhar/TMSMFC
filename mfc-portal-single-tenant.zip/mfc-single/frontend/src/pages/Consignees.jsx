import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Card, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Grid } from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import api from '../utils/api';

export default function Consignees() {
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);
  const load = () => api.get('/consignees').then(r => setList(r.data));
  useEffect(() => { load(); }, []);
  const openForm = (c=null) => { setEditing(c?.id||null); setForm(c||{name:'',gstin:'',address:'',city:'',state:'',phone:'',email:''}); setOpen(true); };
  const save = async () => { editing ? await api.put(`/consignees/${editing}`,form) : await api.post('/consignees',form); setOpen(false); load(); };
  const f = (k,v) => setForm(p=>({...p,[k]:v}));
  return (
    <Box>
      <Box sx={{display:'flex',justifyContent:'space-between',mb:2}}>
        <Typography variant="h5" fontWeight={700}>Consignees</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={()=>openForm()}>Add</Button>
      </Box>
      <Card><TableContainer><Table size="small">
        <TableHead><TableRow sx={{bgcolor:'#f5f7fa'}}><TableCell>Name</TableCell><TableCell>GSTIN</TableCell><TableCell>City</TableCell><TableCell>State</TableCell><TableCell>Phone</TableCell><TableCell>Actions</TableCell></TableRow></TableHead>
        <TableBody>
          {list.map(c=>(
            <TableRow key={c.id} hover>
              <TableCell><b>{c.name}</b></TableCell><TableCell>{c.gstin}</TableCell><TableCell>{c.city}</TableCell><TableCell>{c.state}</TableCell><TableCell>{c.phone}</TableCell>
              <TableCell>
                <IconButton size="small" onClick={()=>openForm(c)}><Edit fontSize="small"/></IconButton>
                <IconButton size="small" color="error" onClick={async()=>{if(confirm('Delete?')){await api.delete(`/consignees/${c.id}`);load();}}}><Delete fontSize="small"/></IconButton>
              </TableCell>
            </TableRow>
          ))}
          {!list.length&&<TableRow><TableCell colSpan={6} align="center" sx={{py:4,color:'#aaa'}}>No consignees</TableCell></TableRow>}
        </TableBody>
      </Table></TableContainer></Card>
      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editing?'Edit':'Add'} Consignee</DialogTitle>
        <DialogContent><Grid container spacing={2} sx={{mt:0.5}}>
          <Grid item xs={12}><TextField label="Company Name" fullWidth value={form.name||''} onChange={e=>f('name',e.target.value)} /></Grid>
          <Grid item xs={6}><TextField label="GSTIN" fullWidth value={form.gstin||''} onChange={e=>f('gstin',e.target.value)} /></Grid>
          <Grid item xs={6}><TextField label="Phone" fullWidth value={form.phone||''} onChange={e=>f('phone',e.target.value)} /></Grid>
          <Grid item xs={6}><TextField label="City" fullWidth value={form.city||''} onChange={e=>f('city',e.target.value)} /></Grid>
          <Grid item xs={6}><TextField label="State" fullWidth value={form.state||''} onChange={e=>f('state',e.target.value)} /></Grid>
          <Grid item xs={12}><TextField label="Address" fullWidth multiline rows={2} value={form.address||''} onChange={e=>f('address',e.target.value)} /></Grid>
        </Grid></DialogContent>
        <DialogActions><Button onClick={()=>setOpen(false)}>Cancel</Button><Button variant="contained" onClick={save}>Save</Button></DialogActions>
      </Dialog>
    </Box>
  );
}
