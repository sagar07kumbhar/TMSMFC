import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { AuthProvider, useAuth } from './context/AuthContext';

import Layout     from './components/Layout';
import Login      from './pages/Login';
import Dashboard  from './pages/Dashboard';
import Trips      from './pages/Trips';
import Fleet      from './pages/Fleet';
import Drivers    from './pages/Drivers';
import Invoices   from './pages/Invoices';
import Consignees from './pages/Consignees';
import Maintenance from './pages/Maintenance';
import AIAssistant from './pages/AIAssistant';
import Settings   from './pages/Settings';

const theme = createTheme({
  palette: {
    primary:    { main: '#1a3a5c' },
    secondary:  { main: '#e67e22' },
    background: { default: '#f4f6f8' },
  },
  typography: { fontFamily: 'Inter, sans-serif' },
  components: {
    MuiButton:    { styleOverrides: { root: { textTransform: 'none', borderRadius: 8, fontWeight: 600 } } },
    MuiCard:      { styleOverrides: { root: { borderRadius: 12, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' } } },
    MuiTextField: { defaultProps: { size: 'small' } },
  }
});

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard"   element={<Dashboard />} />
              <Route path="trips"       element={<Trips />} />
              <Route path="fleet"       element={<Fleet />} />
              <Route path="drivers"     element={<Drivers />} />
              <Route path="invoices"    element={<Invoices />} />
              <Route path="consignees"  element={<Consignees />} />
              <Route path="maintenance" element={<Maintenance />} />
              <Route path="ai"          element={<AIAssistant />} />
              <Route path="settings"    element={<Settings />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
