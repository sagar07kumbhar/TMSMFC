-- ============================================================
-- MFC Portal - Single Tenant Version
-- One installation per transport business owner
-- No company_id needed anywhere
-- ============================================================

CREATE DATABASE IF NOT EXISTS mfc_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mfc_db;

-- ============================================================
-- 1. SETTINGS (owner's business details - edit once)
-- ============================================================
CREATE TABLE settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  business_name VARCHAR(255) DEFAULT 'My Transport Company',
  owner_name VARCHAR(255),
  gstin VARCHAR(20),
  pan VARCHAR(20),
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(100),
  phone VARCHAR(20),
  email VARCHAR(255),
  bank_name VARCHAR(100),
  bank_account VARCHAR(50),
  bank_ifsc VARCHAR(20),
  logo_url VARCHAR(500),
  invoice_prefix VARCHAR(20) DEFAULT 'INV',
  trip_number_prefix VARCHAR(20) DEFAULT 'TRIP',
  driver_pay_per_km DECIMAL(6,2) DEFAULT 5.00,
  default_commission_percent DECIMAL(5,2) DEFAULT 10.00,
  gst_default ENUM('cgst_sgst','igst','exempt') DEFAULT 'exempt',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- 2. USERS (login accounts - admin, staff, etc.)
-- ============================================================
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','staff') DEFAULT 'staff',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 3. TRUCKS
-- ============================================================
CREATE TABLE trucks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  truck_number VARCHAR(50) NOT NULL UNIQUE,
  truck_type VARCHAR(100),
  wheel_count ENUM('4','6','10','14') DEFAULT '10',
  make VARCHAR(100),
  model VARCHAR(100),
  year INT,
  rc_expiry DATE,
  puc_expiry DATE,
  fitness_expiry DATE,
  insurance_expiry DATE,
  permit_expiry DATE,
  loan_amount DECIMAL(12,2) DEFAULT 0,
  loan_emi DECIMAL(10,2) DEFAULT 0,
  loan_start_date DATE,
  loan_tenure_months INT DEFAULT 0,
  loan_paid_emis INT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 4. DRIVERS
-- ============================================================
CREATE TABLE drivers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  license_number VARCHAR(100),
  license_expiry DATE,
  badge_expiry DATE,
  address TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 5. CONSIGNEES (clients/customers)
-- ============================================================
CREATE TABLE consignees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  gstin VARCHAR(20),
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(100),
  phone VARCHAR(20),
  email VARCHAR(255),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 6. TRIPS (with brokerage support)
-- ============================================================
CREATE TABLE trips (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_number VARCHAR(50) UNIQUE NOT NULL,
  lr_number VARCHAR(100),
  trip_date DATE NOT NULL,
  trip_type ENUM('owned','brokerage') DEFAULT 'owned',

  -- Owned trip
  truck_id INT,
  driver_id INT,

  -- Brokerage trip
  broker_owner_name VARCHAR(255),
  broker_owner_phone VARCHAR(20),
  broker_truck_number VARCHAR(50),
  broker_driver_name VARCHAR(255),
  commission_percent DECIMAL(5,2) DEFAULT 0,
  commission_amount DECIMAL(10,2) DEFAULT 0,
  broker_advance_paid DECIMAL(10,2) DEFAULT 0,
  broker_final_paid DECIMAL(10,2) DEFAULT 0,
  broker_payment_status ENUM('pending','advance_paid','settled') DEFAULT 'pending',

  -- Common
  consignee_id INT,
  from_location VARCHAR(255),
  to_location VARCHAR(255),
  distance_km DECIMAL(8,2) DEFAULT 0,
  weight_tons DECIMAL(8,2) DEFAULT 0,
  freight_amount DECIMAL(10,2) DEFAULT 0,
  advance_paid DECIMAL(10,2) DEFAULT 0,
  balance_due DECIMAL(10,2) GENERATED ALWAYS AS (freight_amount - advance_paid) STORED,

  detention_charges DECIMAL(10,2) DEFAULT 0,
  kata_charges DECIMAL(10,2) DEFAULT 0,
  loading_charges DECIMAL(10,2) DEFAULT 0,
  unloading_charges DECIMAL(10,2) DEFAULT 0,

  gst_type ENUM('cgst_sgst','igst','exempt') DEFAULT 'exempt',
  gst_rate DECIMAL(5,2) DEFAULT 0,
  gst_amount DECIMAL(10,2) DEFAULT 0,

  driver_extra_pay DECIMAL(10,2) DEFAULT 0,

  status ENUM('planned','in_progress','completed','cancelled') DEFAULT 'planned',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (truck_id) REFERENCES trucks(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id),
  FOREIGN KEY (consignee_id) REFERENCES consignees(id)
);

-- ============================================================
-- 7. TRIP EXPENSES
-- ============================================================
CREATE TABLE trip_expenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_id INT NOT NULL,
  expense_type ENUM('diesel','toll','rto','repair','driver_allowance','other') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  description VARCHAR(500),
  expense_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE
);

-- ============================================================
-- 8. INVOICES
-- ============================================================
CREATE TABLE invoices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  invoice_number VARCHAR(100) UNIQUE NOT NULL,
  invoice_date DATE NOT NULL,
  consignee_id INT,
  trip_ids JSON,
  subtotal DECIMAL(10,2) DEFAULT 0,
  gst_amount DECIMAL(10,2) DEFAULT 0,
  total_amount DECIMAL(10,2) DEFAULT 0,
  amount_paid DECIMAL(10,2) DEFAULT 0,
  payment_status ENUM('unpaid','partial','paid') DEFAULT 'unpaid',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (consignee_id) REFERENCES consignees(id)
);

-- ============================================================
-- 9. MAINTENANCE LOGS
-- ============================================================
CREATE TABLE maintenance_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  truck_id INT NOT NULL,
  log_type ENUM('servicing','fuel','repair','document','other') NOT NULL,
  description TEXT,
  cost DECIMAL(10,2) DEFAULT 0,
  odometer_reading INT,
  service_date DATE NOT NULL,
  next_service_date DATE,
  vendor_name VARCHAR(255),
  doc_type VARCHAR(100),
  doc_expiry DATE,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (truck_id) REFERENCES trucks(id) ON DELETE CASCADE
);

-- ============================================================
-- 10. TYRE LOGS
-- ============================================================
CREATE TABLE tyre_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  truck_id INT NOT NULL,
  position VARCHAR(10) NOT NULL,
  event_type ENUM('new_fit','removal','rotation') NOT NULL,
  event_date DATE NOT NULL,
  odometer_reading INT NOT NULL,
  tyre_brand VARCHAR(100),
  tyre_serial VARCHAR(100),
  tyre_size VARCHAR(50),
  purchase_cost DECIMAL(10,2) DEFAULT 0,
  km_run INT DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (truck_id) REFERENCES trucks(id) ON DELETE CASCADE
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Owner settings (edit this to match your client)
INSERT INTO settings (
  business_name, owner_name, gstin, pan, address, city, state,
  phone, bank_name, bank_account, bank_ifsc
) VALUES (
  'Mumbai Freight Carriers', 'Sagar', '27DAPPS1266E1ZF', 'DAPPS1266E',
  'Nigdi, Pune', 'Pune', 'Maharashtra',
  '9999999999', 'ICICI Bank', '000000000000', 'ICIC0002305'
);

-- Admin user (password: admin123)
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin', 'admin@mfc.com', '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhu.', 'admin');

-- Sample trucks
INSERT INTO trucks (truck_number, truck_type, wheel_count, make, model, year) VALUES
('MH12AB1234', '14-Wheeler Heavy', '14', 'Tata', 'Prima', 2020),
('MH12CD5678', '10-Wheeler Medium', '10', 'Ashok Leyland', 'U2523', 2021),
('MH14EF9012', '6-Wheeler Light', '6', 'Tata', '1109', 2019);

-- Sample drivers
INSERT INTO drivers (name, phone, license_number, license_expiry) VALUES
('Ramesh Patil', '9876543210', 'MH1420190012345', '2027-06-30'),
('Suresh Jadhav', '9876543211', 'MH1420200054321', '2026-12-31'),
('Mahesh Shinde', '9876543212', 'MH1420180098765', '2026-03-31');

-- Sample consignees
INSERT INTO consignees (name, gstin, city, state, phone) VALUES
('Reliance Industries Ltd', '27AAACR5055K1ZZ', 'Mumbai', 'Maharashtra', '9111111111'),
('Tata Steel Ltd', '21AAACT2727Q1ZV', 'Jamshedpur', 'Jharkhand', '9222222222'),
('Bajaj Auto Ltd', '27AAACB1866J1ZP', 'Pune', 'Maharashtra', '9333333333');
