import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './components/Toast';
import { ProtectedRoute, RoleRoute } from './components/RoleRoute';

import Layout      from './components/Layout';
import Login       from './pages/Login';
import Dashboard   from './pages/Dashboard';
import Trips       from './pages/Trips';
import Fleet       from './pages/Fleet';
import Drivers     from './pages/Drivers';
import Invoices    from './pages/Invoices';
import Consignees  from './pages/Consignees';
import Maintenance from './pages/Maintenance';
import Brokerage   from './pages/Brokerage';
import OwnerLedger from './pages/OwnerLedger';
import Analytics   from './pages/Analytics';
import AIAssistant from './pages/AIAssistant';
import Settings    from './pages/Settings';

const theme = createTheme({
  palette: {
    primary:    { main: '#1a2744' },
    secondary:  { main: '#2563eb' },
    background: { default: '#f0f2f7' },
  },
  typography: { fontFamily: 'Inter, sans-serif', fontSize: 13 },
  components: {
    MuiButton:    { styleOverrides: { root: { textTransform: 'none', borderRadius: 6, fontWeight: 500, fontSize: 12.5, boxShadow: 'none', '&:hover': { boxShadow: 'none' } } } },
    MuiCard:      { styleOverrides: { root: { borderRadius: 8, boxShadow: 'none', border: '0.5px solid #e2e6ef' } } },
    MuiTextField: { defaultProps: { size: 'small' } },
    MuiDialog:    { styleOverrides: { paper: { borderRadius: 10, boxShadow: '0 8px 32px rgba(0,0,0,0.12)' } } },
    MuiTableCell: { styleOverrides: {
      root: { fontSize: 12.5, padding: '8px 12px' },
      head: { fontSize: 11, fontWeight: 500, color: '#6b7a99', backgroundColor: '#fafbfc', borderBottom: '0.5px solid #e2e6ef' }
    }},
    MuiChip: { styleOverrides: { root: { fontSize: 11, height: 22 } } },
  }
});

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <ToastProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
                <Route index element={<Navigate to="/dashboard" replace />} />

                {/* All roles */}
                <Route path="dashboard"   element={<RoleRoute page="dashboard"><Dashboard /></RoleRoute>} />
                <Route path="fleet"       element={<RoleRoute page="fleet"><Fleet /></RoleRoute>} />
                <Route path="drivers"     element={<RoleRoute page="drivers"><Drivers /></RoleRoute>} />

                {/* admin + staff1 */}
                <Route path="trips"       element={<RoleRoute page="trips"><Trips /></RoleRoute>} />
                <Route path="consignees"  element={<RoleRoute page="consignees"><Consignees /></RoleRoute>} />

                {/* admin + staff2 */}
                <Route path="maintenance" element={<RoleRoute page="maintenance"><Maintenance /></RoleRoute>} />

                {/* admin only */}
                <Route path="invoices"    element={<RoleRoute page="invoices"><Invoices /></RoleRoute>} />
                <Route path="brokerage"   element={<RoleRoute page="brokerage"><Brokerage /></RoleRoute>} />
                <Route path="owners"      element={<RoleRoute page="owners"><OwnerLedger /></RoleRoute>} />
                <Route path="analytics"   element={<RoleRoute page="analytics"><Analytics /></RoleRoute>} />
                <Route path="ai"          element={<RoleRoute page="ai"><AIAssistant /></RoleRoute>} />
                <Route path="settings"    element={<RoleRoute page="settings"><Settings /></RoleRoute>} />
              </Route>
            </Routes>
          </BrowserRouter>
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
