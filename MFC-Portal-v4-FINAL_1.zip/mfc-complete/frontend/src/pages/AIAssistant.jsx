import React, { useState, useRef, useEffect } from 'react';
import { Box, Typography, CircularProgress, Alert } from '@mui/material';
import api from '../utils/api';

const HINTS = ['Revenue this month?','Most profitable route?','Expense summary','Brokerage commission MTD?','Which truck needs service?'];

export default function AIAssistant() {
  const [msgs, setMsgs]       = useState([{ role:'assistant', content:"Hello! I'm your MFC business assistant. Ask me about trips, revenue, fleet, or anything about your transport operations." }]);
  const [input, setInput]     = useState('');
  const [loading, setLoading] = useState(false);
  const [apiErr, setApiErr]   = useState('');
  const ref = useRef(null);
  useEffect(() => { ref.current?.scrollIntoView({ behavior:'smooth' }); }, [msgs]);

  const send = async text => {
    const msg = text || input.trim(); if (!msg) return;
    setInput(''); setApiErr('');
    const next = [...msgs, { role:'user', content: msg }];
    setMsgs(next); setLoading(true);
    try {
      const r = await api.post('/ai/chat', { message: msg, history: msgs.slice(-10) });
      setMsgs([...next, { role:'assistant', content: r.data.reply }]);
    } catch (e) {
      const err = e.response?.data?.error || 'AI unavailable';
      setApiErr(err);
      setMsgs([...next, { role:'assistant', content:`⚠️ ${err}` }]);
    } finally { setLoading(false); }
  };

  return (
    <Box sx={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', height:'calc(100vh - 100px)' }}>
      {/* Chat panel */}
      <Box sx={{ bgcolor:'#1a2744', borderRadius:'8px', p:'14px', display:'flex', flexDirection:'column' }}>
        <Typography sx={{ fontSize:13, fontWeight:500, color:'#fff', mb:1.5, display:'flex', alignItems:'center', gap:0.8 }}>
          🧠 AI business assistant
        </Typography>
        {apiErr.includes('configured') && (
          <Alert severity="warning" sx={{ mb:1, fontSize:11 }}>Add ANTHROPIC_API_KEY to backend/.env to enable AI</Alert>
        )}
        <Box sx={{ flex:1, overflowY:'auto', mb:1.5 }}>
          {msgs.map((m,i) => (
            <Box key={i} sx={{ bgcolor:'rgba(255,255,255,0.08)', borderRadius:'6px', p:'10px', fontSize:12, lineHeight:1.6, color:'rgba(255,255,255,0.85)', mb:1, ml: m.role==='user' ? 3 : 0, mr: m.role==='assistant' ? 3 : 0 }}>
              {m.content}
            </Box>
          ))}
          {loading && <Box sx={{ bgcolor:'rgba(255,255,255,0.05)', borderRadius:'6px', p:'10px', display:'flex', alignItems:'center', gap:1 }}><CircularProgress size={14} sx={{ color:'#fff' }} /><span style={{fontSize:12,color:'rgba(255,255,255,0.6)'}}>Thinking...</span></Box>}
          <div ref={ref} />
        </Box>
        <Box sx={{ display:'flex', gap:1 }}>
          <input
            value={input} onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&send()}
            placeholder="Ask anything about your business..."
            style={{ flex:1, padding:'7px 10px', border:'0.5px solid rgba(255,255,255,0.2)', borderRadius:'6px', background:'rgba(255,255,255,0.08)', color:'#fff', fontSize:12, outline:'none' }}
          />
          <button onClick={()=>send()} disabled={loading||!input.trim()} style={{ padding:'7px 14px', background:'#2563eb', color:'#fff', border:'none', borderRadius:'6px', cursor:'pointer', fontSize:12, opacity: loading||!input.trim() ? 0.6 : 1 }}>Send</button>
        </Box>
      </Box>

      {/* Quick insights */}
      <Box>
        <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'14px', mb:'12px' }}>
          <Typography sx={{ fontSize:12, fontWeight:500, color:'#6b7a99', mb:1.5 }}>Quick insights</Typography>
          {HINTS.map(h => (
            <Box key={h} onClick={() => send(h)} sx={{ py:'7px', borderBottom:'0.5px solid #e2e6ef', display:'flex', justifyContent:'space-between', alignItems:'center', cursor:'pointer', '&:hover':{ bgcolor:'#f8f9fc' }, '&:last-child':{ borderBottom:'none' } }}>
              <Typography sx={{ fontSize:12.5, color:'#6b7a99' }}>{h}</Typography>
              <Typography sx={{ fontSize:12, color:'#2563eb' }}>Ask →</Typography>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
}
