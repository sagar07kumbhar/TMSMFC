import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, TextField, Button, Typography, Alert, CircularProgress, InputAdornment, IconButton } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

export default function Login() {
  const [email, setEmail]         = useState('admin@mfc.com');
  const [password, setPassword]   = useState('admin123');
  const [showPass, setShowPass]   = useState(false);
  const [error, setError]         = useState('');
  const [loading, setLoading]     = useState(false);
  const [touched, setTouched]     = useState({});
  const { login } = useAuth();
  const showToast = useToast();
  const nav = useNavigate();

  const validate = () => {
    if (!email) return 'Email is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address';
    if (!password) return 'Password is required';
    if (password.length < 6) return 'Password must be at least 6 characters';
    return null;
  };

  const submit = async e => {
    e.preventDefault();
    setTouched({ email: true, password: true });
    const err = validate();
    if (err) { setError(err); return; }
    setLoading(true); setError('');
    try {
      await login(email, password);
      showToast('Welcome back! Login successful.', 'success');
      nav('/dashboard');
    } catch (e) {
      setError(e.response?.data?.error || 'Invalid email or password');
    } finally { setLoading(false); }
  };

  return (
    <Box sx={{
      minHeight: '100vh', display: 'flex',
      background: 'linear-gradient(135deg, #0f1f3d 0%, #1a2744 50%, #243156 100%)',
    }}>
      {/* Left panel - branding */}
      <Box sx={{
        flex: 1, display: { xs: 'none', md: 'flex' }, flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', p: 6
      }}>
        {/* Big truck illustration */}
        <svg width="320" height="200" viewBox="0 0 320 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Road */}
          <rect x="0" y="165" width="320" height="8" rx="2" fill="rgba(255,255,255,0.08)"/>
          <rect x="40" y="167" width="30" height="2" rx="1" fill="rgba(255,255,255,0.25)"/>
          <rect x="100" y="167" width="30" height="2" rx="1" fill="rgba(255,255,255,0.25)"/>
          <rect x="160" y="167" width="30" height="2" rx="1" fill="rgba(255,255,255,0.25)"/>
          <rect x="220" y="167" width="30" height="2" rx="1" fill="rgba(255,255,255,0.25)"/>
          {/* Truck body */}
          <rect x="20" y="90" width="180" height="75" rx="6" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.4)" strokeWidth="2"/>
          {/* Cargo panels on body */}
          <line x1="60" y1="95" x2="60" y2="155" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5"/>
          <line x1="100" y1="95" x2="100" y2="155" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5"/>
          <line x1="140" y1="95" x2="140" y2="155" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5"/>
          {/* MFC text on body */}
          <text x="110" y="132" textAnchor="middle" fill="rgba(255,255,255,0.6)" fontSize="18" fontWeight="700" fontFamily="Inter, sans-serif" letterSpacing="3">MFC</text>
          <text x="110" y="148" textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize="8" fontFamily="Inter, sans-serif" letterSpacing="2">MUMBAI FREIGHT</text>
          {/* Cab */}
          <path d="M200 105 L200 165 L290 165 L290 130 L265 105 Z" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.45)" strokeWidth="2" strokeLinejoin="round"/>
          {/* Windshield */}
          <path d="M205 110 L205 132 L282 132 L282 128 L260 110 Z" fill="rgba(255,255,255,0.25)" stroke="rgba(255,255,255,0.3)" strokeWidth="1"/>
          {/* Door line */}
          <line x1="240" y1="132" x2="240" y2="165" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5"/>
          {/* Door handle */}
          <rect x="248" y="148" width="10" height="3" rx="1.5" fill="rgba(255,255,255,0.4)"/>
          {/* Headlight */}
          <rect x="282" y="136" width="8" height="6" rx="2" fill="#FCD34D" opacity="0.9"/>
          {/* Headlight glow */}
          <ellipse cx="295" cy="139" rx="10" ry="5" fill="#FCD34D" opacity="0.15"/>
          {/* Exhaust pipe */}
          <rect x="265" y="80" width="6" height="28" rx="3" fill="rgba(255,255,255,0.2)" stroke="rgba(255,255,255,0.3)" strokeWidth="1"/>
          {/* Smoke puffs */}
          <circle cx="268" cy="76" r="5" fill="rgba(255,255,255,0.08)"/>
          <circle cx="272" cy="70" r="4" fill="rgba(255,255,255,0.06)"/>
          <circle cx="266" cy="65" r="3" fill="rgba(255,255,255,0.04)"/>
          {/* Front wheels */}
          <circle cx="248" cy="165" r="20" fill="#0f1f3d" stroke="rgba(255,255,255,0.5)" strokeWidth="2.5"/>
          <circle cx="248" cy="165" r="10" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5"/>
          <circle cx="248" cy="165" r="3" fill="rgba(255,255,255,0.5)"/>
          {/* Rear wheels */}
          <circle cx="80" cy="165" r="20" fill="#0f1f3d" stroke="rgba(255,255,255,0.5)" strokeWidth="2.5"/>
          <circle cx="80" cy="165" r="10" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5"/>
          <circle cx="80" cy="165" r="3" fill="rgba(255,255,255,0.5)"/>
          <circle cx="130" cy="165" r="20" fill="#0f1f3d" stroke="rgba(255,255,255,0.5)" strokeWidth="2.5"/>
          <circle cx="130" cy="165" r="10" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5"/>
          <circle cx="130" cy="165" r="3" fill="rgba(255,255,255,0.5)"/>
          {/* Speed lines */}
          <line x1="2" y1="110" x2="18" y2="110" stroke="rgba(255,255,255,0.3)" strokeWidth="2" strokeLinecap="round"/>
          <line x1="2" y1="120" x2="14" y2="120" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" strokeLinecap="round"/>
          <line x1="2" y1="130" x2="18" y2="130" stroke="rgba(255,255,255,0.3)" strokeWidth="2" strokeLinecap="round"/>
          <line x1="2" y1="140" x2="12" y2="140" stroke="rgba(255,255,255,0.15)" strokeWidth="1" strokeLinecap="round"/>
        </svg>

        <Typography variant="h4" sx={{ color: '#fff', fontWeight: 700, mt: 4, textAlign: 'center', letterSpacing: '-0.5px' }}>
          Mumbai Freight Carriers
        </Typography>
        <Typography sx={{ color: 'rgba(255,255,255,0.55)', mt: 1, fontSize: 15, textAlign: 'center' }}>
          Transport Management Portal
        </Typography>
        <Box sx={{ mt: 4, display: 'flex', gap: 3, flexWrap: 'wrap', justifyContent: 'center' }}>
          {['Fleet Management','Trip Tracking','Smart Analytics','AI Assistant'].map(f => (
            <Box key={f} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: '#60a5fa' }} />
              <Typography sx={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>{f}</Typography>
            </Box>
          ))}
        </Box>
      </Box>

      {/* Right panel - login form */}
      <Box sx={{
        width: { xs: '100%', md: 420 }, display: 'flex', alignItems: 'center',
        justifyContent: 'center', p: 4, bgcolor: 'rgba(255,255,255,0.03)',
        borderLeft: { md: '1px solid rgba(255,255,255,0.08)' }
      }}>
        <Box sx={{ width: '100%', maxWidth: 360 }}>
          {/* Logo */}
          <Box sx={{ mb: 4 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
              <Box sx={{ width: 40, height: 40, borderRadius: '10px', bgcolor: 'rgba(255,255,255,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,0.15)' }}>
                <svg width="26" height="26" viewBox="0 0 48 48" fill="none">
                  <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8"/>
                  <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round"/>
                  <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.45"/>
                  <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
                  <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
                  <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
                  <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
                  <rect x="41" y="27" width="3" height="2" rx="1" fill="#FCD34D"/>
                </svg>
              </Box>
              <Box>
                <Typography sx={{ color: '#fff', fontWeight: 700, fontSize: 16, lineHeight: 1.2 }}>MFC Portal</Typography>
                <Typography sx={{ color: 'rgba(255,255,255,0.45)', fontSize: 11 }}>Sign in to continue</Typography>
              </Box>
            </Box>
          </Box>

          {error && <Alert severity="error" sx={{ mb: 2.5, fontSize: 12, borderRadius: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={submit}>
            <Box mb={2}>
              <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, mb: 0.8, fontWeight: 500 }}>Email address</Typography>
              <TextField fullWidth value={email} onChange={e => setEmail(e.target.value)}
                onBlur={() => setTouched(t => ({ ...t, email: true }))}
                error={touched.email && !email}
                helperText={touched.email && !email ? 'Email is required' : ''}
                sx={{ '& .MuiOutlinedInput-root': { bgcolor: 'rgba(255,255,255,0.07)', borderRadius: '8px', color: '#fff', '& fieldset': { borderColor: 'rgba(255,255,255,0.15)' }, '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' }, '&.Mui-focused fieldset': { borderColor: '#60a5fa' } }, '& .MuiInputBase-input': { fontSize: 13 } }}
              />
            </Box>
            <Box mb={3}>
              <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, mb: 0.8, fontWeight: 500 }}>Password</Typography>
              <TextField fullWidth value={password} onChange={e => setPassword(e.target.value)}
                type={showPass ? 'text' : 'password'}
                onBlur={() => setTouched(t => ({ ...t, password: true }))}
                error={touched.password && !password}
                helperText={touched.password && !password ? 'Password is required' : ''}
                InputProps={{ endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setShowPass(!showPass)} edge="end" sx={{ color: 'rgba(255,255,255,0.4)' }}>
                      {showPass ? <VisibilityOff fontSize="small"/> : <Visibility fontSize="small"/>}
                    </IconButton>
                  </InputAdornment>
                )}}
                sx={{ '& .MuiOutlinedInput-root': { bgcolor: 'rgba(255,255,255,0.07)', borderRadius: '8px', color: '#fff', '& fieldset': { borderColor: 'rgba(255,255,255,0.15)' }, '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' }, '&.Mui-focused fieldset': { borderColor: '#60a5fa' } }, '& .MuiInputBase-input': { fontSize: 13 } }}
              />
            </Box>
            <Button type="submit" fullWidth variant="contained" disabled={loading}
              sx={{ py: 1.3, borderRadius: '8px', fontSize: 14, fontWeight: 600, bgcolor: '#2563eb', '&:hover': { bgcolor: '#1d4ed8' }, letterSpacing: '0.3px' }}>
              {loading ? <CircularProgress size={20} color="inherit"/> : 'Sign in'}
            </Button>
          </Box>

          <Typography sx={{ color: 'rgba(255,255,255,0.25)', fontSize: 11, mt: 3, textAlign: 'center' }}>
            GSTIN: 27DAPPS1266E1ZF · Nigdi, Pune
          </Typography>
        </Box>
      </Box>
    </Box>
  );
}
