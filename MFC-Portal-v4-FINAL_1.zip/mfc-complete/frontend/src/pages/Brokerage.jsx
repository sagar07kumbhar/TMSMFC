import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Chip } from '@mui/material';
import { Add } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';

const fmt  = n => `₹${(+n||0).toLocaleString('en-IN')}`;
const fmtL = n => { const v=+n||0; return v>=100000?`₹${(v/100000).toFixed(1)}L`:v>=1000?`₹${(v/1000).toFixed(0)}K`:`₹${v}`; };

const PAY_COLOR = { pending:'#fee2e2', advance_paid:'#fef9c3', settled:'#dcfce7' };
const PAY_TEXT  = { pending:'#991b1b', advance_paid:'#854d0e', settled:'#166534' };
const PAY_LABEL = { pending:'Pending', advance_paid:'Advance paid', settled:'Settled' };

function KpiCard({ label, value, sub, borderColor }) {
  return (
    <Box sx={{ bgcolor:'#fff', border:`0.5px solid ${borderColor||'#fcd34d'}`, borderRadius:'8px', p:'12px 14px' }}>
      <Typography sx={{ fontSize:11, color:'#92400e', mb:0.4 }}>{label}</Typography>
      <Typography sx={{ fontSize:20, fontWeight:500 }}>{value}</Typography>
      {sub && <Typography sx={{ fontSize:11, color:'#6b7a99', mt:0.3 }}>{sub}</Typography>}
    </Box>
  );
}

export default function Brokerage() {
  const [trips, setTrips]   = useState([]);
  const [stats, setStats]   = useState({ count:0, commission:0, pending:0, avgPct:0, ownRev:0 });
  const [routes, setRoutes] = useState([]);
  const nav = useNavigate();

  useEffect(() => {
    api.get('/trips?trip_type=brokerage&limit=50').then(r => {
      const list = r.data.data || [];
      setTrips(list);
      const count = list.length;
      const commission = list.reduce((s,t)=>s+(+t.commission_amount||0),0);
      const pending = list.filter(t=>t.broker_payment_status!=='settled').reduce((s,t)=>s+(+t.freight_amount-(+t.commission_amount||0)-(+t.broker_advance_paid||0)),0);
      const avgPct = count ? (list.reduce((s,t)=>s+(+t.commission_percent||0),0)/count).toFixed(1) : 0;
      setStats({ count, commission, pending:Math.max(0,pending), avgPct });

      // Route stats
      const rm = {};
      list.forEach(t => {
        const key = `${t.from_location}→${t.to_location}`;
        if (!rm[key]) rm[key] = { route:key, trips:0, commission:0 };
        rm[key].trips++;
        rm[key].commission += +t.commission_amount||0;
      });
      setRoutes(Object.values(rm).sort((a,b)=>b.commission-a.commission).slice(0,5));
    }).catch(()=>{});

    api.get('/trips?trip_type=owned&limit=1').then(r => {
      const total = r.data.total || 0;
      setStats(p=>({...p, ownCount:total}));
    }).catch(()=>{});
  }, []);

  const ownRev = 0; // would come from dashboard stats in real implementation

  return (
    <Box>
      {/* KPI cards — amber themed */}
      <Box sx={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'10px', mb:2 }}>
        <KpiCard label="Brokerage trips (total)" value={stats.count} sub="All time"/>
        <KpiCard label="Commission earned" value={fmtL(stats.commission)} sub="Your net earnings"/>
        <KpiCard label="Pending owner payouts" value={fmtL(stats.pending)} sub="Still to transfer" borderColor="#fca5a5"/>
        <KpiCard label="Avg commission %" value={`${stats.avgPct}%`} sub="Across all trips"/>
      </Box>

      <Box sx={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', mb:2 }}>
        {/* Top routes */}
        <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'14px' }}>
          <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:1.5 }}>Top brokerage routes by commission</Typography>
          {routes.length===0 && <Typography sx={{ fontSize:12, color:'#6b7a99' }}>No brokerage trips yet</Typography>}
          {routes.map((r,i) => (
            <Box key={r.route} sx={{ display:'flex', justifyContent:'space-between', alignItems:'center', py:'6px', borderBottom:i<routes.length-1?'0.5px solid #e2e6ef':'none' }}>
              <Box sx={{ display:'flex', alignItems:'center', gap:1 }}>
                <Box sx={{ width:6, height:6, borderRadius:'50%', bgcolor:'#f59e0b', flexShrink:0 }}/>
                <Typography sx={{ fontSize:12 }}>{r.route}</Typography>
              </Box>
              <Box sx={{ textAlign:'right' }}>
                <Typography sx={{ fontSize:12, fontWeight:500 }}>{fmt(r.commission)}</Typography>
                <Typography sx={{ fontSize:10, color:'#6b7a99' }}>{r.trips} trip{r.trips>1?'s':''}</Typography>
              </Box>
            </Box>
          ))}
        </Box>

        {/* Earnings note */}
        <Box sx={{ bgcolor:'#fffbeb', border:'0.5px solid #fcd34d', borderRadius:'8px', p:'14px' }}>
          <Typography sx={{ fontSize:11, fontWeight:500, color:'#92400e', mb:1.5 }}>How brokerage works</Typography>
          {[
            ['Collect freight from consignee','Full freight amount'],
            ['Your commission (deducted)','5% of freight'],
            ['Transfer to truck owner','Remainder amount'],
            ['Your expenses on brokerage','Zero — no diesel/toll/pay'],
            ['Your net earning','Commission amount only'],
          ].map(([l,v])=>(
            <Box key={l} sx={{ display:'flex', justifyContent:'space-between', py:'5px', borderBottom:'0.5px solid #fde68a', fontSize:12 }}>
              <span style={{ color:'#92400e' }}>{l}</span>
              <span style={{ color:'#78350f', fontWeight:500 }}>{v}</span>
            </Box>
          ))}
        </Box>
      </Box>

      {/* Brokerage trips table */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Box sx={{ p:'10px 14px', display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'0.5px solid #e2e6ef' }}>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Brokerage trips</Typography>
          <Button size="small" variant="contained" startIcon={<Add/>} onClick={()=>nav('/trips')}
            sx={{ bgcolor:'#f59e0b', '&:hover':{ bgcolor:'#d97706' }, fontSize:11.5 }}>
            New brokerage trip
          </Button>
        </Box>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {['LR No.','Date','Route','Owner','Truck','Freight','Commission','Owner payout','Status'].map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef', whiteSpace:'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {trips.map(t => (
              <tr key={t.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                <td style={{ padding:'9px 12px', fontSize:12, fontWeight:500 }}>{t.lr_number}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99' }}>{new Date(t.trip_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.from_location}→{t.to_location}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>
                  <div style={{ fontWeight:500 }}>{t.broker_owner_name}</div>
                  <div style={{ fontSize:10, color:'#6b7a99' }}>{t.broker_owner_phone}</div>
                </td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.broker_truck_number}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(t.freight_amount)}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#92400e', fontWeight:500 }}>
                  {fmt(t.commission_amount)}
                  <div style={{ fontSize:10, color:'#6b7a99' }}>{t.commission_percent}%</div>
                </td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>
                  <div>{fmt((+t.freight_amount||0)-(+t.commission_amount||0))}</div>
                  <div style={{ fontSize:10, color:'#6b7a99' }}>Adv: {fmt(t.broker_advance_paid)}</div>
                </td>
                <td style={{ padding:'9px 12px' }}>
                  <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500, background:PAY_COLOR[t.broker_payment_status]||'#fee2e2', color:PAY_TEXT[t.broker_payment_status]||'#991b1b' }}>
                    {PAY_LABEL[t.broker_payment_status]||'Pending'}
                  </span>
                </td>
              </tr>
            ))}
            {!trips.length && (
              <tr><td colSpan={9} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No brokerage trips yet. Add a brokerage trip from the Trips page.</td></tr>
            )}
          </tbody>
        </table>
      </Box>
    </Box>
  );
}
