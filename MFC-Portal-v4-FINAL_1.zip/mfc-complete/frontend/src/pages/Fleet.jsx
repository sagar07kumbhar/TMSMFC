import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Grid, LinearProgress, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Chip } from '@mui/material';
import { Add } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';
import usePermissions from '../hooks/usePermissions';
import { toDateStr, displayDate, daysUntil } from '../utils/dateUtils';

function DocBadge({ date }) {
  const days = daysUntil(date);
  if (days === null) return <span style={{ fontSize:10, color:'#9ca3af' }}>N/A</span>;
  if (days < 0)   return <span style={{ display:'inline-block', padding:'2px 6px', borderRadius:20, fontSize:10, fontWeight:500, background:'#fee2e2', color:'#991b1b' }}>Expired</span>;
  if (days <= 30) return <span style={{ display:'inline-block', padding:'2px 6px', borderRadius:20, fontSize:10, fontWeight:500, background:'#fef9c3', color:'#854d0e' }}>{days}d left</span>;
  return <span style={{ display:'inline-block', padding:'2px 6px', borderRadius:20, fontSize:10, fontWeight:500, background:'#dcfce7', color:'#166534' }}>Valid</span>;
}

export default function Fleet() {
  const [trucks, setTrucks] = useState([]);
  const [open, setOpen]     = useState(false);
  const [form, setForm]     = useState({});
  const [editing, setEditing] = useState(null);
  const showToast = useToast();
  const { can, isAdmin } = usePermissions();
  const showLoan = can('show_loan_emi');

  const load = () => api.get('/trucks').then(r => setTrucks(r.data || [])).catch(() => {});
  useEffect(() => { load(); }, []);

  const openForm = (t = null) => {
    setEditing(t?.id || null);
    if (t) {
      // Use toDateStr on ALL date fields to prevent -1 day bug
      setForm({
        ...t,
        rc_expiry:        toDateStr(t.rc_expiry),
        puc_expiry:       toDateStr(t.puc_expiry),
        fitness_expiry:   toDateStr(t.fitness_expiry),
        insurance_expiry: toDateStr(t.insurance_expiry),
        permit_expiry:    toDateStr(t.permit_expiry),
        loan_start_date:  toDateStr(t.loan_start_date),
      });
    } else {
      setForm({
        truck_number:'', truck_type:'', wheel_count:'10', make:'', model:'', year: new Date().getFullYear(),
        rc_expiry:'', puc_expiry:'', fitness_expiry:'', insurance_expiry:'', permit_expiry:'',
        loan_amount:'', loan_emi:'', loan_start_date:'', loan_tenure_months:'', loan_paid_emis:'',
      });
    }
    setOpen(true);
  };

  const save = async () => {
    if (!form.truck_number?.trim()) { showToast('Truck number is required', 'error'); return; }
    try {
      editing ? await api.put(`/trucks/${editing}`, form) : await api.post('/trucks', form);
      setOpen(false); load();
      showToast(editing ? 'Truck updated' : 'Truck added', 'success');
    } catch (e) { showToast(e.response?.data?.error || 'Failed to save', 'error'); }
  };

  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  return (
    <Box>
      <Box sx={{ display:'flex', justifyContent:'space-between', alignItems:'center', mb:2 }}>
        <Box>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Fleet management</Typography>
          <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{trucks.length} trucks registered</Typography>
        </Box>
        {isAdmin && (
          <Button variant="contained" size="small" startIcon={<Add/>} onClick={() => openForm()}
            sx={{ bgcolor:'#1a2744', fontSize:12 }}>Add truck</Button>
        )}
      </Box>

      <Grid container spacing={1.5}>
        {trucks.map(t => {
          const pct     = t.loan_tenure_months ? Math.min(100, ((t.loan_paid_emis || 0) / t.loan_tenure_months) * 100) : 100;
          const cleared = !t.loan_tenure_months || pct >= 100;
          return (
            <Grid item xs={12} md={6} lg={4} key={t.id}>
              <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'14px' }}>
                <Box sx={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', mb:1 }}>
                  <Box>
                    <Typography sx={{ fontSize:14, fontWeight:600 }}>{t.truck_number}</Typography>
                    <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{t.make} {t.model} {t.year ? `— ${t.year}` : ''} · {t.wheel_count}W</Typography>
                  </Box>
                  <Box sx={{ display:'flex', gap:1, alignItems:'center' }}>
                    <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500, background:'#dcfce7', color:'#166534' }}>Active</span>
                    {isAdmin && (
                      <button onClick={() => openForm(t)} style={{ border:'0.5px solid #e2e6ef', borderRadius:4, padding:'2px 8px', fontSize:10, cursor:'pointer', background:'#fff' }}>Edit</button>
                    )}
                  </Box>
                </Box>

                {/* Loan / EMI — admin only */}
                {showLoan && (
                  <Box sx={{ mb:1.5 }}>
                    <Box sx={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'#6b7a99', mb:0.5 }}>
                      <span>Loan EMI</span>
                      <span style={{ color: cleared ? '#16a34a' : '#374151', fontWeight: cleared ? 500 : 400 }}>
                        {cleared
                          ? 'Cleared ✓'
                          : `₹${(+t.loan_emi || 0).toLocaleString('en-IN')}/mo · ${(t.loan_tenure_months || 0) - (t.loan_paid_emis || 0)} EMIs left`}
                      </span>
                    </Box>
                    <LinearProgress variant="determinate" value={pct}
                      sx={{ height:5, borderRadius:3, bgcolor:'#e2e8f0',
                        '& .MuiLinearProgress-bar':{ bgcolor: cleared ? '#16a34a' : '#2563eb' } }}/>
                  </Box>
                )}

                {!showLoan && (
                  <Box sx={{ mb:1.5 }}>
                    <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:4, fontSize:11, background:'#f1f5f9', color:'#475569' }}>
                      {t.truck_type || `${t.wheel_count}-Wheeler`}
                    </span>
                  </Box>
                )}

                {/* Document badges */}
                <Box sx={{ display:'flex', gap:'8px', flexWrap:'wrap' }}>
                  {[['RC', t.rc_expiry],['PUC', t.puc_expiry],['Fitness', t.fitness_expiry],['Ins.', t.insurance_expiry],['Permit', t.permit_expiry]].map(([label, date]) => (
                    <Box key={label} sx={{ display:'flex', alignItems:'center', gap:'3px' }}>
                      <span style={{ fontSize:10, color:'#6b7a99', fontWeight:500 }}>{label}</span>
                      <DocBadge date={date}/>
                    </Box>
                  ))}
                </Box>
              </Box>
            </Grid>
          );
        })}
        {!trucks.length && (
          <Grid item xs={12}>
            <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'32px', textAlign:'center', color:'#6b7a99', fontSize:13 }}>
              No trucks added yet.{isAdmin ? ' Click "+ Add truck" to get started.' : ''}
            </Box>
          </Grid>
        )}
      </Grid>

      {/* Add/Edit dialog */}
      {isAdmin && (
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>{editing ? 'Edit Truck' : 'Add Truck'}</DialogTitle>
          <DialogContent sx={{ pt:1 }}>
            <Grid container spacing={1.5} sx={{ mt:0.5 }}>
              <Grid item xs={6}><TextField label="Truck Number *" fullWidth value={form.truck_number||''} onChange={e => f('truck_number', e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="Truck Type" fullWidth value={form.truck_type||''} onChange={e => f('truck_type', e.target.value)} placeholder="e.g. 14-Wheeler Heavy"/></Grid>
              <Grid item xs={4}><TextField select label="Wheels" fullWidth value={form.wheel_count||'10'} onChange={e => f('wheel_count', e.target.value)}>
                {['4','6','10','14'].map(w => <MenuItem key={w} value={w}>{w} Wheeler</MenuItem>)}
              </TextField></Grid>
              <Grid item xs={4}><TextField label="Make" fullWidth value={form.make||''} onChange={e => f('make', e.target.value)} placeholder="e.g. Tata"/></Grid>
              <Grid item xs={4}><TextField label="Model" fullWidth value={form.model||''} onChange={e => f('model', e.target.value)} placeholder="e.g. Prima"/></Grid>
              <Grid item xs={4}><TextField label="Year" type="number" fullWidth value={form.year||''} onChange={e => f('year', e.target.value)}/></Grid>

              <Grid item xs={12}><Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mt:0.5 }}>Document expiry dates</Typography></Grid>
              <Grid item xs={4}><TextField label="RC Expiry" type="date" fullWidth value={form.rc_expiry||''} onChange={e => f('rc_expiry', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>
              <Grid item xs={4}><TextField label="PUC Expiry" type="date" fullWidth value={form.puc_expiry||''} onChange={e => f('puc_expiry', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>
              <Grid item xs={4}><TextField label="Fitness Expiry" type="date" fullWidth value={form.fitness_expiry||''} onChange={e => f('fitness_expiry', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>
              <Grid item xs={4}><TextField label="Insurance Expiry" type="date" fullWidth value={form.insurance_expiry||''} onChange={e => f('insurance_expiry', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>
              <Grid item xs={4}><TextField label="Permit Expiry" type="date" fullWidth value={form.permit_expiry||''} onChange={e => f('permit_expiry', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>

              <Grid item xs={12}><Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mt:0.5 }}>Loan / EMI details</Typography></Grid>
              <Grid item xs={6}><TextField label="Loan Amount ₹" type="number" fullWidth value={form.loan_amount||''} onChange={e => f('loan_amount', e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="EMI ₹/month" type="number" fullWidth value={form.loan_emi||''} onChange={e => f('loan_emi', e.target.value)}/></Grid>
              <Grid item xs={4}><TextField label="Loan start date" type="date" fullWidth value={form.loan_start_date||''} onChange={e => f('loan_start_date', e.target.value)} InputLabelProps={{ shrink:true }}/></Grid>
              <Grid item xs={4}><TextField label="Tenure (months)" type="number" fullWidth value={form.loan_tenure_months||''} onChange={e => f('loan_tenure_months', e.target.value)}/></Grid>
              <Grid item xs={4}><TextField label="EMIs paid" type="number" fullWidth value={form.loan_paid_emis||''} onChange={e => f('loan_paid_emis', e.target.value)}/></Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ px:3, pb:2 }}>
            <Button onClick={() => setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
            <Button variant="contained" onClick={save} sx={{ bgcolor:'#1a2744' }}>Save truck</Button>
          </DialogActions>
        </Dialog>
      )}
    </Box>
  );
}
