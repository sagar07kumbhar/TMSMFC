import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Dialog, DialogTitle, DialogContent, Chip } from '@mui/material';
import { Print, Visibility } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';

const PAY_COLOR = { unpaid:'error', partial:'warning', paid:'success' };
const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;

function amountToWords(n) {
  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
  if (n === 0) return 'Zero';
  if (n < 20) return ones[n];
  if (n < 100) return tens[Math.floor(n/10)] + (n%10?' '+ones[n%10]:'');
  if (n < 1000) return ones[Math.floor(n/100)]+' Hundred'+(n%100?' '+amountToWords(n%100):'');
  if (n < 100000) return amountToWords(Math.floor(n/1000))+' Thousand'+(n%1000?' '+amountToWords(n%1000):'');
  if (n < 10000000) return amountToWords(Math.floor(n/100000))+' Lakh'+(n%100000?' '+amountToWords(n%100000):'');
  return amountToWords(Math.floor(n/10000000))+' Crore'+(n%10000000?' '+amountToWords(n%10000000):'');
}

function InvoicePrint({ inv, onClose }) {
  if (!inv) return null;
  const trips = inv.trips || [];
  const words = amountToWords(Math.round(+inv.total_amount));

  return (
    <div style={{ padding: 24, maxWidth: 720, margin: '0 auto', fontFamily: 'Arial, sans-serif', fontSize: 12 }}>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', paddingBottom:12, borderBottom:'2px solid #1a2744', marginBottom:14 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:50, height:50, borderRadius:'50%', background:'#1a2744', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width="32" height="32" viewBox="0 0 48 48" fill="none">
              <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8"/>
              <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round"/>
              <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.45"/>
              <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
              <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
              <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
              <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
            </svg>
          </div>
          <div>
            <div style={{ fontSize:16, fontWeight:700, color:'#1a2744' }}>Mumbai Freight Carriers</div>
            <div style={{ fontSize:10, color:'#6b7a99' }}>Nigdi, Pune — Subject to Pune Jurisdiction</div>
            <div style={{ fontSize:10, color:'#6b7a99' }}>GSTIN: 27DAPPS1266E1ZF | PAN: DAPPS1266E</div>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:11, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.05em' }}>Tax Invoice</div>
          <div style={{ fontSize:16, fontWeight:700, color:'#1a2744', marginTop:4 }}>{inv.invoice_number}</div>
          <div style={{ fontSize:11, color:'#6b7a99' }}>Date: {new Date(inv.invoice_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>
        </div>
      </div>

      {/* Bill to + Bank */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:14 }}>
        <div>
          <div style={{ fontSize:10, color:'#6b7a99', textTransform:'uppercase', marginBottom:4 }}>Bill to</div>
          <div style={{ fontWeight:600 }}>M/s. {inv.consignee_name}</div>
          {inv.consignee_address && <div style={{ color:'#6b7a99' }}>{inv.consignee_address}, {inv.consignee_city}</div>}
          {inv.consignee_gstin && <div style={{ color:'#6b7a99' }}>GSTIN: {inv.consignee_gstin}</div>}
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:10, color:'#6b7a99', textTransform:'uppercase', marginBottom:4 }}>Bank details</div>
          <div>ICICI Bank, Nigdi Branch</div>
          <div style={{ color:'#6b7a99' }}>A/c: 000000000000</div>
          <div style={{ color:'#6b7a99' }}>IFSC: ICIC0002305</div>
        </div>
      </div>

      {/* Trip table */}
      <table style={{ width:'100%', borderCollapse:'collapse', marginBottom:12, fontSize:11 }}>
        <thead>
          <tr style={{ background:'#1a2744', color:'#fff' }}>
            {['Trip No.','Date','LR No.','Vehicle No.','From','To','Weight','Rate','Advance','Amount'].map(h=>(
              <th key={h} style={{ padding:'6px 8px', textAlign:'left', fontWeight:500 }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {trips.length > 0 ? trips.map((t,i) => (
            <tr key={i} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
              <td style={{ padding:'6px 8px' }}>{i+1}</td>
              <td style={{ padding:'6px 8px' }}>{require('../utils/dateUtils').displayDate(t.trip_date, {day:'2-digit',month:'short'})}</td>
              <td style={{ padding:'6px 8px', fontWeight:500 }}>{t.lr_number}</td>
              <td style={{ padding:'6px 8px' }}>{t.truck_number}</td>
              <td style={{ padding:'6px 8px' }}>{t.from_location}</td>
              <td style={{ padding:'6px 8px' }}>{t.to_location}</td>
              <td style={{ padding:'6px 8px' }}>{t.weight_tons}T</td>
              <td style={{ padding:'6px 8px' }}>{fmt(t.freight_amount)}</td>
              <td style={{ padding:'6px 8px' }}>{fmt(t.advance_paid)}</td>
              <td style={{ padding:'6px 8px', fontWeight:500 }}>{fmt(t.freight_amount)}</td>
            </tr>
          )) : (
            <tr><td colSpan={10} style={{ padding:'12px 8px', color:'#6b7a99', textAlign:'center' }}>Trip details not available</td></tr>
          )}
        </tbody>
      </table>

      {/* Totals + charges */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:12 }}>
        <div>
          <div style={{ fontSize:10, color:'#6b7a99', textTransform:'uppercase', marginBottom:6 }}>Additional charges</div>
          <table style={{ width:'100%', fontSize:11 }}>
            {[['Detention charges','₹0'],['Kata charges','₹0'],['Loading/Unloading','₹0']].map(([l,v])=>(
              <tr key={l}><td style={{ color:'#6b7a99', padding:'2px 0' }}>{l}</td><td style={{ textAlign:'right' }}>{v}</td></tr>
            ))}
          </table>
          <div style={{ marginTop:8, fontSize:10, color:'#6b7a99' }}>
            GST as applicable | PAN: DAPPS1266E
          </div>
          <div style={{ marginTop:6, fontSize:11, fontStyle:'italic', color:'#444' }}>
            Amount in words: {words} Rupees Only
          </div>
        </div>
        <div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <tr style={{ borderBottom:'0.5px solid #e2e6ef' }}><td style={{ padding:'4px 8px', color:'#6b7a99' }}>Subtotal</td><td style={{ padding:'4px 8px', textAlign:'right' }}>{fmt(inv.subtotal)}</td></tr>
            {+inv.gst_amount > 0 && (
              <>
                <tr><td style={{ padding:'4px 8px', color:'#6b7a99' }}>CGST (9%)</td><td style={{ padding:'4px 8px', textAlign:'right' }}>{fmt(+inv.gst_amount/2)}</td></tr>
                <tr><td style={{ padding:'4px 8px', color:'#6b7a99' }}>SGST (9%)</td><td style={{ padding:'4px 8px', textAlign:'right' }}>{fmt(+inv.gst_amount/2)}</td></tr>
              </>
            )}
            <tr style={{ background:'#f8fafc', fontWeight:600 }}><td style={{ padding:'6px 8px' }}>Total amount</td><td style={{ padding:'6px 8px', textAlign:'right', color:'#1a2744', fontSize:13 }}>{fmt(inv.total_amount)}</td></tr>
            <tr><td style={{ padding:'4px 8px', color:'#6b7a99' }}>Total advance received</td><td style={{ padding:'4px 8px', textAlign:'right' }}>{fmt(inv.amount_paid)}</td></tr>
            <tr style={{ fontWeight:600 }}><td style={{ padding:'6px 8px', color:'#d97706' }}>Balance due</td><td style={{ padding:'6px 8px', textAlign:'right', color:'#d97706', fontSize:13 }}>{fmt(+inv.total_amount - +inv.amount_paid)}</td></tr>
          </table>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16, paddingTop:12, borderTop:'0.5px solid #e2e6ef' }}>
        <div style={{ fontSize:10, color:'#6b7a99' }}>This is a computer generated invoice</div>
        <div style={{ textAlign:'center' }}>
          <div style={{ fontSize:10, color:'#6b7a99', marginBottom:28 }}>For Mumbai Freight Carriers Pune</div>
          <div style={{ fontSize:11, fontWeight:600, borderTop:'0.5px solid #444', paddingTop:4, minWidth:160 }}>Authorised Signatory</div>
        </div>
      </div>

      <div style={{ display:'flex', gap:8, marginTop:16 }} className="no-print">
        <button onClick={() => window.print()} style={{ padding:'7px 16px', background:'#1a2744', color:'#fff', border:'none', borderRadius:6, cursor:'pointer', fontSize:13 }}>Print</button>
        <button onClick={onClose} style={{ padding:'7px 16px', background:'transparent', border:'0.5px solid #e2e6ef', borderRadius:6, cursor:'pointer', fontSize:13 }}>Close</button>
      </div>
    </div>
  );
}

export default function Invoices() {
  const [list, setList]       = useState([]);
  const [selected, setSelected] = useState(null);
  const [viewOpen, setViewOpen] = useState(false);
  const showToast = useToast();

  useEffect(() => { api.get('/invoices').then(r => setList(r.data)); }, []);

  const view = async id => {
    try {
      const r = await api.get(`/invoices/${id}`);
      setSelected(r.data);
      setViewOpen(true);
    } catch { showToast('Failed to load invoice', 'error'); }
  };

  const markPaid = async id => {
    try {
      const inv = list.find(i => i.id === id);
      await api.put(`/invoices/${id}/payment`, { amount_paid: inv.total_amount });
      const r = await api.get('/invoices'); setList(r.data);
      showToast('Invoice marked as paid', 'success');
    } catch { showToast('Failed to update', 'error'); }
  };

  return (
    <Box>
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Box sx={{ p:'10px 14px', display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'0.5px solid #e2e6ef' }}>
          <Box>
            <Typography sx={{ fontSize:13, fontWeight:500 }}>Invoices</Typography>
            <Typography sx={{ fontSize:11, color:'#6b7a99' }}>Auto-generated when a trip is saved</Typography>
          </Box>
        </Box>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {['Invoice no.','Date','Consignee','Trips','Amount','GST','Total','Status','Actions'].map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {list.map(inv => (
              <tr key={inv.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                <td style={{ padding:'9px 12px', fontSize:12, fontWeight:500 }}>{inv.invoice_number}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99' }}>{new Date(inv.invoice_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{inv.consignee_name||'—'}</td>
                <td style={{ padding:'9px 12px', fontSize:12, textAlign:'center' }}>
                  {inv.trip_ids ? JSON.parse(inv.trip_ids).length : 0}
                </td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(inv.subtotal)}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(inv.gst_amount)}</td>
                <td style={{ padding:'9px 12px', fontSize:12, fontWeight:500 }}>{fmt(inv.total_amount)}</td>
                <td style={{ padding:'9px 12px' }}>
                  <Chip label={inv.payment_status} size="small" color={PAY_COLOR[inv.payment_status]}/>
                </td>
                <td style={{ padding:'9px 12px', whiteSpace:'nowrap' }}>
                  <button onClick={()=>view(inv.id)} style={{ marginRight:5, padding:'2px 8px', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:10, cursor:'pointer', background:'#fff', color:'inherit' }}>View</button>
                  {inv.payment_status !== 'paid' && (
                    <button onClick={()=>markPaid(inv.id)} style={{ padding:'2px 8px', border:'0.5px solid #16a34a', borderRadius:4, fontSize:10, cursor:'pointer', background:'#fff', color:'#16a34a' }}>Mark paid</button>
                  )}
                </td>
              </tr>
            ))}
            {!list.length&&<tr><td colSpan={9} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No invoices yet. Save a trip to auto-generate one.</td></tr>}
          </tbody>
        </table>
      </Box>

      <Dialog open={viewOpen} onClose={()=>setViewOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ p:0 }} />
        <DialogContent sx={{ p: 0 }}>
          <InvoicePrint inv={selected} onClose={()=>setViewOpen(false)}/>
        </DialogContent>
      </Dialog>

      <style>{`@media print { .no-print { display: none !important; } }`}</style>
    </Box>
  );
}
