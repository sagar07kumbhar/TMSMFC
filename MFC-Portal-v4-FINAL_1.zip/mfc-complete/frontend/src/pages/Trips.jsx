import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Typography, Button, CircularProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, MenuItem, Grid, Alert, IconButton
} from '@mui/material';
import { Add, Delete, LockOutlined, Refresh } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';
import usePermissions from '../hooks/usePermissions';
import { toDateStr, displayDate, todayStr } from '../utils/dateUtils';

// ── helpers ───────────────────────────────────────────────────────────────────
const fmt  = n => `₹${(+n || 0).toLocaleString('en-IN')}`;
const num  = v => isNaN(+v) ? 0 : +v;

const STATUS_COLORS = {
  planned:     { bg:'#f1f5f9', color:'#475569' },
  in_progress: { bg:'#dbeafe', color:'#1e40af' },
  completed:   { bg:'#dcfce7', color:'#166534' },
  cancelled:   { bg:'#fee2e2', color:'#991b1b' },
};

const EXPENSE_TYPES = [
  { value:'diesel',           label:'Diesel' },
  { value:'toll',             label:'Toll' },
  { value:'rto',              label:'RTO / Border' },
  { value:'repair',           label:'Breakdown / Repair' },
  { value:'driver_allowance', label:'Driver allowance' },
  { value:'other',            label:'Other' },
];

const BLANK_OWNED = () => ({
  trip_type:'owned', trip_number:'', lr_number:'', trip_date: todayStr(),
  truck_id:'', driver_id:'', consignee_id:'',
  from_location:'', to_location:'', distance_km:'', weight_tons:'',
  freight_amount:'', advance_paid:'', balance_due:'',
  detention_charges:'', kata_charges:'', loading_charges:'', unloading_charges:'',
  gst_type:'exempt', gst_rate:'', status:'planned', notes:'',
});

const BLANK_BROKER = () => ({
  trip_type:'brokerage', trip_number:'', lr_number:'', trip_date: todayStr(),
  broker_owner_name:'', broker_owner_phone:'', broker_truck_number:'', broker_driver_name:'',
  commission_percent: 5, broker_advance_paid:'', broker_payment_status:'pending',
  consignee_id:'', from_location:'', to_location:'', distance_km:'', weight_tons:'',
  freight_amount:'', advance_paid:'', balance_due:'',
  gst_type:'exempt', gst_rate:'', status:'planned', notes:'',
});

// ── Validation ────────────────────────────────────────────────────────────────
function validate(form) {
  const e = {};
  if (!form.lr_number?.trim())      e.lr_number      = 'LR number required';
  if (!form.trip_date)              e.trip_date      = 'Date required';
  if (!form.from_location?.trim())  e.from_location  = 'From location required';
  if (!form.to_location?.trim())    e.to_location    = 'To location required';
  if (!form.freight_amount || num(form.freight_amount) <= 0)
                                    e.freight_amount = 'Freight amount required';
  if (form.trip_type === 'owned') {
    if (!form.truck_id)  e.truck_id  = 'Select a truck';
    if (!form.driver_id) e.driver_id = 'Select a driver';
  }
  if (form.trip_type === 'brokerage') {
    if (!form.broker_owner_name?.trim())
      e.broker_owner_name   = 'Owner name is required';
    if (!form.broker_owner_phone?.trim())
      e.broker_owner_phone  = 'Owner phone is required';
    else if (!/^[6-9]\d{9}$/.test(form.broker_owner_phone.trim()))
      e.broker_owner_phone  = 'Enter valid 10-digit mobile';
    if (!form.broker_truck_number?.trim())
      e.broker_truck_number = 'Truck number required';
    if (!form.commission_percent || num(form.commission_percent) <= 0)
      e.commission_percent  = 'Commission % required';
  }
  return e;
}

const Badge = ({ label, bg, color }) => (
  <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500, background:bg||'#f1f5f9', color:color||'#475569' }}>{label}</span>
);

function Row({ label, value, valueColor, bold }) {
  return (
    <Box sx={{ display:'flex', justifyContent:'space-between', py:'4px', fontSize: bold ? 14 : 12 }}>
      <span style={{ color:'rgba(255,255,255,0.6)' }}>{label}</span>
      <span style={{ color: valueColor || '#fff', fontWeight: bold ? 700 : 400 }}>{value}</span>
    </Box>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
export default function Trips() {
  const [trips, setTrips]           = useState([]);
  const [trucks, setTrucks]         = useState([]);
  const [drivers, setDrivers]       = useState([]);
  const [consignees, setConsignees] = useState([]);
  const [filter, setFilter]         = useState('all');
  const [open, setOpen]             = useState(false);
  const [form, setForm]             = useState(BLANK_OWNED());
  const [expenses, setExpenses]     = useState([]);
  const [activeTab, setActiveTab]   = useState('owned');
  const [editing, setEditing]       = useState(null);
  const [lrLoading, setLrLoading]   = useState(false);
  const [saving, setSaving]         = useState(false);
  const [errors, setErrors]         = useState({});
  const [touched, setTouched]       = useState({});
  const showToast = useToast();
  const { can, isAdmin, isStaff1 } = usePermissions();

  const showFreightInList = can('show_freight_in_list');
  const showFreightInForm = can('show_freight_amount');
  const canDelete         = can('can_delete_trip');

  // ── load ──────────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    try { const r = await api.get('/trips?limit=500'); setTrips(r.data.data || []); } catch {}
  }, []);

  useEffect(() => {
    load();
    api.get('/trucks').then(r => setTrucks(r.data || [])).catch(() => {});
    api.get('/drivers').then(r => setDrivers(r.data || [])).catch(() => {});
    api.get('/consignees').then(r => setConsignees(r.data || [])).catch(() => {});
  }, []);

  // ── open form ─────────────────────────────────────────────────────────────
  const openForm = async (trip = null, type = 'owned') => {
    setErrors({}); setTouched({});
    if (trip) {
      setEditing(trip.id);
      setActiveTab(trip.trip_type || 'owned');
      setForm({
        ...trip,
        trip_date:             toDateStr(trip.trip_date),
        truck_id:              trip.truck_id     ? String(trip.truck_id)     : '',
        driver_id:             trip.driver_id    ? String(trip.driver_id)    : '',
        consignee_id:          trip.consignee_id ? String(trip.consignee_id) : '',
        freight_amount:        trip.freight_amount     ?? '',
        advance_paid:          trip.advance_paid       ?? '',
        balance_due:           trip.balance_due        ?? '',
        detention_charges:     trip.detention_charges  ?? '',
        kata_charges:          trip.kata_charges       ?? '',
        loading_charges:       trip.loading_charges    ?? '',
        unloading_charges:     trip.unloading_charges  ?? '',
        distance_km:           trip.distance_km        ?? '',
        weight_tons:           trip.weight_tons        ?? '',
        broker_advance_paid:   trip.broker_advance_paid ?? '',
        commission_percent:    trip.commission_percent ?? 5,
        broker_owner_phone:    trip.broker_owner_phone || '',
        gst_rate:              trip.gst_rate ?? '',
      });
      // Load existing expenses
      try {
        const r = await api.get(`/trip-expenses?trip_id=${trip.id}`);
        setExpenses((r.data || []).map(e => ({
          ...e, expense_date: toDateStr(e.expense_date),
        })));
      } catch { setExpenses([]); }
    } else {
      setEditing(null); setExpenses([]);
      setActiveTab(type);
      setLrLoading(true);
      let lr_number = '';
      try { const r = await api.get('/trips/next-lr'); lr_number = r.data.lr_number; } catch {}
      finally { setLrLoading(false); }
      const blank = type === 'owned' ? BLANK_OWNED() : BLANK_BROKER();
      setForm({ ...blank, trip_number: `TRIP-${Date.now().toString().slice(-6)}`, lr_number });
    }
    setOpen(true);
  };

  const switchTab = t => {
    setActiveTab(t); setErrors({}); setTouched({}); setExpenses([]);
    const blank = t === 'owned' ? BLANK_OWNED() : BLANK_BROKER();
    setForm(p => ({ ...blank, trip_number: p.trip_number, lr_number: p.lr_number, trip_date: p.trip_date, consignee_id: p.consignee_id }));
  };

  // ── field helpers ─────────────────────────────────────────────────────────
  const f = (k, v) => {
    setForm(p => {
      const updated = { ...p, [k]: v };
      // Auto-recalculate balance_due whenever freight or advance changes
      if (k === 'freight_amount' || k === 'advance_paid') {
        const fr  = +(updated.freight_amount) || 0;
        const adv = +(updated.advance_paid)   || 0;
        updated.balance_due = Math.max(0, fr - adv);
      }
      return updated;
    });
    if (touched[k]) setErrors(validate({ ...form, [k]: v }));
  };
  const blur = k => { setTouched(p => ({ ...p, [k]: true })); setErrors(validate(form)); };

  // ── expense rows ──────────────────────────────────────────────────────────
  const addExp    = () => setExpenses(p => [...p, { expense_type:'diesel', amount:'', description:'', expense_date: toDateStr(form.trip_date) }]);
  const updExp    = (i, k, v) => setExpenses(p => p.map((e, idx) => idx === i ? { ...e, [k]: v } : e));
  const delExp    = i => setExpenses(p => p.filter((_, idx) => idx !== i));
  const totalExp  = expenses.reduce((s, e) => s + num(e.amount), 0);

  // ── live calc ─────────────────────────────────────────────────────────────
  const ownedCalc = () => {
    const fr  = num(form.freight_amount);
    const det = num(form.detention_charges) + num(form.kata_charges)
              + num(form.loading_charges) + num(form.unloading_charges);
    const ext = totalExp;
    const drv = num(form.distance_km) * 5;
    return { fr, det, ext, drv, net: fr - det - ext - drv, due: fr - num(form.advance_paid) };
  };

  const brokerCalc = () => {
    const fr   = num(form.freight_amount);
    const pct  = num(form.commission_percent);
    const comm = +(fr * pct / 100).toFixed(2);
    const owed = fr - comm;
    return {
      fr, pct, comm, owed,
      due:      fr - num(form.advance_paid),
      ownerRem: owed - num(form.broker_advance_paid),
    };
  };

  // ── save ──────────────────────────────────────────────────────────────────
  const save = async () => {
    const at = {}; Object.keys(form).forEach(k => at[k] = true); setTouched(at);
    const errs = validate(form); setErrors(errs);
    if (Object.keys(errs).length > 0) {
      showToast('Please fix the highlighted errors before saving', 'error');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        // Only send expenses for owned trips
        expenses: form.trip_type === 'owned' ? expenses.filter(e => num(e.amount) > 0) : [],
      };
      const res = editing
        ? await api.put(`/trips/${editing}`, payload)
        : await api.post('/trips', payload);

      setOpen(false);
      await load(); // refresh list immediately

      if (!editing) {
        if (res.data?.invoice_number) {
          const msg = form.trip_type === 'brokerage'
            ? `Brokerage trip saved! Invoice ${res.data.invoice_number} generated for consignee + owner ledger entry created`
            : `Trip saved! Invoice ${res.data.invoice_number} auto-generated`;
          showToast(msg, 'success');
        } else {
          showToast('Trip saved successfully', 'success');
        }
      } else {
        showToast('Trip updated — all linked data refreshed', 'success');
      }
    } catch (e) {
      showToast(e.response?.data?.error || 'Failed to save trip. Check console for details.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const del = async id => {
    if (!confirm('Delete this trip? The linked invoice will also be removed.')) return;
    try { await api.delete(`/trips/${id}`); await load(); showToast('Trip deleted', 'info'); }
    catch { showToast('Failed to delete', 'error'); }
  };

  // ── filtered list ─────────────────────────────────────────────────────────
  const filtered = filter === 'all' ? trips : trips.filter(t => t.trip_type === filter);

  const cols = [
    'LR No.', 'Date', 'Route', 'Type', 'Vehicle', 'Consignee',
    ...(showFreightInList ? ['Freight', 'Advance', 'Balance'] : []),
    'Status', '',
  ];

  // ── render ────────────────────────────────────────────────────────────────
  return (
    <Box>
      {/* Top bar */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px 8px 0 0', border:'0.5px solid #e2e6ef', borderBottom:'none', p:'10px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <Box sx={{ display:'flex', gap:1 }}>
          {['all','owned','brokerage'].map(v => (
            <Button key={v} size="small" variant={filter===v?'contained':'outlined'} onClick={() => setFilter(v)}
              sx={{ fontSize:11.5, py:0.4, minWidth:60, bgcolor:filter===v?'#1a2744':'transparent', borderColor:'#e2e6ef', color:filter===v?'#fff':'#6b7a99' }}>
              {v === 'all' ? `All (${trips.length})` : `${v.charAt(0).toUpperCase()}${v.slice(1)} (${trips.filter(t=>t.trip_type===v).length})`}
            </Button>
          ))}
          <IconButton size="small" onClick={load} title="Refresh" sx={{ color:'#6b7a99' }}><Refresh fontSize="small"/></IconButton>
        </Box>
        <Box sx={{ display:'flex', gap:1 }}>
          <Button size="small" variant="outlined" startIcon={<Add/>} onClick={() => openForm(null, 'owned')}
            sx={{ fontSize:11.5, borderColor:'#2563eb', color:'#2563eb' }}>Own trip</Button>
          {isAdmin && (
            <Button size="small" variant="contained" startIcon={<Add/>} onClick={() => openForm(null, 'brokerage')}
              sx={{ fontSize:11.5, bgcolor:'#f59e0b', '&:hover':{ bgcolor:'#d97706' } }}>Brokerage trip</Button>
          )}
        </Box>
      </Box>

      {isStaff1 && (
        <Box sx={{ bgcolor:'#eff6ff', border:'0.5px solid #bfdbfe', borderTop:'none', p:'7px 14px', display:'flex', alignItems:'center', gap:1 }}>
          <LockOutlined sx={{ fontSize:14, color:'#2563eb' }}/>
          <Typography sx={{ fontSize:11, color:'#1e40af' }}>Financial data (freight, advance, balance) is hidden. Contact admin for access.</Typography>
        </Box>
      )}

      {/* Table */}
      <Box sx={{ bgcolor:'#fff', border:'0.5px solid #e2e6ef', borderTop:'none', borderRadius:'0 0 8px 8px', overflow:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', minWidth:720 }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {cols.map(h => <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef', whiteSpace:'nowrap' }}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t.id}
                onMouseEnter={e => e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e => e.currentTarget.style.background='#fff'}
                style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                <td style={{ padding:'9px 12px', fontWeight:500, fontSize:12 }}>{t.lr_number || t.trip_number}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99', whiteSpace:'nowrap' }}>
                  {displayDate(t.trip_date, { day:'2-digit', month:'short', year:'numeric' })}
                </td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.from_location} → {t.to_location}</td>
                <td style={{ padding:'9px 12px' }}>
                  <Badge label={t.trip_type} bg={t.trip_type==='owned'?'#dbeafe':'#fef3c7'} color={t.trip_type==='owned'?'#1e40af':'#92400e'}/>
                </td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.truck_number || t.broker_truck_number || '—'}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.consignee_name || '—'}</td>
                {showFreightInList && <>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>
                    {fmt(t.freight_amount)}
                    {t.trip_type === 'brokerage' && <div style={{ fontSize:10, color:'#92400e' }}>Comm: {fmt(t.commission_amount)}</div>}
                  </td>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(t.advance_paid)}</td>
                  <td style={{ padding:'9px 12px', fontSize:12, fontWeight:+t.balance_due > 0 ? 500 : 400, color:+t.balance_due > 0 ? '#d97706' : '#16a34a' }}>
                    {+t.balance_due > 0 ? fmt(t.balance_due) : '—'}
                  </td>
                </>}
                <td style={{ padding:'9px 12px' }}>
                  <Badge label={t.status.replace('_', ' ')} {...STATUS_COLORS[t.status]}/>
                </td>
                <td style={{ padding:'9px 12px', whiteSpace:'nowrap' }}>
                  <button onClick={() => openForm(t, t.trip_type)} style={{ marginRight:5, padding:'3px 9px', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:11, cursor:'pointer', background:'#fff' }}>Edit</button>
                  {canDelete && <button onClick={() => del(t.id)} style={{ padding:'3px 9px', border:'0.5px solid #fca5a5', borderRadius:4, fontSize:11, cursor:'pointer', background:'#fff', color:'#dc2626' }}>Del</button>}
                </td>
              </tr>
            ))}
            {!filtered.length && <tr><td colSpan={cols.length} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No trips found.</td></tr>}
          </tbody>
        </table>
      </Box>

      {/* ══ DIALOG ═══════════════════════════════════════════════════════════ */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="xl" fullWidth PaperProps={{ sx: { maxHeight:'95vh' } }}>
        <DialogTitle sx={{ fontSize:15, fontWeight:500, pb:1, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <Box>
            {editing ? 'Edit Trip' : 'Add New Trip'}
            {editing && <Typography component="span" sx={{ fontSize:11, color:'#6b7a99', ml:1.5 }}>Updating will refresh invoice & dashboard instantly</Typography>}
          </Box>
          {!editing && (
            <Box sx={{ display:'flex', gap:0.5 }}>
              <Button size="small" variant={activeTab==='owned'?'contained':'outlined'} onClick={() => switchTab('owned')}
                sx={{ fontSize:12, bgcolor:activeTab==='owned'?'#1a2744':'transparent', borderColor:'#2563eb', color:activeTab==='owned'?'#fff':'#2563eb' }}>🚛 Owned</Button>
              {isAdmin && (
                <Button size="small" variant={activeTab==='brokerage'?'contained':'outlined'} onClick={() => switchTab('brokerage')}
                  sx={{ fontSize:12, bgcolor:activeTab==='brokerage'?'#f59e0b':'transparent', borderColor:'#f59e0b', color:activeTab==='brokerage'?'#fff':'#92400e' }}>🤝 Brokerage</Button>
              )}
            </Box>
          )}
        </DialogTitle>

        <DialogContent dividers sx={{ pt:2 }}>
          {activeTab === 'brokerage' && (
            <Alert severity="info" sx={{ mb:2, fontSize:12 }}>
              <b>Brokerage mode:</b> You collect full freight from consignee, deduct your commission ({form.commission_percent || 5}%), pay the rest to the owner. Invoice is generated for the consignee + owner ledger entry is created.
            </Alert>
          )}

          <Grid container spacing={2}>
            {/* ── LEFT ── */}
            <Grid item xs={12} md={showFreightInForm ? 8 : 12}>

              {/* Section 1: LR & Route */}
              <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderRadius:'6px', p:'12px', mb:1.5 }}>
                <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>LR & Route details</Typography>
                <Grid container spacing={1.5}>
                  <Grid item xs={4}>
                    <TextField label="LR Number *" fullWidth value={form.lr_number}
                      onChange={e => f('lr_number', e.target.value)} onBlur={() => blur('lr_number')}
                      error={touched.lr_number && !!errors.lr_number} helperText={touched.lr_number && errors.lr_number}
                      InputProps={{ endAdornment: lrLoading ? <CircularProgress size={14}/> : null }}
                      sx={{ '& .MuiOutlinedInput-root':{ bgcolor:'rgba(37,99,235,0.04)' } }}/>
                  </Grid>
                  <Grid item xs={4}>
                    <TextField label="LR Date *" type="date" fullWidth
                      value={toDateStr(form.trip_date)}
                      onChange={e => f('trip_date', e.target.value)} onBlur={() => blur('trip_date')}
                      error={touched.trip_date && !!errors.trip_date} helperText={touched.trip_date && errors.trip_date}
                      InputLabelProps={{ shrink:true }}/>
                  </Grid>
                  <Grid item xs={4}>
                    <TextField select label="Status" fullWidth value={form.status} onChange={e => f('status', e.target.value)}>
                      {[['planned','Planned'],['in_progress','In Progress'],['completed','Completed'],['cancelled','Cancelled']].map(([v,l]) =>
                        <MenuItem key={v} value={v}>{l}</MenuItem>)}
                    </TextField>
                  </Grid>
                  <Grid item xs={5}>
                    <TextField label="From *" fullWidth value={form.from_location}
                      onChange={e => f('from_location', e.target.value)} onBlur={() => blur('from_location')}
                      error={touched.from_location && !!errors.from_location} helperText={touched.from_location && errors.from_location}
                      placeholder="e.g. Pune"/>
                  </Grid>
                  <Grid item xs={5}>
                    <TextField label="To *" fullWidth value={form.to_location}
                      onChange={e => f('to_location', e.target.value)} onBlur={() => blur('to_location')}
                      error={touched.to_location && !!errors.to_location} helperText={touched.to_location && errors.to_location}
                      placeholder="e.g. Mumbai"/>
                  </Grid>
                  <Grid item xs={2}>
                    <TextField label="KM" type="number" fullWidth value={form.distance_km} onChange={e => f('distance_km', e.target.value)} inputProps={{ min:0 }}/>
                  </Grid>
                  <Grid item xs={4}>
                    <TextField label="Weight (tons)" type="number" fullWidth value={form.weight_tons} onChange={e => f('weight_tons', e.target.value)} inputProps={{ min:0 }}/>
                  </Grid>
                  <Grid item xs={8}>
                    <TextField select label="Consignee" fullWidth value={form.consignee_id} onChange={e => f('consignee_id', e.target.value)}>
                      <MenuItem value=""><em>— Select consignee (optional) —</em></MenuItem>
                      {consignees.map(c => <MenuItem key={c.id} value={String(c.id)}>{c.name}{c.city?` — ${c.city}`:''}</MenuItem>)}
                    </TextField>
                  </Grid>
                  <Grid item xs={12}>
                    <TextField label="Notes" fullWidth multiline rows={1} value={form.notes || ''} onChange={e => f('notes', e.target.value)}/>
                  </Grid>
                </Grid>
              </Box>

              {/* Section 2a: Truck & Driver — owned */}
              {activeTab === 'owned' && (
                <Box sx={{ bgcolor:'#eff6ff', border:'0.5px solid #bfdbfe', borderRadius:'6px', p:'12px', mb:1.5 }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#1e40af', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>Vehicle & Driver</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}>
                      <TextField select label="Truck *" fullWidth value={form.truck_id}
                        onChange={e => f('truck_id', e.target.value)} onBlur={() => blur('truck_id')}
                        error={touched.truck_id && !!errors.truck_id} helperText={touched.truck_id && errors.truck_id}>
                        <MenuItem value=""><em>— Select truck —</em></MenuItem>
                        {trucks.map(t => <MenuItem key={t.id} value={String(t.id)}>{t.truck_number}{t.truck_type?` — ${t.truck_type}`:''}</MenuItem>)}
                      </TextField>
                    </Grid>
                    <Grid item xs={6}>
                      <TextField select label="Driver *" fullWidth value={form.driver_id}
                        onChange={e => f('driver_id', e.target.value)} onBlur={() => blur('driver_id')}
                        error={touched.driver_id && !!errors.driver_id} helperText={touched.driver_id && errors.driver_id}>
                        <MenuItem value=""><em>— Select driver —</em></MenuItem>
                        {drivers.filter(d => d.is_active).map(d => <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>)}
                      </TextField>
                    </Grid>
                  </Grid>
                </Box>
              )}

              {/* Section 2b: External owner — brokerage */}
              {activeTab === 'brokerage' && (
                <Box sx={{ bgcolor:'#fffbeb', border:'0.5px solid #fcd34d', borderRadius:'6px', p:'12px', mb:1.5 }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#92400e', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>External truck owner details</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}>
                      <TextField label="Owner name *" fullWidth value={form.broker_owner_name || ''}
                        onChange={e => f('broker_owner_name', e.target.value)} onBlur={() => blur('broker_owner_name')}
                        error={touched.broker_owner_name && !!errors.broker_owner_name} helperText={touched.broker_owner_name && errors.broker_owner_name}/>
                    </Grid>
                    <Grid item xs={6}>
                      <TextField label="Owner phone *" fullWidth value={form.broker_owner_phone || ''}
                        onChange={e => f('broker_owner_phone', e.target.value.replace(/\D/, ''))}
                        onBlur={() => blur('broker_owner_phone')}
                        error={touched.broker_owner_phone && !!errors.broker_owner_phone}
                        helperText={touched.broker_owner_phone && errors.broker_owner_phone}
                        inputProps={{ maxLength:10 }}/>
                    </Grid>
                    <Grid item xs={6}>
                      <TextField label="Truck number *" fullWidth value={form.broker_truck_number || ''}
                        onChange={e => f('broker_truck_number', e.target.value)} onBlur={() => blur('broker_truck_number')}
                        error={touched.broker_truck_number && !!errors.broker_truck_number} helperText={touched.broker_truck_number && errors.broker_truck_number}
                        placeholder="e.g. MH04GH7788"/>
                    </Grid>
                    <Grid item xs={6}>
                      <TextField label="Driver name" fullWidth value={form.broker_driver_name || ''} onChange={e => f('broker_driver_name', e.target.value)}/>
                    </Grid>
                  </Grid>
                </Box>
              )}

              {/* Section 3: Freight & Billing */}
              {showFreightInForm && (
                <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderRadius:'6px', p:'12px', mb:1.5 }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>Freight & billing</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={4}>
                      <TextField label="Freight amount ₹ *" type="number" fullWidth value={form.freight_amount}
                        onChange={e => f('freight_amount', e.target.value)} onBlur={() => blur('freight_amount')}
                        error={touched.freight_amount && !!errors.freight_amount} helperText={touched.freight_amount && errors.freight_amount}
                        inputProps={{ min:0 }}/>
                    </Grid>
                    <Grid item xs={4}>
                      <TextField label="Advance received ₹" type="number" fullWidth value={form.advance_paid}
                        onChange={e => f('advance_paid', e.target.value)} inputProps={{ min:0 }}/>
                    </Grid>
                    {/* Balance due — auto-calculated from freight minus advance, editable */}
                    <Grid item xs={4}>
                      <TextField
                        label="Balance due ₹"
                        type="number"
                        fullWidth
                        value={form.balance_due !== '' ? form.balance_due : Math.max(0, (num(form.freight_amount) - num(form.advance_paid)))}
                        onChange={e => f('balance_due', e.target.value)}
                        inputProps={{ min:0 }}
                        helperText="Auto-calculated. Edit if needed."
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            bgcolor: num(form.balance_due) > 0 ? 'rgba(217,119,6,0.06)' : 'rgba(22,163,74,0.05)',
                          },
                          '& .MuiInputLabel-root': {
                            color: num(form.balance_due !== '' ? form.balance_due : num(form.freight_amount) - num(form.advance_paid)) > 0 ? '#d97706' : '#16a34a',
                            fontWeight: 500,
                          }
                        }}
                      />
                    </Grid>
                    {activeTab === 'owned' && <>
                      <Grid item xs={3}><TextField label="Detention ₹" type="number" fullWidth value={form.detention_charges || ''} onChange={e => f('detention_charges', e.target.value)} inputProps={{ min:0 }}/></Grid>
                      <Grid item xs={3}><TextField label="Kata ₹" type="number" fullWidth value={form.kata_charges || ''} onChange={e => f('kata_charges', e.target.value)} inputProps={{ min:0 }}/></Grid>
                      <Grid item xs={3}><TextField label="Loading ₹" type="number" fullWidth value={form.loading_charges || ''} onChange={e => f('loading_charges', e.target.value)} inputProps={{ min:0 }}/></Grid>
                      <Grid item xs={3}><TextField label="Unloading ₹" type="number" fullWidth value={form.unloading_charges || ''} onChange={e => f('unloading_charges', e.target.value)} inputProps={{ min:0 }}/></Grid>
                    </>}
                    {activeTab === 'brokerage' && <>
                      <Grid item xs={4}>
                        <TextField label="Commission % *" type="number" fullWidth value={form.commission_percent}
                          onChange={e => f('commission_percent', e.target.value)} onBlur={() => blur('commission_percent')}
                          error={touched.commission_percent && !!errors.commission_percent}
                          helperText={touched.commission_percent && errors.commission_percent}
                          inputProps={{ min:0, max:100 }}/>
                      </Grid>
                      <Grid item xs={4}>
                        <TextField label="Advance paid to owner ₹" type="number" fullWidth
                          value={form.broker_advance_paid || ''}
                          onChange={e => f('broker_advance_paid', e.target.value)} inputProps={{ min:0 }}/>
                      </Grid>
                      <Grid item xs={4}>
                        <TextField select label="Owner pay status" fullWidth value={form.broker_payment_status || 'pending'} onChange={e => f('broker_payment_status', e.target.value)}>
                          <MenuItem value="pending">Pending</MenuItem>
                          <MenuItem value="advance_paid">Advance paid</MenuItem>
                          <MenuItem value="settled">Fully settled</MenuItem>
                        </TextField>
                      </Grid>
                    </>}
                    <Grid item xs={4}>
                      <TextField select label="GST type" fullWidth value={form.gst_type} onChange={e => f('gst_type', e.target.value)}>
                        <MenuItem value="exempt">Exempt</MenuItem>
                        <MenuItem value="cgst_sgst">CGST + SGST (Intra-state)</MenuItem>
                        <MenuItem value="igst">IGST (Inter-state)</MenuItem>
                      </TextField>
                    </Grid>
                    <Grid item xs={4}>
                      <TextField label="GST %" type="number" fullWidth value={form.gst_rate || ''} onChange={e => f('gst_rate', e.target.value)} inputProps={{ min:0, max:28 }}/>
                    </Grid>
                  </Grid>
                </Box>
              )}

              {/* Section 4: Trip expenses — owned only */}
              {activeTab === 'owned' && showFreightInForm && (
                <Box sx={{ bgcolor:'#fff8f0', border:'0.5px solid #fed7aa', borderRadius:'6px', p:'12px' }}>
                  <Box sx={{ display:'flex', justifyContent:'space-between', alignItems:'center', mb:1 }}>
                    <Typography sx={{ fontSize:10, fontWeight:600, color:'#9a3412', textTransform:'uppercase', letterSpacing:'0.06em' }}>
                      Trip expenses — Diesel, Toll, RTO, Repair etc.
                    </Typography>
                    <Button size="small" startIcon={<Add/>} onClick={addExp}
                      sx={{ fontSize:11, color:'#9a3412', border:'0.5px solid #fed7aa', py:0.3 }}>Add row</Button>
                  </Box>
                  {expenses.length === 0 && (
                    <Typography sx={{ fontSize:12, color:'#c2410c', opacity:0.7, py:0.5 }}>
                      No expenses yet. Click "Add row" to log diesel, toll, repair costs etc.
                    </Typography>
                  )}
                  {expenses.map((exp, i) => (
                    <Grid container spacing={1} key={i} sx={{ mb:1, alignItems:'center' }}>
                      <Grid item xs={3}>
                        <TextField select size="small" fullWidth label="Type" value={exp.expense_type} onChange={e => updExp(i, 'expense_type', e.target.value)}>
                          {EXPENSE_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
                        </TextField>
                      </Grid>
                      <Grid item xs={2}>
                        <TextField size="small" type="number" fullWidth label="Amount ₹" value={exp.amount} onChange={e => updExp(i, 'amount', e.target.value)} inputProps={{ min:0 }}/>
                      </Grid>
                      <Grid item xs={4}>
                        <TextField size="small" fullWidth label="Description" value={exp.description || ''} onChange={e => updExp(i, 'description', e.target.value)} placeholder="e.g. Diesel — Pune highway"/>
                      </Grid>
                      <Grid item xs={2}>
                        <TextField size="small" type="date" fullWidth label="Date"
                          value={toDateStr(exp.expense_date) || toDateStr(form.trip_date)}
                          onChange={e => updExp(i, 'expense_date', e.target.value)}
                          InputLabelProps={{ shrink:true }}/>
                      </Grid>
                      <Grid item xs={1} sx={{ textAlign:'center' }}>
                        <IconButton size="small" onClick={() => delExp(i)} sx={{ color:'#dc2626' }}><Delete fontSize="small"/></IconButton>
                      </Grid>
                    </Grid>
                  ))}
                  {expenses.length > 0 && (
                    <Box sx={{ display:'flex', justifyContent:'flex-end', pt:1, borderTop:'0.5px solid #fed7aa', mt:0.5 }}>
                      <Typography sx={{ fontSize:12, fontWeight:500, color:'#9a3412' }}>Total: {fmt(totalExp)}</Typography>
                    </Box>
                  )}
                </Box>
              )}
            </Grid>

            {/* ── RIGHT — Calculator ── */}
            {showFreightInForm && (
              <Grid item xs={12} md={4}>
                <Box sx={{ bgcolor:'#1a2744', borderRadius:'8px', p:'14px', color:'#fff', position:'sticky', top:0 }}>
                  <Typography sx={{ fontSize:11, fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.5 }}>
                    {activeTab === 'owned' ? 'Live profit calculator' : 'Commission calculator'}
                  </Typography>

                  {activeTab === 'owned' && (() => {
                    const c = ownedCalc();
                    return <>
                      <Row label="Freight collected" value={fmt(c.fr)}/>
                      <Box sx={{ my:0.8, borderTop:'1px solid rgba(255,255,255,0.1)' }}/>
                      <Row label="Detention + Kata + Load" value={`− ${fmt(c.det)}`} valueColor="#fca5a5"/>
                      <Row label={`Diesel + Toll + Other (${expenses.length})`} value={`− ${fmt(c.ext)}`} valueColor="#fca5a5"/>
                      <Row label={`Driver extra (${form.distance_km || 0} km × ₹5)`} value={`− ${fmt(c.drv)}`} valueColor="#fca5a5"/>
                      <Box sx={{ my:1, borderTop:'1px solid rgba(255,255,255,0.15)' }}/>
                      <Row label="Net profit" value={fmt(c.net)} valueColor={c.net >= 0 ? '#4ade80' : '#f87171'} bold/>
                      <Row label="Balance due from client" value={fmt(c.due)} valueColor="#fbbf24"/>
                      {!editing && num(form.freight_amount) > 0 && (
                        <Box sx={{ mt:1.5, p:'8px', bgcolor:'rgba(255,255,255,0.07)', borderRadius:'5px', fontSize:11, color:'rgba(255,255,255,0.6)' }}>
                          ✓ Invoice will auto-generate on save
                        </Box>
                      )}
                    </>;
                  })()}

                  {activeTab === 'brokerage' && (() => {
                    const c = brokerCalc();
                    return <>
                      <Row label="Freight collected from consignee" value={fmt(c.fr)}/>
                      <Box sx={{ my:1, borderTop:'1px solid rgba(255,255,255,0.1)' }}/>
                      <Row label={`Your commission (${c.pct}%)`} value={fmt(c.comm)} valueColor="#4ade80" bold/>
                      <Row label="Pay to truck owner" value={fmt(c.owed)} valueColor="#93c5fd"/>
                      <Box sx={{ my:1, p:'8px', bgcolor:'rgba(245,158,11,0.12)', border:'1px solid rgba(245,158,11,0.25)', borderRadius:'5px', fontSize:11, color:'#fbbf24' }}>
                        No diesel / toll / driver expense on your side
                      </Box>
                      <Box sx={{ my:1, borderTop:'1px solid rgba(255,255,255,0.15)' }}/>
                      <Row label="Advance received from consignee" value={fmt(num(form.advance_paid))}/>
                      <Row label="Balance due from consignee" value={fmt(c.due)} valueColor={c.due > 0 ? '#fbbf24' : '#4ade80'}/>
                      <Box sx={{ my:1, borderTop:'1px solid rgba(255,255,255,0.1)' }}/>
                      <Row label="Advance paid to owner" value={fmt(num(form.broker_advance_paid))}/>
                      <Row label="Still owed to owner" value={fmt(Math.max(0, c.ownerRem))} valueColor={c.ownerRem > 0 ? '#f87171' : '#4ade80'}/>
                      <Box sx={{ mt:1.5, p:'8px', bgcolor:'rgba(255,255,255,0.07)', borderRadius:'5px', fontSize:11, color:'rgba(255,255,255,0.6)' }}>
                        ✓ Invoice will be generated for consignee<br/>
                        ✓ Owner ledger entry will be created
                      </Box>
                    </>;
                  })()}
                </Box>
              </Grid>
            )}
          </Grid>
        </DialogContent>

        <DialogActions sx={{ px:3, py:2, gap:1 }}>
          <Button onClick={() => setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={save} disabled={saving}
            sx={{ bgcolor:'#1a2744', px:3, fontSize:13, minWidth:140 }}>
            {saving ? <CircularProgress size={18} color="inherit"/> : editing ? 'Update trip' : 'Save trip'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
