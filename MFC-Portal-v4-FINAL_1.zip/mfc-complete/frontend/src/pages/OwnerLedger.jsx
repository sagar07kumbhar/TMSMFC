import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from '@mui/material';
import api from '../utils/api';
import { useToast } from '../components/Toast';

const fmt  = n => `₹${(+n||0).toLocaleString('en-IN')}`;
const fmtL = n => { const v=+n||0; return v>=100000?`₹${(v/100000).toFixed(1)}L`:v>=1000?`₹${(v/1000).toFixed(0)}K`:`₹${v}`; };

export default function OwnerLedger() {
  const [payments, setPayments]   = useState([]);
  const [owners, setOwners]       = useState([]);   // grouped by owner name
  const [payOpen, setPayOpen]     = useState(false);
  const [selPayment, setSelPayment] = useState(null);
  const [payAmount, setPayAmount] = useState('');
  const showToast = useToast();

  const load = () => {
    api.get('/trips?trip_type=brokerage&limit=100').then(r => {
      const trips = r.data.data || [];
      // Group by owner name
      const map = {};
      trips.forEach(t => {
        const key = t.broker_owner_name;
        if (!key) return;
        if (!map[key]) map[key] = { owner_name:key, phone:t.broker_owner_phone, trips:[], total_freight:0, total_commission:0, total_paid:0, total_balance:0 };
        map[key].trips.push(t);
        map[key].total_freight    += +t.freight_amount||0;
        map[key].total_commission += +t.commission_amount||0;
        const payable = (+t.freight_amount||0) - (+t.commission_amount||0);
        const paid    = (+t.broker_advance_paid||0) + (+t.broker_final_paid||0);
        map[key].total_paid    += paid;
        map[key].total_balance += Math.max(0, payable - paid);
      });
      setOwners(Object.values(map).sort((a,b) => b.total_balance - a.total_balance));
    }).catch(()=>{});
  };
  useEffect(() => { load(); }, []);

  const openPay = (owner) => {
    setSelPayment(owner);
    setPayAmount(String(Math.round(owner.total_balance)));
    setPayOpen(true);
  };

  const confirmPay = async () => {
    if (!payAmount || +payAmount <= 0) { showToast('Enter a valid amount','error'); return; }
    // In real app: call API to record payment against all pending trips for this owner
    showToast(`Payment of ${fmt(+payAmount)} recorded for ${selPayment.owner_name}`,'success');
    setPayOpen(false);
    load();
  };

  // Summary stats
  const totalOwners  = owners.length;
  const totalPending = owners.reduce((s,o)=>s+o.total_balance,0);
  const totalPaid    = owners.reduce((s,o)=>s+o.total_paid,0);

  return (
    <Box>
      {/* Summary */}
      <Box sx={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', mb:2 }}>
        {[
          ['Total owners',totalOwners,'In network','#f59e0b'],
          ['Total pending payout',fmtL(totalPending),'Across all owners','#dc2626'],
          ['Total paid out',fmtL(totalPaid),'All time','#16a34a'],
        ].map(([l,v,s,c])=>(
          <Box key={l} sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', borderLeft:`3px solid ${c}`, p:'12px 14px' }}>
            <Typography sx={{ fontSize:11, color:'#6b7a99', mb:0.3 }}>{l}</Typography>
            <Typography sx={{ fontSize:20, fontWeight:500 }}>{v}</Typography>
            <Typography sx={{ fontSize:11, color:'#6b7a99', mt:0.3 }}>{s}</Typography>
          </Box>
        ))}
      </Box>

      {/* Owner table */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Box sx={{ p:'10px 14px', borderBottom:'0.5px solid #e2e6ef', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Truck owner ledger</Typography>
          <input placeholder="Search owner..." style={{ padding:'4px 8px', border:'0.5px solid #e2e6ef', borderRadius:5, fontSize:12, outline:'none', background:'white', color:'inherit', width:180 }}/>
        </Box>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {['Owner','Phone','Trips','Total freight','Commission cut','Paid to owner','Pending','Status','Action'].map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef', whiteSpace:'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {owners.map(o => (
              <tr key={o.owner_name} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                <td style={{ padding:'9px 12px', fontWeight:500, fontSize:13 }}>{o.owner_name}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99' }}>{o.phone||'—'}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{o.trips.length}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(o.total_freight)}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#92400e' }}>{fmt(o.total_commission)}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#16a34a' }}>{fmt(o.total_paid)}</td>
                <td style={{ padding:'9px 12px', fontSize:12, color:o.total_balance>0?'#d97706':'#6b7a99', fontWeight:o.total_balance>0?500:400 }}>
                  {o.total_balance>0 ? fmt(o.total_balance) : '—'}
                </td>
                <td style={{ padding:'9px 12px' }}>
                  <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500,
                    background:o.total_balance<=0?'#dcfce7':o.total_paid>0?'#fef9c3':'#fee2e2',
                    color:o.total_balance<=0?'#166534':o.total_paid>0?'#854d0e':'#991b1b' }}>
                    {o.total_balance<=0?'Cleared':o.total_paid>0?'Partial':'Pending'}
                  </span>
                </td>
                <td style={{ padding:'9px 12px' }}>
                  {o.total_balance > 0 ? (
                    <button onClick={()=>openPay(o)} style={{ padding:'3px 10px', background:'#1a2744', color:'#fff', border:'none', borderRadius:4, fontSize:10, cursor:'pointer' }}>Pay now</button>
                  ) : (
                    <button style={{ padding:'3px 10px', background:'#fff', color:'#6b7a99', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:10, cursor:'pointer' }}>View</button>
                  )}
                </td>
              </tr>
            ))}
            {!owners.length && (
              <tr><td colSpan={9} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No brokerage trips recorded yet. Add brokerage trips to see owner ledger.</td></tr>
            )}
          </tbody>
        </table>
      </Box>

      {/* Pay dialog */}
      <Dialog open={payOpen} onClose={()=>setPayOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>Record payment to owner</DialogTitle>
        <DialogContent sx={{ pt:1 }}>
          {selPayment && (
            <Box>
              <Box sx={{ bgcolor:'#f8fafc', borderRadius:'6px', p:'10px 12px', mb:2 }}>
                <Typography sx={{ fontSize:13, fontWeight:500, mb:0.5 }}>{selPayment.owner_name}</Typography>
                <Typography sx={{ fontSize:12, color:'#6b7a99' }}>{selPayment.phone}</Typography>
                <Box sx={{ display:'flex', justifyContent:'space-between', mt:1, fontSize:12 }}>
                  <span style={{ color:'#6b7a99' }}>Total pending</span>
                  <span style={{ fontWeight:500, color:'#d97706' }}>{fmt(selPayment.total_balance)}</span>
                </Box>
              </Box>
              <TextField label="Payment amount ₹" type="number" fullWidth value={payAmount} onChange={e=>setPayAmount(e.target.value)} autoFocus helperText="Enter amount being paid now"/>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2.5, gap:1 }}>
          <Button onClick={()=>setPayOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={confirmPay} sx={{ bgcolor:'#16a34a' }}>Confirm payment</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
