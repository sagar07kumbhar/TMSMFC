import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Grid } from '@mui/material';
import api from '../utils/api';
import { useToast } from '../components/Toast';

export default function Consignees() {
  const [list, setList]       = useState([]);
  const [open, setOpen]       = useState(false);
  const [form, setForm]       = useState({});
  const [editing, setEditing] = useState(null);
  const showToast = useToast();

  const load = () => api.get('/consignees').then(r => setList(r.data));
  useEffect(() => { load(); }, []);

  const openForm = (c = null) => {
    setEditing(c?.id || null);
    setForm(c || { name:'', gstin:'', address:'', city:'', state:'', phone:'', email:'' });
    setOpen(true);
  };

  const save = async () => {
    try {
      editing ? await api.put(`/consignees/${editing}`, form) : await api.post('/consignees', form);
      setOpen(false); load();
      showToast(editing ? 'Consignee updated' : 'Consignee added successfully', 'success');
    } catch { showToast('Failed to save', 'error'); }
  };

  const del = async id => {
    if (!confirm('Remove consignee?')) return;
    try { await api.delete(`/consignees/${id}`); load(); showToast('Consignee removed', 'info'); }
    catch { showToast('Failed to remove', 'error'); }
  };

  const f = (k,v) => setForm(p => ({...p,[k]:v}));

  return (
    <Box>
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Box sx={{ p:'12px 16px', display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'0.5px solid #e2e6ef' }}>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Consignees</Typography>
          <Button variant="contained" size="small" onClick={() => openForm()} sx={{ bgcolor:'#1a2744', fontSize:12 }}>+ Add consignee</Button>
        </Box>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {['Name','City','State','GSTIN','Phone','Trips','Actions'].map(h => (
                <th key={h} style={{ padding:'8px 14px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {list.map(c => (
              <tr key={c.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                <td style={{ padding:'9px 14px', fontSize:12.5, fontWeight:500 }}>{c.name}</td>
                <td style={{ padding:'9px 14px', fontSize:12.5 }}>{c.city}</td>
                <td style={{ padding:'9px 14px', fontSize:12.5 }}>{c.state}</td>
                <td style={{ padding:'9px 14px', fontSize:12.5, color:'#6b7a99' }}>{c.gstin||'—'}</td>
                <td style={{ padding:'9px 14px', fontSize:12.5 }}>{c.phone}</td>
                <td style={{ padding:'9px 14px', fontSize:12.5, color:'#6b7a99' }}>—</td>
                <td style={{ padding:'9px 14px' }}>
                  <button onClick={() => openForm(c)} style={{ marginRight:6, padding:'3px 8px', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:11, cursor:'pointer', background:'#fff' }}>Edit</button>
                  <button onClick={() => del(c.id)} style={{ padding:'3px 8px', border:'0.5px solid #fca5a5', borderRadius:4, fontSize:11, cursor:'pointer', background:'#fff', color:'#dc2626' }}>Remove</button>
                </td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan={7} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12.5 }}>No consignees added yet</td></tr>}
          </tbody>
        </table>
      </Box>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>{editing ? 'Edit Consignee' : 'Add Consignee'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={1.5} sx={{ mt:0.5 }}>
            <Grid item xs={12}><TextField label="Company Name" fullWidth value={form.name||''} onChange={e=>f('name',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="GSTIN" fullWidth value={form.gstin||''} onChange={e=>f('gstin',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="Phone" fullWidth value={form.phone||''} onChange={e=>f('phone',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="City" fullWidth value={form.city||''} onChange={e=>f('city',e.target.value)} /></Grid>
            <Grid item xs={6}><TextField label="State" fullWidth value={form.state||''} onChange={e=>f('state',e.target.value)} /></Grid>
            <Grid item xs={12}><TextField label="Address" fullWidth multiline rows={2} value={form.address||''} onChange={e=>f('address',e.target.value)} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2 }}>
          <Button onClick={() => setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={save} sx={{ bgcolor:'#1a2744' }}>Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
