import React, { useEffect, useState } from 'react';
import { Box, Typography, CircularProgress, Alert, Chip } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import usePermissions from '../hooks/usePermissions';

const fmtL = n => { const v=+n||0; return v>=100000?`₹${(v/100000).toFixed(1)}L`:v>=1000?`₹${(v/1000).toFixed(0)}K`:`₹${v}`; };
const fmt  = n => `₹${(+n||0).toLocaleString('en-IN')}`;

function StatCard({ label, value, sub, borderColor, onClick, alert }) {
  return (
    <Box onClick={onClick} sx={{
      bgcolor: '#fff', borderRadius: '8px',
      border: '0.5px solid #e2e6ef',
      borderLeft: borderColor ? `3px solid ${borderColor}` : '0.5px solid #e2e6ef',
      p: '12px 14px', cursor: onClick ? 'pointer' : 'default',
      transition: 'box-shadow 0.15s',
      '&:hover': onClick ? { boxShadow: '0 2px 8px rgba(0,0,0,0.08)' } : {}
    }}>
      <Typography sx={{ fontSize: 11, color: '#6b7a99', mb: 0.4 }}>{label}</Typography>
      <Typography sx={{ fontSize: 20, fontWeight: 500, color: alert ? '#dc2626' : '#1a2744', mb: 0.3 }}>{value}</Typography>
      {sub && <Typography sx={{ fontSize: 11, color: '#6b7a99' }}>{sub}</Typography>}
    </Box>
  );
}

export default function Dashboard() {
  const [data, setData]  = useState(null);
  const [err, setErr]    = useState('');
  const { can, role, isAdmin, isStaff1, isStaff2 } = usePermissions();
  const nav = useNavigate();

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(r => setData(r.data))
      .catch(() => setErr('Failed to load dashboard'));
  }, []);

  if (!data && !err) return <Box sx={{ display:'flex', justifyContent:'center', mt:8 }}><CircularProgress /></Box>;
  if (err) return <Alert severity="error">{err}</Alert>;

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box sx={{ width: 38, height: 38, borderRadius: '10px', bgcolor: '#1a2744', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="24" height="24" viewBox="0 0 48 48" fill="none">
              <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8"/>
              <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round"/>
              <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.45"/>
              <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
              <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
              <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
              <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
              <rect x="41" y="27" width="3" height="2" rx="1" fill="#FCD34D"/>
            </svg>
          </Box>
          <Box>
            <Typography sx={{ fontSize: 15, fontWeight: 600, color: '#1a2744', lineHeight: 1.2 }}>Dashboard</Typography>
            <Typography sx={{ fontSize: 11, color: '#6b7a99' }}>
              {isAdmin ? 'Full overview' : isStaff1 ? 'Operations view' : 'Fleet & maintenance view'}
            </Typography>
          </Box>
        </Box>

        {/* Alerts - all roles see doc expiry */}
        <Box sx={{ display: 'flex', gap: 1 }}>
          {data.expiring_docs > 0 && (
            <Chip label={`${data.expiring_docs} docs expiring soon`} size="small" color="warning" sx={{ fontSize: 11 }} onClick={() => nav('/fleet')} />
          )}
          {/* Only admin sees invoice alerts */}
          {isAdmin && data.pending_invoices.count > 0 && (
            <Chip label={`${data.pending_invoices.count} unpaid invoices`} size="small" color="error" sx={{ fontSize: 11 }} onClick={() => nav('/invoices')} />
          )}
        </Box>
      </Box>

      {/* ── ADMIN VIEW ── */}
      {isAdmin && (
        <>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '10px', mb: '10px' }}>
            <StatCard label="Own truck revenue" value={fmtL(data.monthly.owned_revenue)} sub="This month" borderColor="#2563eb" onClick={() => nav('/analytics')} />
            <StatCard label="Brokerage commission" value={fmtL(data.monthly.brokerage_commission)} sub={`${data.monthly.trips} trips`} borderColor="#f59e0b" onClick={() => nav('/brokerage')} />
            <StatCard label="Total earnings" value={fmtL(data.monthly.total_revenue)} sub="Own + brokerage" onClick={() => nav('/analytics')} />
            <StatCard label="Balance due" value={fmtL(data.pending_invoices.amount)} sub={`${data.pending_invoices.count} invoices`} alert={data.pending_invoices.count > 0} onClick={() => nav('/invoices')} />
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '10px', mb: '14px' }}>
            <StatCard label="Net profit" value={fmtL(data.monthly.net_profit)} sub={`Expenses: ${fmtL(data.monthly.expenses)}`} borderColor="#16a34a" />
            <StatCard label="Active trucks" value={data.fleet.trucks} sub="in fleet" onClick={() => nav('/fleet')} />
            <StatCard label="Active drivers" value={data.fleet.drivers} sub="on roster" onClick={() => nav('/drivers')} />
            <StatCard label="Docs expiring" value={data.expiring_docs} sub="in 30 days" borderColor={data.expiring_docs > 0 ? '#dc2626' : undefined} alert={data.expiring_docs > 0} onClick={() => nav('/fleet')} />
          </Box>

          {/* Revenue chart — admin only */}
          <Box sx={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '12px', mb: '12px' }}>
            <Box sx={{ bgcolor: '#fff', borderRadius: '8px', border: '0.5px solid #e2e6ef', p: '14px' }}>
              <Typography sx={{ fontSize: 11, fontWeight: 500, color: '#6b7a99', mb: 1.5 }}>Monthly earnings — own vs brokerage</Typography>
              <Box sx={{ display:'flex', gap:'12px', mb:1 }}>
                {[['#1a2744','Own trucks'],['#f59e0b','Brokerage']].map(([c,l])=>(
                  <Box key={l} sx={{display:'flex',alignItems:'center',gap:0.5}}><Box sx={{width:8,height:8,bgcolor:c,borderRadius:'2px'}}/><Typography sx={{fontSize:10,color:'#6b7a99'}}>{l}</Typography></Box>
                ))}
              </Box>
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={data.trend} margin={{top:0,right:0,left:-20,bottom:0}}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false}/>
                  <XAxis dataKey="month_label" tick={{fontSize:10,fill:'#6b7a99'}} axisLine={false} tickLine={false}/>
                  <YAxis tick={{fontSize:10,fill:'#6b7a99'}} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                  <Tooltip formatter={v=>[`₹${(+v).toLocaleString('en-IN')}`,'']}/>
                  <Bar dataKey="owned_revenue" name="Own" fill="#1a2744" radius={[3,3,0,0]}/>
                  <Bar dataKey="brokerage_commission" name="Brokerage" fill="#f59e0b" radius={[3,3,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </Box>
            <Box sx={{ bgcolor: '#fff', borderRadius: '8px', border: '0.5px solid #e2e6ef', p: '14px' }}>
              <Typography sx={{ fontSize: 11, fontWeight: 500, color: '#6b7a99', mb: 1.5 }}>Top routes</Typography>
              {data.top_routes.map((r, i) => (
                <Box key={i} sx={{ display:'flex', alignItems:'center', gap:1, py:'6px', borderBottom: i < data.top_routes.length-1 ? '0.5px solid #e2e6ef' : 'none' }}>
                  <Box sx={{ width:6, height:6, borderRadius:'50%', bgcolor:'#2563eb', flexShrink:0 }}/>
                  <Box sx={{ flex:1 }}>
                    <Typography sx={{ fontSize:12 }}>{r.route}</Typography>
                    <Typography sx={{ fontSize:10, color:'#6b7a99' }}>{r.trips} trips · {fmt(r.revenue)}</Typography>
                  </Box>
                </Box>
              ))}
              {!data.top_routes.length && <Typography sx={{ fontSize:12, color:'#6b7a99' }}>No completed trips yet</Typography>}
            </Box>
          </Box>

          {/* Quick actions — admin */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '10px' }}>
            {[
              { label: 'New Trip', sub: 'Add a trip', color: '#1a2744', path: '/trips' },
              { label: 'Maintenance', sub: 'Log service', color: '#7c3aed', path: '/maintenance' },
              { label: 'Analytics', sub: 'View reports', color: '#059669', path: '/analytics' },
              { label: 'AI Assistant', sub: 'Ask anything', color: '#2563eb', path: '/ai' },
            ].map(q => (
              <Box key={q.label} onClick={() => nav(q.path)} sx={{ bgcolor: q.color, borderRadius: '8px', p: '12px 14px', cursor: 'pointer', transition: 'opacity 0.15s', '&:hover': { opacity: 0.9 } }}>
                <Typography sx={{ color: '#fff', fontWeight: 600, fontSize: 13 }}>{q.label}</Typography>
                <Typography sx={{ color: 'rgba(255,255,255,0.65)', fontSize: 11, mt: 0.3 }}>{q.sub}</Typography>
              </Box>
            ))}
          </Box>
        </>
      )}

      {/* ── STAFF 1 VIEW — Operations ── */}
      {isStaff1 && (
        <>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px', mb: '14px' }}>
            <StatCard label="Active trucks" value={data.fleet.trucks} sub="in fleet" onClick={() => nav('/fleet')} />
            <StatCard label="Active drivers" value={data.fleet.drivers} sub="on roster" onClick={() => nav('/drivers')} />
            <StatCard label="Docs expiring" value={data.expiring_docs} sub="in 30 days" borderColor={data.expiring_docs > 0 ? '#dc2626' : undefined} alert={data.expiring_docs > 0} onClick={() => nav('/fleet')} />
          </Box>

          {/* Trips this month — count only, no ₹ */}
          <Box sx={{ bgcolor: '#fff', borderRadius: '8px', border: '0.5px solid #e2e6ef', p: '14px', mb: '12px' }}>
            <Typography sx={{ fontSize: 12, fontWeight: 500, color: '#1a2744', mb: 1 }}>Trips this month</Typography>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1 }}>
              <Typography sx={{ fontSize: 32, fontWeight: 600, color: '#1a2744' }}>{data.monthly.trips}</Typography>
              <Typography sx={{ fontSize: 13, color: '#6b7a99' }}>trips recorded</Typography>
            </Box>
          </Box>

          {/* Quick actions — staff1 */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px' }}>
            {[
              { label: 'New Trip', sub: 'Add a trip', color: '#1a2744', path: '/trips' },
              { label: 'Drivers', sub: 'View roster', color: '#059669', path: '/drivers' },
              { label: 'Consignees', sub: 'Manage clients', color: '#2563eb', path: '/consignees' },
            ].map(q => (
              <Box key={q.label} onClick={() => nav(q.path)} sx={{ bgcolor: q.color, borderRadius: '8px', p: '12px 14px', cursor: 'pointer', transition: 'opacity 0.15s', '&:hover': { opacity: 0.9 } }}>
                <Typography sx={{ color: '#fff', fontWeight: 600, fontSize: 13 }}>{q.label}</Typography>
                <Typography sx={{ color: 'rgba(255,255,255,0.65)', fontSize: 11, mt: 0.3 }}>{q.sub}</Typography>
              </Box>
            ))}
          </Box>
        </>
      )}

      {/* ── STAFF 2 VIEW — Fleet & Maintenance ── */}
      {isStaff2 && (
        <>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px', mb: '14px' }}>
            <StatCard label="Active trucks" value={data.fleet.trucks} sub="in fleet" onClick={() => nav('/fleet')} />
            <StatCard label="Active drivers" value={data.fleet.drivers} sub="on roster" onClick={() => nav('/drivers')} />
            <StatCard label="Docs expiring" value={data.expiring_docs} sub="in 30 days" borderColor={data.expiring_docs > 0 ? '#dc2626' : undefined} alert={data.expiring_docs > 0} onClick={() => nav('/fleet')} />
          </Box>

          {/* Doc expiry alerts */}
          {data.expiring_docs > 0 && (
            <Box sx={{ bgcolor: '#fef9c3', border: '0.5px solid #fcd34d', borderRadius: '8px', p: '12px 14px', mb: '12px' }}>
              <Typography sx={{ fontSize: 13, fontWeight: 500, color: '#854d0e', mb: 0.5 }}>
                Action required — {data.expiring_docs} document{data.expiring_docs > 1 ? 's' : ''} expiring within 30 days
              </Typography>
              <Typography sx={{ fontSize: 12, color: '#92400e' }}>
                Check Fleet page to see which RC, PUC, Fitness or Insurance certificates need renewal.
              </Typography>
            </Box>
          )}

          {/* Quick actions — staff2 */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px' }}>
            {[
              { label: 'Maintenance', sub: 'Log service/repair', color: '#7c3aed', path: '/maintenance' },
              { label: 'Fleet', sub: 'Check documents', color: '#1a2744', path: '/fleet' },
              { label: 'Drivers', sub: 'Manage drivers', color: '#059669', path: '/drivers' },
            ].map(q => (
              <Box key={q.label} onClick={() => nav(q.path)} sx={{ bgcolor: q.color, borderRadius: '8px', p: '12px 14px', cursor: 'pointer', transition: 'opacity 0.15s', '&:hover': { opacity: 0.9 } }}>
                <Typography sx={{ color: '#fff', fontWeight: 600, fontSize: 13 }}>{q.label}</Typography>
                <Typography sx={{ color: 'rgba(255,255,255,0.65)', fontSize: 11, mt: 0.3 }}>{q.sub}</Typography>
              </Box>
            ))}
          </Box>
        </>
      )}
    </Box>
  );
}
