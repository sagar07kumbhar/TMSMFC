import React, { useState, useEffect } from 'react';
import { toDateStr, displayDate, daysUntil } from '../utils/dateUtils';
import { Box, Typography, Button, Tabs, Tab, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Grid } from '@mui/material';
import { Add } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';

const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;
const fmtL = n => { const v=+n||0; return v>=100000?`₹${(v/100000).toFixed(1)}L`:v>=1000?`₹${(v/1000).toFixed(0)}K`:`₹${v}`; };

const TYRE_POSITIONS = [
  { id:'T1',  label:'T1',  axle:'Front axle',   side:'Left' },
  { id:'T2',  label:'T2',  axle:'Front axle',   side:'Right' },
  { id:'T3',  label:'T3',  axle:'Mid axle 1',   side:'Left outer' },
  { id:'T4',  label:'T4',  axle:'Mid axle 1',   side:'Left inner' },
  { id:'T5',  label:'T5',  axle:'Mid axle 1',   side:'Right inner' },
  { id:'T6',  label:'T6',  axle:'Mid axle 1',   side:'Right outer' },
  { id:'T7',  label:'T7',  axle:'Mid axle 2',   side:'Left outer' },
  { id:'T8',  label:'T8',  axle:'Mid axle 2',   side:'Left inner' },
  { id:'T9',  label:'T9',  axle:'Mid axle 2',   side:'Right inner' },
  { id:'T10', label:'T10', axle:'Mid axle 2',   side:'Right outer' },
  { id:'T11', label:'T11', axle:'Rear axle',    side:'Left outer' },
  { id:'T12', label:'T12', axle:'Rear axle',    side:'Left inner' },
  { id:'T13', label:'T13', axle:'Rear axle',    side:'Right inner' },
  { id:'T14', label:'T14', axle:'Rear axle',    side:'Right outer' },
  { id:'SPARE', label:'SP', axle:'Spare', side:'' },
];

const AXLES = ['Front axle','Mid axle 1','Mid axle 2','Rear axle','Spare'];

function TyreGrid({ logs }) {
  const currentByPos = {};
  (logs||[]).forEach(l => {
    if (!currentByPos[l.position] || toDateStr(l.event_date) > toDateStr(currentByPos[l.position].event_date))
      currentByPos[l.position] = l;
  });

  const getStatus = (pos) => {
    const l = currentByPos[pos];
    if (!l || l.event_type==='removal') return 'empty';
    if ((l.km_run||0) >= 60000) return 'warn';
    return 'ok';
  };

  return (
    <Box>
      {AXLES.map(axle => {
        const positions = TYRE_POSITIONS.filter(p => p.axle===axle);
        return (
          <Box key={axle} sx={{ display:'flex', alignItems:'center', gap:'10px', mb:'10px' }}>
            <Typography sx={{ fontSize:11, color:'#6b7a99', width:80, flexShrink:0, fontWeight:500 }}>{axle}</Typography>
            <Box sx={{ display:'flex', gap:'6px', alignItems:'center' }}>
              {positions.map((p, i) => {
                const st = getStatus(p.id);
                const mid = positions.length > 2 && i === Math.floor(positions.length/2) - (positions.length===4?0:1);
                return (
                  <React.Fragment key={p.id}>
                    {mid && <Box sx={{ width:2, height:28, bgcolor:'#e2e8f0' }}/>}
                    <Box title={`${p.id} — ${p.side}`} sx={{
                      width:44, height:28, borderRadius:'5px', display:'flex', alignItems:'center', justifyContent:'center',
                      fontSize:11, fontWeight:500, cursor:'pointer', border:'1.5px solid',
                      ...(st==='ok'   ? { bgcolor:'#dcfce7', borderColor:'#16a34a', color:'#166534' } :
                          st==='warn' ? { bgcolor:'#fef9c3', borderColor:'#d97706', color:'#854d0e' } :
                                        { bgcolor:'#f8fafc', borderColor:'#e2e8f0', color:'#9ca3af', borderStyle:'dashed' })
                    }}>{p.label}</Box>
                  </React.Fragment>
                );
              })}
            </Box>
          </Box>
        );
      })}
      <Box sx={{ display:'flex', gap:2, mt:1, pt:1, borderTop:'0.5px solid #e2e6ef' }}>
        {[['#dcfce7','#16a34a','Good (0–60k km)'],['#fef9c3','#d97706','Worn (60k+ km)'],['#f8fafc','#e2e8f0','Empty slot']].map(([bg,border,label])=>(
          <Box key={label} sx={{ display:'flex', alignItems:'center', gap:'4px' }}>
            <Box sx={{ width:14, height:14, borderRadius:'3px', bgcolor:bg, border:`1.5px solid ${border}` }}/>
            <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{label}</Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

export default function Maintenance() {
  const [trucks, setTrucks]       = useState([]);
  const [selTruck, setSelTruck]   = useState('');
  const [summary, setSummary]     = useState(null);
  const [logs, setLogs]           = useState([]);
  const [tyreLogs, setTyreLogs]   = useState([]);
  const [tab, setTab]             = useState(0);
  const [open, setOpen]           = useState(false);
  const [tyreOpen, setTyreOpen]   = useState(false);
  const [form, setForm]           = useState({});
  const [tyreForm, setTyreForm]   = useState({});
  const showToast = useToast();

  useEffect(() => { api.get('/trucks').then(r => { setTrucks(r.data||[]); if(r.data?.length) setSelTruck(String(r.data[0].id)); }); }, []);

  useEffect(() => {
    if (!selTruck) return;
    api.get(`/maintenance?truck_id=${selTruck}`).then(r => setLogs(r.data||[])).catch(()=>setLogs([]));
    api.get(`/tyres?truck_id=${selTruck}`).then(r => setTyreLogs(r.data||[])).catch(()=>setTyreLogs([]));
    api.get(`/dashboard/truck-summary/${selTruck}`).then(r => setSummary(r.data)).catch(()=>setSummary(null));
  }, [selTruck]);

  const saveLog = async () => {
    if (!form.log_type||!form.service_date||!form.cost) { showToast('Fill required fields','error'); return; }
    try {
      await api.post('/maintenance', { ...form, truck_id:selTruck });
      setOpen(false);
      api.get(`/maintenance?truck_id=${selTruck}`).then(r=>setLogs(r.data||[]));
      showToast('Log saved','success');
    } catch { showToast('Failed to save','error'); }
  };

  const saveTyre = async () => {
    if (!tyreForm.position||!tyreForm.event_type||!tyreForm.event_date||!tyreForm.odometer_reading) { showToast('Fill required fields','error'); return; }
    try {
      await api.post('/tyres', { ...tyreForm, truck_id:selTruck });
      setTyreOpen(false);
      api.get(`/tyres?truck_id=${selTruck}`).then(r=>setTyreLogs(r.data||[]));
      showToast('Tyre log saved','success');
    } catch { showToast('Failed to save','error'); }
  };

  const filtered = (type) => logs.filter(l => l.log_type===type);
  const totalCost = (type) => filtered(type).reduce((s,l)=>s+(+l.cost||0),0);

  const brandStats = () => {
    const map = {};
    tyreLogs.filter(l=>l.event_type==='new_fit').forEach(l => {
      if (!l.tyre_brand) return;
      if (!map[l.tyre_brand]) map[l.tyre_brand] = { brand:l.tyre_brand, count:0, totalKm:0, totalCost:0 };
      map[l.tyre_brand].count++;
      map[l.tyre_brand].totalKm += +l.km_run||0;
      map[l.tyre_brand].totalCost += +l.purchase_cost||0;
    });
    return Object.values(map).map(b => ({ ...b, avgKm:b.count?Math.round(b.totalKm/b.count):0, costPerKm:b.totalKm>0?(b.totalCost/b.totalKm).toFixed(2):0 })).sort((a,b)=>b.avgKm-a.avgKm);
  };

  const TABS = ['Tyres','Servicing','Fuel log','Repairs','Documents','Full history'];

  return (
    <Box>
      {/* Truck selector */}
      <Box sx={{ display:'flex', alignItems:'center', gap:2, mb:2 }}>
        <TextField select label="Select truck" size="small" value={selTruck} onChange={e=>setSelTruck(e.target.value)} sx={{ minWidth:240 }}>
          {trucks.map(t=><MenuItem key={t.id} value={String(t.id)}>{t.truck_number} — {t.make} {t.model}</MenuItem>)}
        </TextField>
        {selTruck && (
          <Box sx={{ display:'flex', gap:1 }}>
            <Button size="small" variant="outlined" startIcon={<Add/>} onClick={()=>{ setForm({ log_type:'servicing', service_date:new Date().toISOString().slice(0,10), cost:0 }); setOpen(true); }} sx={{ fontSize:11.5, borderColor:'#2563eb', color:'#2563eb' }}>Add log</Button>
            <Button size="small" variant="outlined" startIcon={<Add/>} onClick={()=>{ setTyreForm({ event_type:'new_fit', event_date:new Date().toISOString().slice(0,10), purchase_cost:0 }); setTyreOpen(true); }} sx={{ fontSize:11.5, borderColor:'#7c3aed', color:'#7c3aed' }}>Log tyre</Button>
          </Box>
        )}
      </Box>

      {/* Truck summary card */}
      {summary && (
        <Box sx={{ bgcolor:'#1a2744', borderRadius:'8px', p:'14px', mb:2, display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:'10px' }}>
          {[
            ['Revenue (FY)', fmtL(summary.total_revenue),'#60a5fa'],
            ['Trips', summary.total_trips,'#fff'],
            ['Total km', `${(summary.total_km||0).toLocaleString('en-IN')} km`,'#fff'],
            ['Maintenance cost', fmtL(summary.total_maintenance_cost),'#fca5a5'],
            ['Fuel cost', fmtL(summary.fuel_cost),'#fcd34d'],
            ['Net contribution', fmtL(summary.net_contribution), +summary.net_contribution>=0?'#4ade80':'#f87171'],
          ].map(([l,v,c])=>(
            <Box key={l} sx={{ textAlign:'center' }}>
              <Typography sx={{ fontSize:10, color:'rgba(255,255,255,0.5)', mb:0.3 }}>{l}</Typography>
              <Typography sx={{ fontSize:15, fontWeight:600, color:c }}>{v}</Typography>
            </Box>
          ))}
        </Box>
      )}

      {/* Tabs */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Tabs value={tab} onChange={(_,v)=>setTab(v)} sx={{ borderBottom:'0.5px solid #e2e6ef', '& .MuiTab-root':{ fontSize:12, minHeight:40, textTransform:'none', color:'#6b7a99' }, '& .Mui-selected':{ color:'#1a2744', fontWeight:500 }, '& .MuiTabs-indicator':{ bgcolor:'#1a2744' } }}>
          {TABS.map(t=><Tab key={t} label={t}/>)}
        </Tabs>

        <Box sx={{ p:'14px' }}>

          {/* TYRES */}
          {tab===0 && (
            <Box>
              <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:1.5 }}>Tyre positions — click any position to log a change</Typography>
              <TyreGrid logs={tyreLogs}/>
              {/* Current tyre status table */}
              <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mt:2, mb:1 }}>Current tyre status</Typography>
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>
                  {['Position','Brand','Size','Fitted at (odo)','Km run','Cost','Status'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {tyreLogs.filter(l=>l.event_type==='new_fit').map(l=>(
                    <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'7px 10px', fontSize:12, fontWeight:500 }}>{l.position}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.tyre_brand||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.tyre_size||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{(l.odometer_reading||0).toLocaleString('en-IN')} km</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{(l.km_run||0).toLocaleString('en-IN')} km</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{fmt(l.purchase_cost)}</td>
                      <td style={{ padding:'7px 10px' }}>
                        <span style={{ display:'inline-block', padding:'2px 7px', borderRadius:20, fontSize:11, fontWeight:500, background:(l.km_run||0)>=60000?'#fef9c3':'#dcfce7', color:(l.km_run||0)>=60000?'#854d0e':'#166534' }}>{(l.km_run||0)>=60000?'Worn':'Good'}</span>
                      </td>
                    </tr>
                  ))}
                  {!tyreLogs.length && <tr><td colSpan={7} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No tyre logs yet. Click "Log tyre" to start.</td></tr>}
                </tbody>
              </table>

              {/* Brand analytics */}
              {brandStats().length>0 && (
                <Box sx={{ mt:2 }}>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:1 }}>Brand performance analytics</Typography>
                  <table style={{ width:'100%', borderCollapse:'collapse' }}>
                    <thead><tr style={{ background:'#fafbfc' }}>
                      {['Brand','Tyres used','Avg km/tyre','Avg cost','Cost/km','Rating'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}
                    </tr></thead>
                    <tbody>
                      {brandStats().map((b,i)=>(
                        <tr key={b.brand} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                          <td style={{ padding:'7px 10px', fontSize:12, fontWeight:500 }}>{b.brand}</td>
                          <td style={{ padding:'7px 10px', fontSize:12 }}>{b.count}</td>
                          <td style={{ padding:'7px 10px', fontSize:12 }}>{b.avgKm.toLocaleString('en-IN')} km</td>
                          <td style={{ padding:'7px 10px', fontSize:12 }}>{fmt(b.totalCost/b.count)}</td>
                          <td style={{ padding:'7px 10px', fontSize:12 }}>₹{b.costPerKm}/km</td>
                          <td style={{ padding:'7px 10px' }}>
                            <span style={{ display:'inline-block', padding:'2px 7px', borderRadius:20, fontSize:11, fontWeight:500, background:i===0?'#dcfce7':'#f1f5f9', color:i===0?'#166534':'#475569' }}>{i===0?'Best':'Good'}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Box>
              )}
            </Box>
          )}

          {/* SERVICING */}
          {tab===1 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'10px', mb:2 }}>
                {[['Total servicing cost',fmt(totalCost('servicing')),'#2563eb'],['Oil changes',filtered('servicing').filter(l=>l.description?.toLowerCase().includes('oil')).length,'#1a2744'],['Brake services',filtered('servicing').filter(l=>l.description?.toLowerCase().includes('brake')).length,'#1a2744'],['Logs total',filtered('servicing').length,'#1a2744']].map(([l,v,c])=>(
                  <Box key={l} sx={{ bgcolor:'#f8fafc', borderRadius:'6px', p:'10px 12px', border:'0.5px solid #e2e6ef' }}>
                    <Typography sx={{ fontSize:10, color:'#6b7a99', mb:0.3 }}>{l}</Typography>
                    <Typography sx={{ fontSize:17, fontWeight:500, color:c }}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Date','Type','Description','Odometer','Cost','Next due','Vendor'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {filtered('servicing').map(l=>(
                    <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{displayDate(l.service_date)}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.log_type}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.odometer_reading?`${l.odometer_reading.toLocaleString('en-IN')} km`:'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{fmt(l.cost)}</td>
                      <td style={{ padding:'7px 10px', fontSize:12, color:l.next_service_date&&new Date(l.next_service_date)<new Date()?'#dc2626':'#374151' }}>{l.next_service_date?new Date(l.next_service_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.vendor_name||'—'}</td>
                    </tr>
                  ))}
                  {!filtered('servicing').length&&<tr><td colSpan={7} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No servicing logs yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}

          {/* FUEL */}
          {tab===2 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'10px', mb:2 }}>
                {[['Total fuel cost',fmt(totalCost('fuel')),'#dc2626'],['Fill-ups',filtered('fuel').length,'#1a2744'],['Avg mileage','4.2 km/L','#16a34a'],['Cost/km','₹22/km','#1a2744']].map(([l,v,c])=>(
                  <Box key={l} sx={{ bgcolor:'#f8fafc', borderRadius:'6px', p:'10px 12px', border:'0.5px solid #e2e6ef' }}>
                    <Typography sx={{ fontSize:10, color:'#6b7a99', mb:0.3 }}>{l}</Typography>
                    <Typography sx={{ fontSize:17, fontWeight:500, color:c }}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Date','Litres','Rate/L','Amount','Odometer','Mileage','Location'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {filtered('fuel').map(l=>(
                    <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{displayDate(l.service_date, {day:'2-digit',month:'short'})}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description?.split('|')[0]||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description?.split('|')[1]||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{fmt(l.cost)}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.odometer_reading?`${l.odometer_reading.toLocaleString('en-IN')} km`:'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description?.split('|')[2]||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.vendor_name||'—'}</td>
                    </tr>
                  ))}
                  {!filtered('fuel').length&&<tr><td colSpan={7} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No fuel logs yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}

          {/* REPAIRS */}
          {tab===3 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', mb:2 }}>
                {[['Total repair cost',fmt(totalCost('repair')),'#dc2626'],['Repair incidents',filtered('repair').length,'#1a2744'],['Avg repair cost',filtered('repair').length?fmt(totalCost('repair')/filtered('repair').length):'₹0','#1a2744']].map(([l,v,c])=>(
                  <Box key={l} sx={{ bgcolor:'#f8fafc', borderRadius:'6px', p:'10px 12px', border:'0.5px solid #e2e6ef' }}>
                    <Typography sx={{ fontSize:10, color:'#6b7a99', mb:0.3 }}>{l}</Typography>
                    <Typography sx={{ fontSize:17, fontWeight:500, color:c }}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Date','Problem','Description','Cost','Vendor','Notes'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {filtered('repair').map(l=>(
                    <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{displayDate(l.service_date, {day:'2-digit',month:'short'})}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.log_type}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{fmt(l.cost)}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.vendor_name||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.notes||'—'}</td>
                    </tr>
                  ))}
                  {!filtered('repair').length&&<tr><td colSpan={6} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No repair logs yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}

          {/* DOCUMENTS */}
          {tab===4 && (
            <Box>
              {filtered('document').length===0
                ? <Typography sx={{ fontSize:12, color:'#6b7a99', p:2 }}>No document logs yet. Add a log with type "document" to track RC/PUC/Fitness/Insurance/Permit.</Typography>
                : <table style={{ width:'100%', borderCollapse:'collapse' }}>
                    <thead><tr style={{ background:'#fafbfc' }}>{['Document','Number','Issue date','Expiry date','Days left','Status'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                    <tbody>
                      {filtered('document').map(l=>{
                        const days = daysUntil(l.doc_expiry);
                        return (
                          <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                            <td style={{ padding:'7px 10px', fontSize:12, fontWeight:500 }}>{l.doc_type||l.description||'Document'}</td>
                            <td style={{ padding:'7px 10px', fontSize:12 }}>{l.notes||'—'}</td>
                            <td style={{ padding:'7px 10px', fontSize:12 }}>{displayDate(l.service_date)}</td>
                            <td style={{ padding:'7px 10px', fontSize:12 }}>{l.doc_expiry?displayDate(l.doc_expiry):'—'}</td>
                            <td style={{ padding:'7px 10px', fontSize:12, color:days!==null&&days<30?'#d97706':undefined }}>{days!==null?`${days} days`:'—'}</td>
                            <td style={{ padding:'7px 10px' }}>
                              <span style={{ display:'inline-block', padding:'2px 7px', borderRadius:20, fontSize:11, fontWeight:500, background:days===null?'#f1f5f9':days<0?'#fee2e2':days<30?'#fef9c3':'#dcfce7', color:days===null?'#475569':days<0?'#991b1b':days<30?'#854d0e':'#166534' }}>{days===null?'N/A':days<0?'Expired':days<30?'Expiring soon':'Valid'}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
              }
            </Box>
          )}

          {/* FULL HISTORY */}
          {tab===5 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:'10px', mb:2 }}>
                {[['Servicing',fmt(totalCost('servicing')),'#2563eb'],['Fuel',fmt(totalCost('fuel')),'#dc2626'],['Repairs',fmt(totalCost('repair')),'#7c3aed'],['Tyres',fmt(tyreLogs.filter(l=>l.event_type==='new_fit').reduce((s,l)=>s+(+l.purchase_cost||0),0)),'#f59e0b'],['Total',fmt(totalCost('servicing')+totalCost('fuel')+totalCost('repair')),'#1a2744']].map(([l,v,c])=>(
                  <Box key={l} sx={{ bgcolor:'#f8fafc', borderRadius:'6px', p:'10px 12px', border:'0.5px solid #e2e6ef' }}>
                    <Typography sx={{ fontSize:10, color:'#6b7a99', mb:0.3 }}>{l}</Typography>
                    <Typography sx={{ fontSize:17, fontWeight:500, color:c }}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Date','Category','Description','Odometer','Cost','Vendor'].map(h=><th key={h} style={{ padding:'7px 10px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {[...logs].sort((a,b)=>new Date(b.service_date)-new Date(a.service_date)).map(l=>(
                    <tr key={l.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{displayDate(l.service_date)}</td>
                      <td style={{ padding:'7px 10px' }}>
                        <span style={{ display:'inline-block', padding:'2px 7px', borderRadius:20, fontSize:11, fontWeight:500, background:{servicing:'#dbeafe',fuel:'#fee2e2',repair:'#ede9fe',document:'#dcfce7',other:'#f1f5f9'}[l.log_type]||'#f1f5f9', color:{servicing:'#1e40af',fuel:'#991b1b',repair:'#6d28d9',document:'#166534',other:'#475569'}[l.log_type]||'#475569' }}>{l.log_type}</span>
                      </td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.description||'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.odometer_reading?`${l.odometer_reading.toLocaleString('en-IN')} km`:'—'}</td>
                      <td style={{ padding:'7px 10px', fontSize:12, fontWeight:500 }}>{fmt(l.cost)}</td>
                      <td style={{ padding:'7px 10px', fontSize:12 }}>{l.vendor_name||'—'}</td>
                    </tr>
                  ))}
                  {!logs.length&&<tr><td colSpan={6} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No maintenance logs yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}
        </Box>
      </Box>

      {/* Add maintenance log dialog */}
      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>Add maintenance log</DialogTitle>
        <DialogContent sx={{ pt:1 }}>
          <Grid container spacing={1.5}>
            <Grid item xs={6}><TextField select label="Category *" fullWidth value={form.log_type||''} onChange={e=>setForm(p=>({...p,log_type:e.target.value}))}>
              {[['servicing','Servicing / Oil change'],['fuel','Fuel fill-up'],['repair','Repair'],['document','Document renewal'],['other','Other']].map(([v,l])=><MenuItem key={v} value={v}>{l}</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={6}><TextField label="Date *" type="date" fullWidth value={form.service_date||''} onChange={e=>setForm(p=>({...p,service_date:e.target.value}))} InputLabelProps={{shrink:true}}/></Grid>
            <Grid item xs={12}><TextField label="Description" fullWidth value={form.description||''} onChange={e=>setForm(p=>({...p,description:e.target.value}))} placeholder="e.g. Engine oil + oil filter replaced"/></Grid>
            <Grid item xs={4}><TextField label="Cost ₹ *" type="number" fullWidth value={form.cost||''} onChange={e=>setForm(p=>({...p,cost:e.target.value}))}/></Grid>
            <Grid item xs={4}><TextField label="Odometer (km)" type="number" fullWidth value={form.odometer_reading||''} onChange={e=>setForm(p=>({...p,odometer_reading:e.target.value}))}/></Grid>
            <Grid item xs={4}><TextField label="Vendor" fullWidth value={form.vendor_name||''} onChange={e=>setForm(p=>({...p,vendor_name:e.target.value}))}/></Grid>
            <Grid item xs={6}><TextField label="Next service date" type="date" fullWidth value={form.next_service_date||''} onChange={e=>setForm(p=>({...p,next_service_date:e.target.value}))} InputLabelProps={{shrink:true}}/></Grid>
            <Grid item xs={6}><TextField label="Notes" fullWidth value={form.notes||''} onChange={e=>setForm(p=>({...p,notes:e.target.value}))}/></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2 }}>
          <Button onClick={()=>setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={saveLog} sx={{ bgcolor:'#1a2744' }}>Save log</Button>
        </DialogActions>
      </Dialog>

      {/* Add tyre log dialog */}
      <Dialog open={tyreOpen} onClose={()=>setTyreOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>Log tyre change</DialogTitle>
        <DialogContent sx={{ pt:1 }}>
          <Grid container spacing={1.5}>
            <Grid item xs={6}><TextField select label="Position *" fullWidth value={tyreForm.position||''} onChange={e=>setTyreForm(p=>({...p,position:e.target.value}))}>
              {TYRE_POSITIONS.map(p=><MenuItem key={p.id} value={p.id}>{p.id} — {p.side||p.axle}</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={6}><TextField select label="Event *" fullWidth value={tyreForm.event_type||'new_fit'} onChange={e=>setTyreForm(p=>({...p,event_type:e.target.value}))}>
              <MenuItem value="new_fit">New fit</MenuItem>
              <MenuItem value="removal">Removal</MenuItem>
              <MenuItem value="rotation">Rotation</MenuItem>
            </TextField></Grid>
            <Grid item xs={6}><TextField label="Date *" type="date" fullWidth value={tyreForm.event_date||''} onChange={e=>setTyreForm(p=>({...p,event_date:e.target.value}))} InputLabelProps={{shrink:true}}/></Grid>
            <Grid item xs={6}><TextField label="Odometer (km) *" type="number" fullWidth value={tyreForm.odometer_reading||''} onChange={e=>setTyreForm(p=>({...p,odometer_reading:e.target.value}))}/></Grid>
            <Grid item xs={6}><TextField select label="Brand" fullWidth value={tyreForm.tyre_brand||''} onChange={e=>setTyreForm(p=>({...p,tyre_brand:e.target.value}))}>
              {['MRF','Apollo','CEAT','Bridgestone','JK Tyre','Goodyear','Other'].map(b=><MenuItem key={b} value={b}>{b}</MenuItem>)}
            </TextField></Grid>
            <Grid item xs={6}><TextField label="Size" fullWidth value={tyreForm.tyre_size||''} onChange={e=>setTyreForm(p=>({...p,tyre_size:e.target.value}))} placeholder="e.g. 295/80 R22.5"/></Grid>
            <Grid item xs={6}><TextField label="Serial no." fullWidth value={tyreForm.tyre_serial||''} onChange={e=>setTyreForm(p=>({...p,tyre_serial:e.target.value}))}/></Grid>
            <Grid item xs={6}><TextField label="Purchase cost ₹" type="number" fullWidth value={tyreForm.purchase_cost||''} onChange={e=>setTyreForm(p=>({...p,purchase_cost:e.target.value}))}/></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2 }}>
          <Button onClick={()=>setTyreOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={saveTyre} sx={{ bgcolor:'#7c3aed' }}>Save tyre log</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
