import React from 'react';

export default function MFCLogo({ size = 48, showText = true, textColor = '#fff', variant = 'full' }) {
  const s = size;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      {/* Truck SVG icon */}
      <svg width={s} height={s} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Truck body */}
        <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.15" stroke="#fff" strokeWidth="1.5"/>
        {/* Cab */}
        <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.15" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round"/>
        {/* Windshield */}
        <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.35"/>
        {/* Cargo lines on body */}
        <line x1="10" y1="22" x2="10" y2="30" stroke="#fff" strokeWidth="0.8" strokeOpacity="0.5"/>
        <line x1="16" y1="22" x2="16" y2="30" stroke="#fff" strokeWidth="0.8" strokeOpacity="0.5"/>
        <line x1="22" y1="22" x2="22" y2="30" stroke="#fff" strokeWidth="0.8" strokeOpacity="0.5"/>
        {/* Wheels */}
        <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.5"/>
        <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.6"/>
        <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.5"/>
        <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.6"/>
        {/* Road line */}
        <line x1="2" y1="38" x2="46" y2="38" stroke="#fff" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="4 3"/>
        {/* Headlight */}
        <rect x="41" y="27" width="3" height="2" rx="1" fill="#FCD34D"/>
        {/* Speed lines */}
        <line x1="2" y1="24" x2="6" y2="24" stroke="#fff" strokeWidth="1" strokeOpacity="0.4" strokeLinecap="round"/>
        <line x1="2" y1="27" x2="5" y2="27" stroke="#fff" strokeWidth="0.8" strokeOpacity="0.3" strokeLinecap="round"/>
        <line x1="2" y1="30" x2="6" y2="30" stroke="#fff" strokeWidth="1" strokeOpacity="0.4" strokeLinecap="round"/>
      </svg>

      {showText && variant === 'full' && (
        <div>
          <div style={{ color: textColor, fontWeight: 700, fontSize: s * 0.29, lineHeight: 1.2, letterSpacing: '-0.3px' }}>
            Mumbai Freight Carriers
          </div>
          <div style={{ color: textColor, opacity: 0.55, fontSize: s * 0.19, marginTop: 1 }}>
            Nigdi, Pune
          </div>
        </div>
      )}

      {showText && variant === 'short' && (
        <div style={{ color: textColor, fontWeight: 700, fontSize: s * 0.33, letterSpacing: '-0.3px' }}>
          MFC Portal
        </div>
      )}
    </div>
  );
}

// Standalone circle badge version for small spaces
export function MFCBadge({ size = 40 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: '#1a2744', display: 'flex', alignItems: 'center',
      justifyContent: 'center', flexShrink: 0,
      border: '2px solid rgba(255,255,255,0.2)'
    }}>
      <svg width={size * 0.65} height={size * 0.65} viewBox="0 0 48 48" fill="none">
        <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8"/>
        <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round"/>
        <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.5"/>
        <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
        <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
        <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
        <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
        <rect x="41" y="27" width="3" height="2" rx="1" fill="#FCD34D"/>
      </svg>
    </div>
  );
}
