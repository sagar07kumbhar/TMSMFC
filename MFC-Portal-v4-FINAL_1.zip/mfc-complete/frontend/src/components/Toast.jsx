import React, { createContext, useContext, useState, useCallback } from 'react';
import { Snackbar, Alert } from '@mui/material';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toast, setToast] = useState({ open: false, message: '', severity: 'success' });
  const showToast = useCallback((message, severity = 'success') => {
    setToast({ open: true, message, severity });
  }, []);
  const close = () => setToast(t => ({ ...t, open: false }));
  return (
    <ToastContext.Provider value={showToast}>
      {children}
      <Snackbar open={toast.open} autoHideDuration={3500} onClose={close} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert onClose={close} severity={toast.severity} variant="filled" sx={{ borderRadius: 2, fontSize: 13, fontWeight: 500 }}>
          {toast.message}
        </Alert>
      </Snackbar>
    </ToastContext.Provider>
  );
}

export const useToast = () => useContext(ToastContext);
