import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Box, Typography, Tooltip } from '@mui/material';
import { useAuth } from '../context/AuthContext';
import { getNavForRole } from '../utils/permissions';
import usePermissions from '../hooks/usePermissions';

const ICONS = {
  dashboard:   'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',
  trips:       'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7',
  invoices:    'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
  consignees:  'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4',
  fleet:       'M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0H3m16 0h2',
  drivers:     'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
  maintenance: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
  brokerage:   'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4',
  owners:      'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z',
  analytics:   'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
  ai:          'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z',
  settings:    'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4',
};

const ROLE_LABELS = { admin: 'Admin', staff1: 'Operations', staff2: 'Fleet & Maintenance' };
const ROLE_COLORS = { admin: '#2563eb', staff1: '#16a34a', staff2: '#7c3aed' };

function NavIcon({ page }) {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d={ICONS[page] || ICONS.dashboard}/>
    </svg>
  );
}

const W = 220;

export default function Layout() {
  const { user, logout } = useAuth();
  const { role }         = usePermissions();
  const nav              = useNavigate();
  const loc              = useLocation();
  const navItems         = getNavForRole(role);
  const currentPage      = navItems.find(n => n.path === loc.pathname);

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden', bgcolor: '#f0f2f7' }}>
      {/* Sidebar */}
      <Box sx={{ width: W, flexShrink: 0, bgcolor: '#1a2744', display: 'flex', flexDirection: 'column' }}>

        {/* Logo */}
        <Box sx={{ p: '16px 14px 14px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
            <Box sx={{ width: 34, height: 34, borderRadius: '8px', bgcolor: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, border: '1px solid rgba(255,255,255,0.12)' }}>
              <svg width="22" height="22" viewBox="0 0 48 48" fill="none">
                <rect x="4" y="18" width="26" height="16" rx="2" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8"/>
                <path d="M30 22 L30 34 L44 34 L44 26 L38 22 Z" fill="#fff" fillOpacity="0.2" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round"/>
                <path d="M32 23.5 L32 27 L42 27 L42 25.5 L37 23.5 Z" fill="#fff" fillOpacity="0.45"/>
                <circle cx="12" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
                <circle cx="12" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
                <circle cx="36" cy="34" r="4" fill="#1a2744" stroke="#fff" strokeWidth="1.8"/>
                <circle cx="36" cy="34" r="1.5" fill="#fff" fillOpacity="0.7"/>
                <rect x="41" y="27" width="3" height="2" rx="1" fill="#FCD34D"/>
              </svg>
            </Box>
            <Box>
              <Typography sx={{ color: '#fff', fontWeight: 700, fontSize: 13, lineHeight: 1.2 }}>MFC Portal</Typography>
              <Typography sx={{ color: 'rgba(255,255,255,0.4)', fontSize: 10 }}>Mumbai Freight Carriers</Typography>
            </Box>
          </Box>
        </Box>

        {/* Nav */}
        <Box sx={{ flex: 1, overflowY: 'auto', py: 1, '&::-webkit-scrollbar': { width: 3 }, '&::-webkit-scrollbar-thumb': { background: 'rgba(255,255,255,0.15)', borderRadius: 2 } }}>
          {navItems.map((item) => {
            const active = loc.pathname === item.path;
            // Track sections to show headers
            return (
              <Box key={item.path}>
                {item.section && (
                  <Typography sx={{ px: '14px', pt: '10px', pb: '3px', fontSize: 9.5, color: 'rgba(255,255,255,0.28)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>
                    {item.section}
                  </Typography>
                )}
                <Box onClick={() => nav(item.path)} sx={{
                  display: 'flex', alignItems: 'center', gap: 1.2,
                  px: '14px', py: '8px', cursor: 'pointer',
                  color: active ? '#fff' : 'rgba(255,255,255,0.6)',
                  bgcolor: active ? 'rgba(255,255,255,0.1)' : 'transparent',
                  borderLeft: `2px solid ${active ? '#60a5fa' : 'transparent'}`,
                  fontSize: 12.5, fontWeight: active ? 500 : 400,
                  transition: 'all 0.15s',
                  '&:hover': { bgcolor: 'rgba(255,255,255,0.07)', color: '#fff' }
                }}>
                  <Box sx={{ flexShrink: 0 }}><NavIcon page={item.page} /></Box>
                  {item.label}
                </Box>
              </Box>
            );
          })}
        </Box>

        {/* User info + role badge + signout */}
        <Box sx={{ p: '10px 14px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
            <Box sx={{ width: 30, height: 30, borderRadius: '50%', bgcolor: ROLE_COLORS[role] || '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
              {user?.name?.[0]?.toUpperCase() || 'U'}
            </Box>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography sx={{ color: '#fff', fontSize: 12, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {user?.name}
              </Typography>
              {/* Role badge */}
              <Box sx={{ display: 'inline-flex', alignItems: 'center', bgcolor: 'rgba(255,255,255,0.1)', borderRadius: '3px', px: 0.8, py: 0.2, mt: 0.3 }}>
                <Typography sx={{ fontSize: 9.5, color: 'rgba(255,255,255,0.7)', fontWeight: 500, letterSpacing: '0.03em' }}>
                  {ROLE_LABELS[role] || role}
                </Typography>
              </Box>
            </Box>
          </Box>
          <Box onClick={() => { logout(); nav('/login'); }} sx={{
            display: 'flex', alignItems: 'center', gap: 1,
            color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: 12, py: 0.5,
            '&:hover': { color: '#fff' }, transition: 'color 0.15s'
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
            </svg>
            Sign out
          </Box>
        </Box>
      </Box>

      {/* Main */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        <Box sx={{ bgcolor: '#fff', borderBottom: '0.5px solid #e2e6ef', px: '20px', height: 52, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <Typography sx={{ fontSize: 15, fontWeight: 500, color: '#1a2744' }}>
            {currentPage?.label || 'MFC Portal'}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography sx={{ fontSize: 12, color: '#6b7a99' }}>
              {new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}
            </Typography>
            <Box sx={{ width: 1, height: 20, bgcolor: '#e2e6ef' }}/>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: ROLE_COLORS[role] || '#2563eb' }}/>
              <Typography sx={{ fontSize: 12, color: '#6b7a99' }}>{user?.name} · {ROLE_LABELS[role]}</Typography>
            </Box>
          </Box>
        </Box>
        <Box sx={{ flex: 1, overflowY: 'auto', p: '16px 20px' }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
}
