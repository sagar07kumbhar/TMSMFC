import React from 'react';
import { Navigate } from 'react-router-dom';
import { Box, Typography, Button } from '@mui/material';
import { LockOutlined } from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { canAccessPage } from '../utils/permissions';
import { useNavigate } from 'react-router-dom';

// Route guard — wraps protected pages
export function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  return user ? children : <Navigate to="/login" replace />;
}

// Page-level access guard — redirects to 403 if role not allowed
export function RoleRoute({ page, children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (!canAccessPage(user.role, page)) return <AccessDenied />;
  return children;
}

// 403 page shown when a role tries to access a restricted page
export function AccessDenied() {
  const nav = useNavigate();
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', textAlign: 'center' }}>
      <Box sx={{ width: 64, height: 64, borderRadius: '50%', bgcolor: '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
        <LockOutlined sx={{ fontSize: 28, color: '#dc2626' }} />
      </Box>
      <Typography sx={{ fontSize: 18, fontWeight: 600, color: '#1a2744', mb: 1 }}>Access restricted</Typography>
      <Typography sx={{ fontSize: 13, color: '#6b7a99', maxWidth: 320, mb: 3 }}>
        You don't have permission to view this page. Contact your admin if you need access.
      </Typography>
      <Button variant="contained" onClick={() => nav('/dashboard')}
        sx={{ bgcolor: '#1a2744', fontSize: 13 }}>
        Go to dashboard
      </Button>
    </Box>
  );
}
