// ============================================================
// MFC Portal — Date utilities
// Central place for all date handling to prevent timezone bugs
//
// ROOT CAUSE: MySQL DATE columns returned as JS Date objects
// at midnight UTC shift to the previous day when converted
// to local time (IST = UTC+5:30).
//
// FIX: dateStrings:true in db.js means MySQL now returns
// plain 'YYYY-MM-DD' strings. These functions handle both
// old Date objects and new strings safely.
// ============================================================

/**
 * Convert ANY date value to a plain 'YYYY-MM-DD' string.
 * Safe for: JS Date objects, ISO strings, MySQL date strings, null/undefined.
 * Never uses new Date() internally so no timezone shifting.
 */
export function toDateStr(v) {
  if (!v) return '';
  const s = String(v);
  // Already clean YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  // ISO string '2026-06-20T00:00:00.000Z' — take first 10 chars only
  if (s.length > 10 && s[10] === 'T') return s.slice(0, 10);
  // JS Date object .toString() or other formats — extract with regex
  const m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : '';
}

/**
 * Format a date for display in Indian format: '20 Jun 2026'
 * Appends T12:00:00 before parsing to stay in IST midday — never shifts day.
 */
export function displayDate(v, opts = { day:'2-digit', month:'short', year:'numeric' }) {
  const s = toDateStr(v);
  if (!s) return '—';
  // Parse at noon IST to avoid any timezone edge cases
  return new Date(s + 'T12:00:00').toLocaleDateString('en-IN', opts);
}

/**
 * How many days until a date (negative = already expired)
 */
export function daysUntil(v) {
  const s = toDateStr(v);
  if (!s) return null;
  const target = new Date(s + 'T12:00:00');
  const now    = new Date();
  now.setHours(12, 0, 0, 0);
  return Math.round((target - now) / 86400000);
}

/**
 * Today's date as 'YYYY-MM-DD' string
 */
export function todayStr() {
  return toDateStr(new Date().toISOString());
}
