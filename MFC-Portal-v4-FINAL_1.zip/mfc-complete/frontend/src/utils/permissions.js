// ============================================================
// MFC Portal — Role Based Access Control
// Single source of truth for all permissions
//
// ROLES:
//   admin  — full access, all financial data
//   staff1 — operations: trips, drivers, consignees (no ₹ data)
//   staff2 — fleet & maintenance: drivers, fleet docs, maintenance (no ₹)
//
// FUTURE: custom per-user permissions can be added as a premium
// feature by extending this with a user_permissions table
// ============================================================

export const ROLES = {
  ADMIN:  'admin',
  STAFF1: 'staff1',
  STAFF2: 'staff2',
};

// Pages each role can access
export const PAGE_ACCESS = {
  dashboard:   ['admin', 'staff1', 'staff2'],
  trips:       ['admin', 'staff1'],
  invoices:    ['admin'],
  consignees:  ['admin', 'staff1'],
  fleet:       ['admin', 'staff1', 'staff2'],
  drivers:     ['admin', 'staff1', 'staff2'],
  maintenance: ['admin', 'staff2'],
  brokerage:   ['admin'],
  owners:      ['admin'],
  analytics:   ['admin'],
  ai:          ['admin'],
  settings:    ['admin'],
};

// Granular field-level permissions
export const FIELD_ACCESS = {
  // Financial figures — admin only
  show_revenue:           ['admin'],
  show_freight_amount:    ['admin', 'staff1'],  // staff1 can enter but list is hidden
  show_freight_in_list:   ['admin'],            // table column hidden for staff1
  show_commission:        ['admin'],
  show_invoice_amounts:   ['admin'],
  show_pending_dues:      ['admin'],
  show_brokerage_kpis:    ['admin'],

  // Fleet financial
  show_loan_emi:          ['admin'],
  show_loan_amount:       ['admin'],

  // Driver sensitive
  show_aadhaar:           ['admin', 'staff2'],

  // Dashboard cards
  dashboard_revenue_card:    ['admin'],
  dashboard_brokerage_card:  ['admin'],
  dashboard_invoice_card:    ['admin'],
  dashboard_trips_card:      ['admin', 'staff1'],
  dashboard_fleet_card:      ['admin', 'staff1', 'staff2'],
  dashboard_drivers_card:    ['admin', 'staff1', 'staff2'],
  dashboard_docs_card:       ['admin', 'staff1', 'staff2'],

  // Actions
  can_delete_trip:        ['admin'],
  can_edit_trip_amount:   ['admin', 'staff1'],
  can_manage_users:       ['admin'],
};

// Check if a role has access to a page
export function canAccessPage(role, page) {
  return PAGE_ACCESS[page]?.includes(role) ?? false;
}

// Check if a role has a specific field/feature permission
export function canAccess(role, permission) {
  return FIELD_ACCESS[permission]?.includes(role) ?? false;
}

// Get nav items visible to a role
export const NAV_ITEMS = [
  { section: null,         label: 'Dashboard',    path: '/dashboard',   page: 'dashboard' },
  { section: 'Operations', label: 'Trips',         path: '/trips',       page: 'trips' },
  { section: null,         label: 'Invoices',      path: '/invoices',    page: 'invoices' },
  { section: null,         label: 'Consignees',    path: '/consignees',  page: 'consignees' },
  { section: 'Fleet',      label: 'Fleet',         path: '/fleet',       page: 'fleet' },
  { section: null,         label: 'Drivers',       path: '/drivers',     page: 'drivers' },
  { section: null,         label: 'Maintenance',   path: '/maintenance', page: 'maintenance' },
  { section: 'Brokerage',  label: 'Brokerage',     path: '/brokerage',   page: 'brokerage' },
  { section: null,         label: 'Owner Ledger',  path: '/owners',      page: 'owners' },
  { section: 'Analytics',  label: 'Analytics',     path: '/analytics',   page: 'analytics' },
  { section: null,         label: 'AI Assistant',  path: '/ai',          page: 'ai' },
  { section: 'System',     label: 'Settings',      path: '/settings',    page: 'settings' },
];

export function getNavForRole(role) {
  return NAV_ITEMS.filter(item => canAccessPage(role, item.page));
}
