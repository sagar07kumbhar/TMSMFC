import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
});

// Attach JWT token to every request
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('mfc_token');
    console.log('API Request:', config.url, '| Token:', token ? 'present' : 'MISSING');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

// Handle 401 globally — redirect to login
api.interceptors.response.use(
  response => response,
  error => {
    console.error('API Error:', error.response?.status, error.response?.data);
    if (error.response?.status === 401) {
      localStorage.removeItem('mfc_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
