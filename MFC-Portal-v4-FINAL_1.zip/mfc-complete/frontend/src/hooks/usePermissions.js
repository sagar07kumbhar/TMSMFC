import { useAuth } from '../context/AuthContext';
import { canAccess, canAccessPage } from '../utils/permissions';

// Central hook — use this in every component that needs permission checks
// Usage:
//   const { can, canPage, role, isAdmin } = usePermissions();
//   if (can('show_revenue')) { ... }
//   if (canPage('analytics')) { ... }

export default function usePermissions() {
  const { user } = useAuth();
  const role = user?.role || 'staff1';

  return {
    role,
    isAdmin:  role === 'admin',
    isStaff1: role === 'staff1',
    isStaff2: role === 'staff2',

    // Check a specific feature permission
    can: (permission) => canAccess(role, permission),

    // Check if a page is accessible
    canPage: (page) => canAccessPage(role, page),
  };
}
