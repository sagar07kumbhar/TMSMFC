const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     process.env.DB_PORT     || 3306,
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'mfc_db',
  waitForConnections: true,
  connectionLimit: 10,
  timezone: '+00:00',         // store/read as UTC — no timezone shifting
  dateStrings: true,          // FIX: return DATE columns as 'YYYY-MM-DD' strings
                              // not JS Date objects (which cause -1 day bug in IST)
});

(async () => {
  try {
    const conn = await pool.getConnection();
    console.log('✅ MySQL connected successfully');
    conn.release();
  } catch (err) {
    console.error('❌ MySQL connection failed:', err.message);
    console.error('   Check .env: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME');
  }
})();

module.exports = pool;
