// ============================================================
// MFC Portal — Backend Role-Based Access Control Middleware
// Mirrors the frontend permissions.js logic on the server
// ============================================================

// Route-level permissions
const ROUTE_PERMISSIONS = {
  // admin only
  'GET:/api/invoices':         ['admin'],
  'POST:/api/invoices':        ['admin'],
  'PUT:/api/invoices':         ['admin'],
  'GET:/api/dashboard/stats':  ['admin', 'staff1', 'staff2'],

  // Financial endpoints — admin only
  'GET:/api/analytics':        ['admin'],
  'GET:/api/brokerage':        ['admin'],
  'GET:/api/owners':           ['admin'],

  // Trips — admin + staff1
  'GET:/api/trips':            ['admin', 'staff1'],
  'POST:/api/trips':           ['admin', 'staff1'],
  'PUT:/api/trips':            ['admin', 'staff1'],
  'DELETE:/api/trips':         ['admin'],             // only admin can delete

  // Trucks — all can read, only admin can write
  'GET:/api/trucks':           ['admin', 'staff1', 'staff2'],
  'POST:/api/trucks':          ['admin'],
  'PUT:/api/trucks':           ['admin'],
  'DELETE:/api/trucks':        ['admin'],

  // Drivers — all roles
  'GET:/api/drivers':          ['admin', 'staff1', 'staff2'],
  'POST:/api/drivers':         ['admin', 'staff2'],
  'PUT:/api/drivers':          ['admin', 'staff2'],
  'DELETE:/api/drivers':       ['admin'],

  // Consignees — admin + staff1
  'GET:/api/consignees':       ['admin', 'staff1'],
  'POST:/api/consignees':      ['admin', 'staff1'],
  'PUT:/api/consignees':       ['admin', 'staff1'],
  'DELETE:/api/consignees':    ['admin'],

  // Maintenance — admin + staff2
  'GET:/api/maintenance':      ['admin', 'staff2'],
  'POST:/api/maintenance':     ['admin', 'staff2'],
  'PUT:/api/maintenance':      ['admin', 'staff2'],
  'DELETE:/api/maintenance':   ['admin'],

  // Tyres — admin + staff2
  'GET:/api/tyres':            ['admin', 'staff2'],
  'POST:/api/tyres':           ['admin', 'staff2'],
  'DELETE:/api/tyres':         ['admin'],

  // Settings — admin only
  'GET:/api/settings':         ['admin'],
  'PUT:/api/settings':         ['admin'],

  // AI — admin only (has financial context)
  'POST:/api/ai':              ['admin'],
};

// Fields to strip from responses based on role
const STRIP_FIELDS = {
  trips: {
    staff1: [], // staff1 sees freight (they enter it) but table hides it on frontend
    staff2: ['freight_amount','advance_paid','balance_due','commission_amount','gst_amount','total_expenses'],
  },
  trucks: {
    staff1: ['loan_amount','loan_emi','loan_tenure_months','loan_paid_emis'],
    staff2: ['loan_amount','loan_emi','loan_tenure_months','loan_paid_emis'],
  },
  drivers: {
    staff1: ['aadhaar_number','aadhaar_status'],
    // staff2 can see aadhaar
  },
};

// Middleware: check role has access to this route
function requireRole(allowedRoles) {
  return (req, res, next) => {
    const role = req.user?.role;
    if (!role) return res.status(401).json({ error: 'Not authenticated' });
    if (!allowedRoles.includes(role)) {
      return res.status(403).json({
        error: 'Access denied',
        message: `Your role (${role}) does not have permission for this action`
      });
    }
    next();
  };
}

// Middleware: strip sensitive fields from response based on role
function stripFields(resource) {
  return (req, res, next) => {
    const role = req.user?.role;
    const fieldsToStrip = STRIP_FIELDS[resource]?.[role] || [];
    if (fieldsToStrip.length === 0) return next();

    // Override res.json to strip fields
    const originalJson = res.json.bind(res);
    res.json = (data) => {
      if (Array.isArray(data)) {
        data = data.map(item => stripObj(item, fieldsToStrip));
      } else if (data && typeof data === 'object') {
        if (data.data && Array.isArray(data.data)) {
          data = { ...data, data: data.data.map(item => stripObj(item, fieldsToStrip)) };
        } else {
          data = stripObj(data, fieldsToStrip);
        }
      }
      return originalJson(data);
    };
    next();
  };
}

function stripObj(obj, fields) {
  if (!obj || typeof obj !== 'object') return obj;
  const result = { ...obj };
  fields.forEach(f => { delete result[f]; });
  return result;
}

// Convenience: admin only
const adminOnly = requireRole(['admin']);

// Convenience: admin + staff1
const adminOrStaff1 = requireRole(['admin', 'staff1']);

// Convenience: admin + staff2
const adminOrStaff2 = requireRole(['admin', 'staff2']);

// Convenience: all roles
const allRoles = requireRole(['admin', 'staff1', 'staff2']);

module.exports = { requireRole, stripFields, adminOnly, adminOrStaff1, adminOrStaff2, allRoles };
