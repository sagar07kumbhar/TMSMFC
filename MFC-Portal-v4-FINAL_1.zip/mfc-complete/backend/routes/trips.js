const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { adminOrStaff1, adminOnly, stripFields } = require('../middleware/rbac');

router.use(auth);

function getFY() {
  const today = new Date(), m = today.getMonth() + 1, y = today.getFullYear();
  const s = m >= 4 ? y : y - 1;
  return `${s}-${String(s + 1).slice(-2)}`;
}

const nullIfEmpty = v => (v === '' || v === undefined || v === null) ? null : v;
const num = v => (v === '' || v === null || v === undefined || isNaN(+v)) ? 0 : +v;

// ─── GET next LR number ───────────────────────────────────────────────────────
router.get('/next-lr', adminOrStaff1, async (req, res) => {
  try {
    const fy = getFY();
    const [rows] = await db.query(
      `SELECT lr_number FROM trips WHERE lr_number LIKE ? ORDER BY id DESC LIMIT 1`,
      [`MFC/${fy}/%`]
    );
    let next = 1;
    if (rows.length) next = (parseInt(rows[0].lr_number.split('/')[2]) || 0) + 1;
    res.json({ lr_number: `MFC/${fy}/${String(next).padStart(3, '0')}`, fy });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

// ─── GET all trips ────────────────────────────────────────────────────────────
router.get('/', adminOrStaff1, stripFields('trips'), async (req, res) => {
  const { trip_type, status, from_date, to_date, page = 1, limit = 500 } = req.query;
  let where = 'WHERE 1=1'; const params = [];
  if (trip_type) { where += ' AND t.trip_type = ?'; params.push(trip_type); }
  if (status)    { where += ' AND t.status = ?';    params.push(status); }
  if (from_date) { where += ' AND t.trip_date >= ?'; params.push(from_date); }
  if (to_date)   { where += ' AND t.trip_date <= ?'; params.push(to_date); }
  try {
    const [rows] = await db.query(`
      SELECT
        t.*,
        (t.freight_amount - t.advance_paid) AS balance_due,
        tr.truck_number,
        d.name  AS driver_name,
        c.name  AS consignee_name,
        COALESCE((SELECT SUM(amount) FROM trip_expenses WHERE trip_id = t.id), 0) AS total_trip_expenses
      FROM trips t
      LEFT JOIN trucks     tr ON t.truck_id     = tr.id
      LEFT JOIN drivers    d  ON t.driver_id    = d.id
      LEFT JOIN consignees c  ON t.consignee_id = c.id
      ${where}
      ORDER BY t.trip_date DESC, t.id DESC
      LIMIT ? OFFSET ?
    `, [...params, +limit, (+page - 1) * +limit]);

    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM trips t ${where}`, params);
    res.json({ data: rows, total, page: +page, pages: Math.ceil(total / +limit) });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

// ─── GET single trip with expenses ───────────────────────────────────────────
router.get('/:id', adminOrStaff1, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT t.*,
        (t.freight_amount - t.advance_paid) AS balance_due,
        tr.truck_number, d.name AS driver_name,
        c.name AS consignee_name, c.gstin AS consignee_gstin, c.city, c.state
      FROM trips t
      LEFT JOIN trucks     tr ON t.truck_id     = tr.id
      LEFT JOIN drivers    d  ON t.driver_id    = d.id
      LEFT JOIN consignees c  ON t.consignee_id = c.id
      WHERE t.id = ?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Trip not found' });
    const [expenses] = await db.query(
      'SELECT * FROM trip_expenses WHERE trip_id = ? ORDER BY expense_date, id',
      [req.params.id]);
    res.json({ ...rows[0], expenses });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

// ─── POST — create trip ───────────────────────────────────────────────────────
router.post('/', adminOrStaff1, async (req, res) => {
  const d = req.body;
  const isBrokerage = d.trip_type === 'brokerage';
  const commission_amount = isBrokerage
    ? +(num(d.freight_amount) * num(d.commission_percent) / 100).toFixed(2) : 0;
  const driver_extra_pay = (!isBrokerage && num(d.distance_km) > 0)
    ? +(num(d.distance_km) * 5).toFixed(2) : 0;
  const gst_amount = +(num(d.freight_amount) * num(d.gst_rate) / 100).toFixed(2);

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // ── 1. Insert trip (no balance_due in column list — update separately) ──
    const [r] = await conn.query(`
      INSERT INTO trips (
        trip_number, lr_number, trip_date, trip_type,
        truck_id, driver_id,
        broker_owner_name, broker_owner_phone, broker_truck_number, broker_driver_name,
        commission_percent, commission_amount,
        broker_advance_paid, broker_final_paid, broker_payment_status,
        consignee_id, from_location, to_location, distance_km, weight_tons,
        freight_amount, advance_paid,
        detention_charges, kata_charges, loading_charges, unloading_charges,
        gst_type, gst_rate, gst_amount, driver_extra_pay, status, notes
      ) VALUES (
        ?,?,?,?,
        ?,?,
        ?,?,?,?,
        ?,?,
        ?,?,?,
        ?,?,?,?,?,
        ?,?,
        ?,?,?,?,
        ?,?,?,?,
        ?,?
      )`, [
      d.trip_number, d.lr_number, d.trip_date, d.trip_type || 'owned',
      nullIfEmpty(d.truck_id), nullIfEmpty(d.driver_id),
      nullIfEmpty(d.broker_owner_name), nullIfEmpty(d.broker_owner_phone),
      nullIfEmpty(d.broker_truck_number), nullIfEmpty(d.broker_driver_name),
      num(d.commission_percent), commission_amount,
      num(d.broker_advance_paid), num(d.broker_final_paid), d.broker_payment_status || 'pending',
      nullIfEmpty(d.consignee_id), d.from_location, d.to_location,
      num(d.distance_km), num(d.weight_tons),
      num(d.freight_amount), num(d.advance_paid),
      num(d.detention_charges), num(d.kata_charges),
      num(d.loading_charges), num(d.unloading_charges),
      d.gst_type || 'exempt', num(d.gst_rate), gst_amount, driver_extra_pay,
      d.status || 'planned', d.notes || '',
    ]);
    const tripId = r.insertId;

    // ── 2. Set balance_due (use submitted value if provided, else calculate) ───
    const balanceDue_post = (d.balance_due !== undefined && d.balance_due !== '')
      ? num(d.balance_due)
      : num(d.freight_amount) - num(d.advance_paid);
    await conn.query('UPDATE trips SET balance_due = ? WHERE id = ?', [balanceDue_post, tripId]);

    // ── 3. Save trip expenses (owned only) ───────────────────────────────────
    if (!isBrokerage && Array.isArray(d.expenses)) {
      for (const exp of d.expenses) {
        if (num(exp.amount) > 0) {
          await conn.query(
            'INSERT INTO trip_expenses (trip_id,expense_type,amount,description,expense_date) VALUES (?,?,?,?,?)',
            [tripId, exp.expense_type, num(exp.amount),
             exp.description || '', nullIfEmpty(exp.expense_date) || d.trip_date]
          );
        }
      }
    }

    // ── 4. Auto-create invoice (ALL trips — owned AND brokerage) ──────────────
    // Consignee always gets an invoice regardless of whose truck it is
    let invoice_number = null;
    if (true) {
      const [settings] = await conn.query('SELECT invoice_prefix FROM settings LIMIT 1');
      const prefix = settings[0]?.invoice_prefix || 'INV';
      const fy = getFY();
      const [lastInv] = await conn.query(
        `SELECT invoice_number FROM invoices WHERE invoice_number LIKE ? ORDER BY id DESC LIMIT 1`,
        [`${prefix}/${fy}/%`]);
      let invNext = 1;
      if (lastInv.length) invNext = (parseInt(lastInv[0].invoice_number.split('/')[2]) || 0) + 1;
      invoice_number = `${prefix}/${fy}/${String(invNext).padStart(3, '0')}`;

      const subtotal = num(d.freight_amount) + num(d.detention_charges)
        + num(d.kata_charges) + num(d.loading_charges) + num(d.unloading_charges);
      const total_amount = subtotal + gst_amount;
      const pstatus = num(d.advance_paid) >= total_amount ? 'paid'
        : num(d.advance_paid) > 0 ? 'partial' : 'unpaid';

      await conn.query(`
        INSERT INTO invoices
          (invoice_number, invoice_date, consignee_id, trip_ids,
           subtotal, gst_amount, total_amount, amount_paid, payment_status, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?)`, [
        invoice_number, d.trip_date, nullIfEmpty(d.consignee_id),
        JSON.stringify([tripId]),
        subtotal, gst_amount, total_amount, num(d.advance_paid), pstatus,
        `Auto-generated for trip ${d.lr_number}`,
      ]);

    // ── 5. Create owner ledger entry ─────────────────────────────────────────
    if (isBrokerage && d.broker_owner_name?.trim()) {
      // Brokerage: track what you owe the external truck owner
      const ownerPayable = num(d.freight_amount) - commission_amount;
      await conn.query(`
        INSERT INTO owner_payments
          (trip_id, owner_name, owner_phone, truck_number,
           freight_amount, commission_amount, payable_amount,
           advance_paid, balance_due, status)
        VALUES (?,?,?,?,?,?,?,?,?,?)`, [
        tripId, d.broker_owner_name, d.broker_owner_phone || '',
        d.broker_truck_number || '',
        num(d.freight_amount), commission_amount, ownerPayable,
        num(d.broker_advance_paid),
        Math.max(0, ownerPayable - num(d.broker_advance_paid)),
        'pending',
      ]);
    } else if (!isBrokerage && d.truck_id) {
      // Owned: log your own truck's trip revenue in ledger
      const [truckRows] = await conn.query(
        'SELECT truck_number FROM trucks WHERE id = ?', [d.truck_id]);
      const truckNo = truckRows[0]?.truck_number || '';
      await conn.query(`
        INSERT INTO owner_payments
          (trip_id, owner_name, owner_phone, truck_number,
           freight_amount, commission_amount, payable_amount,
           advance_paid, balance_due, status)
        VALUES (?,?,?,?,?,?,?,?,?,?)`, [
        tripId, 'MFC (Own Truck)', '', truckNo,
        num(d.freight_amount), 0, 0,
        num(d.freight_amount),   // fully paid to self
        0,
        'settled',               // own truck — no payout needed
      ]);
    }

    await conn.commit();
    res.status(201).json({ id: tripId, message: 'Trip created', invoice_number, trip_type: d.trip_type });
  } catch (err) {
    await conn.rollback();
    console.error('POST /trips error:', err);
    res.status(500).json({ error: err.message });
  } finally { conn.release(); }
});

// ─── PUT — update trip ────────────────────────────────────────────────────────
router.put('/:id', adminOrStaff1, async (req, res) => {
  const d = req.body;
  const id = +req.params.id;
  const isBrokerage = d.trip_type === 'brokerage';
  const commission_amount = isBrokerage
    ? +(num(d.freight_amount) * num(d.commission_percent) / 100).toFixed(2) : 0;
  const driver_extra_pay = (!isBrokerage && num(d.distance_km) > 0)
    ? +(num(d.distance_km) * 5).toFixed(2) : 0;
  const gst_amount = +(num(d.freight_amount) * num(d.gst_rate) / 100).toFixed(2);

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // ── 1. Update trip fields (no balance_due in SET — update separately) ────
    await conn.query(`
      UPDATE trips SET
        trip_number=?, lr_number=?, trip_date=?, trip_type=?,
        truck_id=?, driver_id=?,
        broker_owner_name=?, broker_owner_phone=?,
        broker_truck_number=?, broker_driver_name=?,
        commission_percent=?, commission_amount=?,
        broker_advance_paid=?, broker_final_paid=?, broker_payment_status=?,
        consignee_id=?, from_location=?, to_location=?,
        distance_km=?, weight_tons=?,
        freight_amount=?, advance_paid=?,
        detention_charges=?, kata_charges=?, loading_charges=?, unloading_charges=?,
        gst_type=?, gst_rate=?, gst_amount=?,
        driver_extra_pay=?, status=?, notes=?
      WHERE id=?`, [
      d.trip_number, d.lr_number, d.trip_date, d.trip_type || 'owned',
      nullIfEmpty(d.truck_id), nullIfEmpty(d.driver_id),
      nullIfEmpty(d.broker_owner_name), nullIfEmpty(d.broker_owner_phone),
      nullIfEmpty(d.broker_truck_number), nullIfEmpty(d.broker_driver_name),
      num(d.commission_percent), commission_amount,
      num(d.broker_advance_paid), num(d.broker_final_paid), d.broker_payment_status || 'pending',
      nullIfEmpty(d.consignee_id), d.from_location, d.to_location,
      num(d.distance_km), num(d.weight_tons),
      num(d.freight_amount), num(d.advance_paid),
      num(d.detention_charges), num(d.kata_charges),
      num(d.loading_charges), num(d.unloading_charges),
      d.gst_type || 'exempt', num(d.gst_rate), gst_amount,
      driver_extra_pay, d.status || 'planned', d.notes || '',
      id,
    ]);

    // ── 2. Set balance_due (use submitted value if provided, else calculate) ────
    const balanceDue_put = (d.balance_due !== undefined && d.balance_due !== '')
      ? num(d.balance_due)
      : num(d.freight_amount) - num(d.advance_paid);
    await conn.query('UPDATE trips SET balance_due = ? WHERE id = ?', [balanceDue_put, id]);

    // ── 3. Re-save trip expenses ──────────────────────────────────────────────
    await conn.query('DELETE FROM trip_expenses WHERE trip_id = ?', [id]);
    if (!isBrokerage && Array.isArray(d.expenses)) {
      for (const exp of d.expenses) {
        if (num(exp.amount) > 0) {
          await conn.query(
            'INSERT INTO trip_expenses (trip_id,expense_type,amount,description,expense_date) VALUES (?,?,?,?,?)',
            [id, exp.expense_type, num(exp.amount),
             exp.description || '', nullIfEmpty(exp.expense_date) || d.trip_date]
          );
        }
      }
    }

    // ── 4. Sync invoice (all trips — owned and brokerage) ──────────────────────
    if (true) {
      const subtotal = num(d.freight_amount) + num(d.detention_charges)
        + num(d.kata_charges) + num(d.loading_charges) + num(d.unloading_charges);
      const total_amount = subtotal + gst_amount;
      const pstatus = num(d.advance_paid) >= total_amount ? 'paid'
        : num(d.advance_paid) > 0 ? 'partial' : 'unpaid';
      await conn.query(`
        UPDATE invoices
        SET subtotal=?, gst_amount=?, total_amount=?, amount_paid=?, payment_status=?
        WHERE trip_ids = ?`,
        [subtotal, gst_amount, total_amount, num(d.advance_paid), pstatus,
         JSON.stringify([id])]);
    }

    // ── 5. Sync owner ledger (brokerage only) ─────────────────────────────────
    if (isBrokerage) {
      const ownerPayable = num(d.freight_amount) - commission_amount;
      await conn.query(`
        UPDATE owner_payments SET
          commission_amount=?, payable_amount=?,
          advance_paid=?, balance_due=?, status=?
        WHERE trip_id=?`, [
        commission_amount, ownerPayable,
        num(d.broker_advance_paid),
        Math.max(0, ownerPayable - num(d.broker_advance_paid)),
        d.broker_payment_status || 'pending',
        id,
      ]);
    }

    await conn.commit();
    res.json({ message: 'Trip updated' });
  } catch (err) {
    await conn.rollback();
    console.error('PUT /trips error:', err);
    res.status(500).json({ error: err.message });
  } finally { conn.release(); }
});

// ─── DELETE trip ──────────────────────────────────────────────────────────────
router.delete('/:id', adminOnly, async (req, res) => {
  try {
    await db.query('DELETE FROM trips WHERE id = ?', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

module.exports = router;
