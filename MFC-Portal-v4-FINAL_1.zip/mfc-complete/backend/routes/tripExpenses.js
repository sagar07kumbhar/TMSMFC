const router = require('express').Router();
const db     = require('../config/db');
const { auth } = require('../middleware/auth');

router.use(auth);

// GET /api/trip-expenses?trip_id=X  — get all expenses for a trip
router.get('/', async (req, res) => {
  const { trip_id } = req.query;
  if (!trip_id) return res.status(400).json({ error: 'trip_id required' });
  try {
    const [rows] = await db.query(
      'SELECT * FROM trip_expenses WHERE trip_id = ? ORDER BY expense_date ASC, id ASC',
      [trip_id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch expenses' });
  }
});

// POST /api/trip-expenses  — add one expense
router.post('/', async (req, res) => {
  const { trip_id, expense_type, amount, description, expense_date } = req.body;
  if (!trip_id || !expense_type || !amount) {
    return res.status(400).json({ error: 'trip_id, expense_type, amount required' });
  }
  try {
    const [r] = await db.query(
      'INSERT INTO trip_expenses (trip_id, expense_type, amount, description, expense_date) VALUES (?,?,?,?,?)',
      [trip_id, expense_type, +amount, description || '', expense_date || null]
    );
    res.status(201).json({ id: r.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save expense' });
  }
});

// DELETE /api/trip-expenses/by-trip/:trip_id  — delete ALL expenses for a trip (used before re-saving)
router.delete('/by-trip/:trip_id', async (req, res) => {
  try {
    await db.query('DELETE FROM trip_expenses WHERE trip_id = ?', [req.params.trip_id]);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete' });
  }
});

// DELETE /api/trip-expenses/:id  — delete one expense
router.delete('/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM trip_expenses WHERE id = ?', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete' });
  }
});

module.exports = router;
