const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

// Main dashboard stats — called every time dashboard loads
router.get('/stats', async (req, res) => {
  const month = req.query.month || (new Date().getMonth() + 1);
  const year  = req.query.year  || new Date().getFullYear();
  try {
    // Revenue this month — owned trips only (freight is your revenue)
    // Only count completed + in_progress trips (not planned, not cancelled)
    const [[owned]] = await db.query(`
      SELECT COALESCE(SUM(freight_amount + detention_charges + kata_charges + loading_charges + unloading_charges), 0) AS rev
      FROM trips
      WHERE trip_type='owned' AND MONTH(trip_date)=? AND YEAR(trip_date)=?
        AND status IN ('completed','in_progress')`, [month, year]);

    // Brokerage commission this month
    const [[brokerage]] = await db.query(`
      SELECT COALESCE(SUM(commission_amount), 0) AS rev
      FROM trips
      WHERE trip_type='brokerage' AND MONTH(trip_date)=? AND YEAR(trip_date)=?
        AND status IN ('completed','in_progress')`, [month, year]);

    // Trip expenses (diesel, toll etc) this month — owned only
    const [[expenses]] = await db.query(`
      SELECT COALESCE(SUM(te.amount), 0) AS total
      FROM trip_expenses te
      JOIN trips t ON te.trip_id = t.id
      WHERE MONTH(t.trip_date)=? AND YEAR(t.trip_date)=?
        AND t.status IN ('completed','in_progress')`, [month, year]);

    // Trip count this month (all statuses except cancelled)
    const [[trips]] = await db.query(`
      SELECT COUNT(*) AS total FROM trips
      WHERE MONTH(trip_date)=? AND YEAR(trip_date)=? AND status != 'cancelled'`, [month, year]);

    // Active fleet
    const [[trucks]]  = await db.query(`SELECT COUNT(*) AS total FROM trucks WHERE is_active=1`);
    const [[drivers]] = await db.query(`SELECT COUNT(*) AS total FROM drivers WHERE is_active=1`);

    // Pending invoices (owned trips only — brokerage has no invoice)
    const [[pending]] = await db.query(`
      SELECT COUNT(*) AS count, COALESCE(SUM(total_amount - amount_paid), 0) AS amount
      FROM invoices WHERE payment_status != 'paid'`);

    // Expiring documents in 30 days
    const [[expiring]] = await db.query(`
      SELECT COUNT(*) AS count FROM (
        SELECT id FROM trucks WHERE
          (rc_expiry        BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) OR
          (puc_expiry       BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) OR
          (fitness_expiry   BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) OR
          (insurance_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)) OR
          (permit_expiry    BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY))
        UNION
        SELECT id FROM drivers WHERE
          license_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
      ) AS alerts`);

    // 6-month trend
    const [trend] = await db.query(`
      SELECT
        DATE_FORMAT(trip_date,'%b %Y') AS month_label,
        DATE_FORMAT(trip_date,'%Y-%m') AS month_sort,
        COALESCE(SUM(CASE WHEN trip_type='owned'
          THEN freight_amount + detention_charges + kata_charges + loading_charges + unloading_charges
          ELSE 0 END), 0) AS owned_revenue,
        COALESCE(SUM(CASE WHEN trip_type='brokerage' THEN commission_amount ELSE 0 END), 0) AS brokerage_commission,
        COUNT(*) AS trips
      FROM trips
      WHERE trip_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        AND status != 'cancelled'
      GROUP BY DATE_FORMAT(trip_date,'%Y-%m'), DATE_FORMAT(trip_date,'%b %Y')
      ORDER BY month_sort ASC`);

    // Top routes by revenue (completed trips)
    const [routes] = await db.query(`
      SELECT
        CONCAT(from_location, ' → ', to_location) AS route,
        COUNT(*) AS trips,
        SUM(freight_amount) AS revenue
      FROM trips
      WHERE status = 'completed' AND trip_type = 'owned'
      GROUP BY from_location, to_location
      ORDER BY revenue DESC LIMIT 5`);

    // Brokerage pending payout
    const [[brokeragePending]] = await db.query(`
      SELECT COALESCE(SUM(balance_due), 0) AS total FROM owner_payments WHERE status != 'settled'`);

    res.json({
      monthly: {
        owned_revenue:          +owned.rev,
        brokerage_commission:   +brokerage.rev,
        total_revenue:          +owned.rev + +brokerage.rev,
        expenses:               +expenses.total,
        net_profit:             +owned.rev + +brokerage.rev - +expenses.total,
        trips:                  +trips.total,
      },
      fleet:              { trucks: +trucks.total, drivers: +drivers.total },
      pending_invoices:   { count: +pending.count, amount: +pending.amount },
      expiring_docs:      +expiring.count,
      brokerage_pending:  +brokeragePending.total,
      trend,
      top_routes:         routes,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load dashboard stats' });
  }
});

// Truck summary for maintenance page
router.get('/truck-summary/:truck_id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        t.id, t.truck_number,
        COALESCE((SELECT SUM(freight_amount) FROM trips WHERE truck_id=t.id AND status='completed'),0) AS total_revenue,
        COALESCE((SELECT COUNT(*) FROM trips WHERE truck_id=t.id),0) AS total_trips,
        COALESCE((SELECT SUM(distance_km) FROM trips WHERE truck_id=t.id),0) AS total_km,
        COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='servicing'),0) AS servicing_cost,
        COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='fuel'),0) AS fuel_cost,
        COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='repair'),0) AS repair_cost,
        COALESCE((SELECT SUM(purchase_cost) FROM tyre_logs WHERE truck_id=t.id AND event_type='new_fit'),0) AS tyre_cost,
        COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id),0) AS total_maintenance_cost,
        COALESCE((SELECT SUM(freight_amount) FROM trips WHERE truck_id=t.id AND status='completed'),0) -
        COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id),0) AS net_contribution
      FROM trucks t WHERE t.id = ?`, [req.params.truck_id]);
    if (!rows.length) return res.status(404).json({ error: 'Truck not found' });
    res.json(rows[0]);
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

module.exports = router;
