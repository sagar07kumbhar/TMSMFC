const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
router.use(auth);

// GET all drivers with this month's trip count
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT d.*,
        COALESCE((
          SELECT COUNT(*) FROM trips t
          WHERE t.driver_id = d.id
            AND MONTH(t.trip_date) = MONTH(CURDATE())
            AND YEAR(t.trip_date) = YEAR(CURDATE())
            AND t.status != 'cancelled'
        ), 0) AS trips_this_month,
        COALESCE((
          SELECT SUM(t.freight_amount) FROM trips t
          WHERE t.driver_id = d.id
            AND MONTH(t.trip_date) = MONTH(CURDATE())
            AND YEAR(t.trip_date) = YEAR(CURDATE())
            AND t.status IN ('completed','in_progress')
        ), 0) AS revenue_this_month
      FROM drivers d
      WHERE d.is_active = 1
      ORDER BY d.name ASC`);
    res.json(rows);
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed' }); }
});

router.get('/:id', async (req, res) => {
  try {
    const [r] = await db.query('SELECT * FROM drivers WHERE id=?', [req.params.id]);
    r.length ? res.json(r[0]) : res.status(404).json({ error: 'Not found' });
  } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

router.post('/', async (req, res) => {
  const d = req.body;
  // Validate phone
  if (!d.phone || !/^[6-9]\d{9}$/.test(d.phone.trim()))
    return res.status(400).json({ error: 'Valid 10-digit mobile number required' });
  // Validate aadhaar if provided
  if (d.aadhaar_number && !/^\d{12}$/.test(d.aadhaar_number))
    return res.status(400).json({ error: 'Aadhaar must be exactly 12 digits' });
  try {
    const [r] = await db.query(`
      INSERT INTO drivers
        (name, phone, license_number, license_expiry, badge_expiry, address,
         aadhaar_number, aadhaar_status, aadhaar_copy_uploaded)
      VALUES (?,?,?,?,?,?,?,?,?)`,
      [d.name, d.phone.trim(), d.license_number,
       d.license_expiry || null, d.badge_expiry || null, d.address || '',
       d.aadhaar_number || null,
       d.aadhaar_status || 'not_verified',
       d.aadhaar_copy_uploaded ? 1 : 0]);
    res.status(201).json({ id: r.insertId });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed to add driver' }); }
});

router.put('/:id', async (req, res) => {
  const d = req.body;
  if (!d.phone || !/^[6-9]\d{9}$/.test(d.phone.trim()))
    return res.status(400).json({ error: 'Valid 10-digit mobile number required' });
  if (d.aadhaar_number && !/^\d{12}$/.test(d.aadhaar_number))
    return res.status(400).json({ error: 'Aadhaar must be exactly 12 digits' });
  try {
    await db.query(`
      UPDATE drivers SET
        name=?, phone=?, license_number=?, license_expiry=?, badge_expiry=?,
        address=?, aadhaar_number=?, aadhaar_status=?, aadhaar_copy_uploaded=?,
        is_active=?
      WHERE id=?`,
      [d.name, d.phone.trim(), d.license_number,
       d.license_expiry || null, d.badge_expiry || null,
       d.address || '',
       d.aadhaar_number || null,
       d.aadhaar_status || 'not_verified',
       d.aadhaar_copy_uploaded ? 1 : 0,
       d.is_active ? 1 : 0,
       req.params.id]);
    res.json({ message: 'Driver updated' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Failed to update driver' }); }
});

router.delete('/:id', async (req, res) => {
  await db.query('UPDATE drivers SET is_active=0 WHERE id=?', [req.params.id]);
  res.json({ message: 'Deactivated' });
});

module.exports = router;
