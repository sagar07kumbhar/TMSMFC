# 🚛 MFC Portal v4.0
### Mumbai Freight Carriers — Transport Management System
### Nigdi, Pune | GSTIN: 27DAPPS1266E1ZF

---

## 🚀 Setup (4 steps)

### Step 1 — Database (XAMPP)
1. Start XAMPP → start MySQL
2. Open http://localhost/phpmyadmin
3. Click **SQL** tab at the top
4. Open `database/mfc_setup.sql` → paste entire file → click **Go**
5. You'll see 11 tables created ✅

### Step 2 — Configure backend
```
cd backend
copy .env.example .env
```
Edit `.env` — set your DB password (blank for XAMPP default)

### Step 3 — Start backend
```
cd backend
npm install
npm run dev
```
✅ Running at http://localhost:5001

### Step 4 — Start frontend
```
cd frontend
npm install
npm run dev
```
✅ Opens at http://localhost:3000

---

## 🔐 Login credentials

| Role | Email | Password | Access |
|------|-------|----------|--------|
| Admin | admin@mfc.com | admin123 | Everything |
| Staff 1 (Operations) | staff1@mfc.com | staff123 | Trips, Drivers, Consignees |
| Staff 2 (Fleet) | staff2@mfc.com | staff123 | Drivers, Fleet, Maintenance |

---

## ✅ Key business rules

| Rule | Detail |
|------|--------|
| **Owned trip** | Invoice to consignee + own truck ledger entry (settled) |
| **Brokerage trip** | Invoice to consignee + owner ledger entry (pending payout) |
| **Balance due** | Auto-calculated (freight − advance), editable |
| **No invoice needed** | Brokerage used to skip invoice — now both get invoice |
| **Commission** | MFC deducts % from brokerage freight, pays rest to owner |
| **Driver extra pay** | distance × ₹5 auto-calculated (owned trips only) |
| **Date fix** | dateStrings:true in db.js prevents -1 day timezone bug |

---

## 📁 Project structure

```
mfc-complete/
├── database/
│   └── mfc_setup.sql          ← ONE file, run this only
├── backend/
│   ├── .env.example           ← Copy to .env
│   ├── config/db.js
│   ├── middleware/auth.js + rbac.js
│   └── routes/
│       ├── trips.js           ← Invoice for ALL trips, owner ledger for ALL
│       ├── dashboard.js
│       ├── drivers.js
│       ├── trucks.js
│       ├── consignees.js
│       ├── invoices.js
│       ├── maintenance.js
│       ├── tyres.js
│       ├── tripExpenses.js
│       ├── settings.js
│       ├── auth.js
│       └── ai.js
└── frontend/src/
    ├── utils/
    │   ├── dateUtils.js       ← toDateStr, displayDate, daysUntil
    │   ├── api.js
    │   └── permissions.js
    ├── hooks/usePermissions.js
    ├── context/AuthContext.jsx
    ├── components/
    │   ├── Layout.jsx
    │   ├── RoleRoute.jsx
    │   ├── Toast.jsx
    │   └── MFCLogo.jsx
    └── pages/
        ├── Login.jsx
        ├── Dashboard.jsx
        ├── Trips.jsx
        ├── Fleet.jsx
        ├── Drivers.jsx
        ├── Invoices.jsx
        ├── Consignees.jsx
        ├── Maintenance.jsx
        ├── Brokerage.jsx
        ├── OwnerLedger.jsx
        ├── Analytics.jsx
        ├── AIAssistant.jsx
        └── Settings.jsx
```
