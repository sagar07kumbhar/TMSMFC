# 🚛 MFC Portal v4.0 — Complete Build
### Mumbai Freight Carriers, Nigdi, Pune

---

## 📦 What's in this bundle

```
mfc-complete/
├── database/
│   ├── schema.sql           ← Run FIRST — creates all 11 tables
│   ├── schema_update.sql    ← Run SECOND — adds owner_payments, aadhaar, views
│   └── roles_update.sql     ← Run THIRD — adds staff1/staff2 users & roles
│
├── backend/
│   ├── config/db.js
│   ├── middleware/
│   │   ├── auth.js          ← JWT authentication
│   │   └── rbac.js          ← Role-based access control
│   ├── routes/
│   │   ├── auth.js          ← Login, me, change-password
│   │   ├── trips.js         ← Trips + auto-invoice + brokerage ledger
│   │   ├── trucks.js
│   │   ├── drivers.js
│   │   ├── consignees.js
│   │   ├── tripExpenses.js
│   │   ├── invoices.js      ← Auto-generated when trip saved
│   │   ├── maintenance.js
│   │   ├── tyres.js         ← Per-position tyre tracking
│   │   ├── dashboard.js     ← Role-aware KPIs
│   │   ├── settings.js
│   │   └── ai.js            ← Claude AI assistant
│   ├── server.js
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── utils/
    │   │   ├── api.js           ← Axios with JWT
    │   │   └── permissions.js   ← Single source of truth for RBAC
    │   ├── hooks/
    │   │   └── usePermissions.js ← Role check hook
    │   ├── context/AuthContext.jsx
    │   ├── components/
    │   │   ├── Layout.jsx       ← Sidebar with truck logo + role badge
    │   │   ├── RoleRoute.jsx    ← Page-level access guard
    │   │   ├── Toast.jsx        ← Notifications
    │   │   └── MFCLogo.jsx      ← Truck SVG logo
    │   ├── pages/
    │   │   ├── Login.jsx        ← Split layout, truck illustration
    │   │   ├── Dashboard.jsx    ← Role-aware: 3 different views
    │   │   ├── Trips.jsx        ← Owned/Brokerage tabs, live calculator
    │   │   ├── Fleet.jsx        ← Card grid, EMI hidden from staff
    │   │   ├── Drivers.jsx      ← Monthly trips, Aadhaar field
    │   │   ├── Invoices.jsx     ← Auto-generated, print-ready MFC format
    │   │   ├── Consignees.jsx
    │   │   ├── Maintenance.jsx  ← 6 tabs: Tyres/Service/Fuel/Repair/Docs/History
    │   │   ├── Brokerage.jsx    ← Brokerage dashboard (admin only)
    │   │   ├── OwnerLedger.jsx  ← Owner payout ledger (admin only)
    │   │   ├── Analytics.jsx    ← 7-tab analytics (admin only)
    │   │   ├── AIAssistant.jsx  ← Claude AI chat (admin only)
    │   │   └── Settings.jsx     ← Business settings (admin only)
    │   ├── App.jsx              ← All routes with role guards
    │   └── main.jsx
    ├── index.html
    ├── package.json
    └── vite.config.js
```

---

## 🔐 Roles

| Role | Email | Password | Access |
|------|-------|----------|--------|
| Admin | admin@mfc.com | admin123 | Everything + all financial data |
| Staff 1 (Operations) | staff1@mfc.com | staff123 | Trips, Drivers, Consignees, Fleet |
| Staff 2 (Fleet) | staff2@mfc.com | staff123 | Drivers, Fleet docs, Maintenance |

**What staff can NOT see:**
- Revenue, freight amounts in list view, invoices
- Brokerage dashboard, owner ledger, analytics
- Loan/EMI amounts on trucks
- AI assistant, Settings

---

## 🚀 Local setup (5 steps)

### Step 1 — Database setup in phpMyAdmin

1. Open http://localhost/phpmyadmin
2. Create database named `mfc_db`
3. Import `database/schema.sql`
4. Import `database/schema_update.sql`
5. Import `database/roles_update.sql`

### Step 2 — Configure backend

```bash
cd backend
copy .env.example .env
```

Edit `.env`:
```
DB_PASSWORD=          ← blank for XAMPP
JWT_SECRET=mfc2024mysecretkey99
ANTHROPIC_API_KEY=    ← optional, for AI tab
```

### Step 3 — Start backend

```bash
cd backend
npm install
npm run dev
```

✅ Should see: `🚛 MFC Portal v4.0 running on http://localhost:5000`

### Step 4 — Start frontend (new terminal)

```bash
cd frontend
npm install
npm run dev
```

✅ Opens at: http://localhost:5173

### Step 5 — Login

- URL: http://localhost:5173
- Email: admin@mfc.com
- Password: admin123

---

## ✨ Key features

| Feature | Details |
|---------|---------|
| **Role-based access** | 3 roles, protected at frontend + backend + API level |
| **Auto invoice** | Saved when trip is created, MFC print format |
| **Brokerage** | No expenses, commission only, owner ledger |
| **Tyre tracking** | T1–T14 + spare, brand analytics, km per tyre |
| **Maintenance** | 6 tabs per truck, monthly cost charts |
| **Analytics** | 7 tabs: Revenue, Trips, Drivers, Routes, Expenses, Fleet, Profit |
| **AI Assistant** | Claude-powered, admin only |
| **LR auto-gen** | MFC/2026-27/001 format, FY-aware |
| **Driver extra pay** | distance × ₹5/km auto-calculated |
| **GST** | CGST+SGST / IGST / Exempt, auto-applied |
| **Truck logo** | Professional SVG truck throughout the app |

---

## 💰 SaaS pricing

| Tier | Setup | Monthly |
|------|-------|---------|
| First 5 clients | ₹18,000 | ₹2,500 |
| After 5 clients | ₹25,000 | ₹3,000 |

**Future premium feature:** Custom per-user permissions (foundation already built in permissions.js)
