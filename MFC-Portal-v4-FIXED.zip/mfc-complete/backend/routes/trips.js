const router = require('express').Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { adminOrStaff1, adminOnly, stripFields } = require('../middleware/rbac');

router.use(auth);

function getFY() {
  const today = new Date(), m = today.getMonth()+1, y = today.getFullYear();
  const s = m>=4?y:y-1;
  return `${s}-${String(s+1).slice(-2)}`;
}

// Auto-generate next LR
router.get('/next-lr', adminOrStaff1, async (req, res) => {
  try {
    const fy = getFY();
    const [rows] = await db.query(`SELECT lr_number FROM trips WHERE lr_number LIKE ? ORDER BY id DESC LIMIT 1`, [`MFC/${fy}/%`]);
    let next = 1;
    if (rows.length) { const p=rows[0].lr_number.split('/'); next=(parseInt(p[2])||0)+1; }
    res.json({ lr_number:`MFC/${fy}/${String(next).padStart(3,'0')}`, fy });
  } catch { res.status(500).json({ error:'Failed' }); }
});

// GET all trips — admin+staff1 only, strip financials for staff1
router.get('/', adminOrStaff1, stripFields('trips'), async (req, res) => {
  const { trip_type, status, from_date, to_date, page=1, limit=20 } = req.query;
  let where='WHERE 1=1'; const params=[];
  if (trip_type) { where+=' AND t.trip_type=?'; params.push(trip_type); }
  if (status)    { where+=' AND t.status=?';    params.push(status); }
  if (from_date) { where+=' AND t.trip_date>=?'; params.push(from_date); }
  if (to_date)   { where+=' AND t.trip_date<=?'; params.push(to_date); }
  try {
    const [rows] = await db.query(`
      SELECT t.*, tr.truck_number, d.name AS driver_name, c.name AS consignee_name,
        COALESCE((SELECT SUM(amount) FROM trip_expenses WHERE trip_id=t.id),0) AS total_expenses
      FROM trips t
      LEFT JOIN trucks tr ON t.truck_id=tr.id
      LEFT JOIN drivers d ON t.driver_id=d.id
      LEFT JOIN consignees c ON t.consignee_id=c.id
      ${where} ORDER BY t.trip_date DESC LIMIT ? OFFSET ?
    `, [...params, +limit, (+page-1)*+limit]);
    const [[{total}]] = await db.query(`SELECT COUNT(*) AS total FROM trips t ${where}`, params);
    res.json({ data:rows, total, page:+page, pages:Math.ceil(total/+limit) });
  } catch(e) { console.error(e); res.status(500).json({ error:'Failed' }); }
});

// GET single trip
router.get('/:id', adminOrStaff1, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT t.*, tr.truck_number, d.name AS driver_name,
        c.name AS consignee_name, c.gstin AS consignee_gstin, c.city, c.state
      FROM trips t LEFT JOIN trucks tr ON t.truck_id=tr.id
      LEFT JOIN drivers d ON t.driver_id=d.id LEFT JOIN consignees c ON t.consignee_id=c.id
      WHERE t.id=?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error:'Not found' });
    const [expenses] = await db.query('SELECT * FROM trip_expenses WHERE trip_id=?', [req.params.id]);
    res.json({ ...rows[0], expenses });
  } catch { res.status(500).json({ error:'Failed' }); }
});

// POST — create trip + auto invoice
router.post('/', adminOrStaff1, async (req, res) => {
  const d = req.body;
  const commission_amount = d.trip_type==='brokerage' ? ((+d.freight_amount||0)*(+d.commission_percent||0)/100).toFixed(2) : 0;
  const driver_extra_pay  = d.trip_type==='owned' && d.distance_km ? (+d.distance_km*5).toFixed(2) : 0;
  const gst_amount = (+d.freight_amount||0)*(+d.gst_rate||0)/100;

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [r] = await conn.query(`
      INSERT INTO trips (trip_number,lr_number,trip_date,trip_type,
        truck_id,driver_id,broker_owner_name,broker_owner_phone,broker_truck_number,broker_driver_name,
        commission_percent,commission_amount,consignee_id,from_location,to_location,
        distance_km,weight_tons,freight_amount,advance_paid,
        detention_charges,kata_charges,loading_charges,unloading_charges,
        gst_type,gst_rate,gst_amount,driver_extra_pay,status,notes)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [d.trip_number,d.lr_number,d.trip_date,d.trip_type||'owned',
       d.truck_id||null,d.driver_id||null,d.broker_owner_name||null,d.broker_owner_phone||null,
       d.broker_truck_number||null,d.broker_driver_name||null,
       d.commission_percent||0,commission_amount,d.consignee_id||null,
       d.from_location,d.to_location,d.distance_km||0,d.weight_tons||0,
       d.freight_amount||0,d.advance_paid||0,
       d.detention_charges||0,d.kata_charges||0,d.loading_charges||0,d.unloading_charges||0,
       d.gst_type||'exempt',d.gst_rate||0,gst_amount,driver_extra_pay,
       d.status||'planned',d.notes||'']);
    const tripId = r.insertId;

    // Auto-create invoice
    const [settings] = await conn.query('SELECT invoice_prefix FROM settings LIMIT 1');
    const prefix = settings[0]?.invoice_prefix||'INV';
    const fy = getFY();
    const [lastInv] = await conn.query(`SELECT invoice_number FROM invoices WHERE invoice_number LIKE ? ORDER BY id DESC LIMIT 1`, [`${prefix}/${fy}/%`]);
    let invNext=1;
    if (lastInv.length) { const p=lastInv[0].invoice_number.split('/'); invNext=(parseInt(p[2])||0)+1; }
    const invoice_number = `${prefix}/${fy}/${String(invNext).padStart(3,'0')}`;
    const subtotal = +d.freight_amount+(+d.detention_charges||0)+(+d.kata_charges||0)+(+d.loading_charges||0)+(+d.unloading_charges||0);
    const total_amount = subtotal+gst_amount;
    await conn.query(`INSERT INTO invoices(invoice_number,invoice_date,consignee_id,trip_ids,subtotal,gst_amount,total_amount,amount_paid,payment_status,notes)VALUES(?,?,?,?,?,?,?,?,?,?)`,
      [invoice_number,d.trip_date,d.consignee_id||null,JSON.stringify([tripId]),subtotal,gst_amount,total_amount,d.advance_paid||0,
       +d.advance_paid>=total_amount?'paid':+d.advance_paid>0?'partial':'unpaid',`Auto for trip ${d.lr_number}`]);

    // Auto-create owner ledger entry for brokerage
    if (d.trip_type==='brokerage' && d.broker_owner_name) {
      const ownerPayable = +d.freight_amount-+commission_amount;
      await conn.query(`INSERT INTO owner_payments(trip_id,owner_name,owner_phone,truck_number,freight_amount,commission_amount,payable_amount,advance_paid,balance_due,status)VALUES(?,?,?,?,?,?,?,?,?,?)`,
        [tripId,d.broker_owner_name,d.broker_owner_phone||'',d.broker_truck_number||'',
         d.freight_amount||0,commission_amount,ownerPayable,d.broker_advance_paid||0,
         ownerPayable-(d.broker_advance_paid||0),'pending']);
    }
    await conn.commit();
    res.status(201).json({ id:tripId, message:'Trip created', invoice_number });
  } catch(e) { await conn.rollback(); console.error(e); res.status(500).json({ error:e.message }); }
  finally { conn.release(); }
});

// PUT — update trip (admin + staff1)
router.put('/:id', adminOrStaff1, async (req, res) => {
  const d = req.body;
  const commission_amount = d.trip_type==='brokerage'?((+d.freight_amount||0)*(+d.commission_percent||0)/100).toFixed(2):0;
  const driver_extra_pay  = d.trip_type==='owned'&&d.distance_km?(+d.distance_km*5).toFixed(2):0;
  const gst_amount = (+d.freight_amount||0)*(+d.gst_rate||0)/100;
  try {
    await db.query(`UPDATE trips SET trip_number=?,lr_number=?,trip_date=?,trip_type=?,
      truck_id=?,driver_id=?,broker_owner_name=?,broker_owner_phone=?,broker_truck_number=?,broker_driver_name=?,
      commission_percent=?,commission_amount=?,consignee_id=?,from_location=?,to_location=?,
      distance_km=?,weight_tons=?,freight_amount=?,advance_paid=?,
      detention_charges=?,kata_charges=?,loading_charges=?,unloading_charges=?,
      gst_type=?,gst_rate=?,gst_amount=?,driver_extra_pay=?,status=?,notes=? WHERE id=?`,
      [d.trip_number,d.lr_number,d.trip_date,d.trip_type,
       d.truck_id||null,d.driver_id||null,d.broker_owner_name||null,d.broker_owner_phone||null,
       d.broker_truck_number||null,d.broker_driver_name||null,
       d.commission_percent||0,commission_amount,d.consignee_id||null,
       d.from_location,d.to_location,d.distance_km||0,d.weight_tons||0,
       d.freight_amount||0,d.advance_paid||0,
       d.detention_charges||0,d.kata_charges||0,d.loading_charges||0,d.unloading_charges||0,
       d.gst_type||'exempt',d.gst_rate||0,gst_amount,driver_extra_pay,
       d.status||'planned',d.notes||'',req.params.id]);
    res.json({ message:'Trip updated' });
  } catch(e) { console.error(e); res.status(500).json({ error:'Failed' }); }
});

// DELETE — admin only
router.delete('/:id', adminOnly, async (req, res) => {
  await db.query('DELETE FROM trips WHERE id=?', [req.params.id]);
  res.json({ message:'Deleted' });
});

module.exports = router;
