const express = require('express');
const cors    = require('cors');
require('dotenv').config();

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173', credentials: true }));
app.use(express.json());

// Routes
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/settings',      require('./routes/settings'));
app.use('/api/trips',         require('./routes/trips'));
app.use('/api/trucks',        require('./routes/trucks'));
app.use('/api/drivers',       require('./routes/drivers'));
app.use('/api/trip-expenses', require('./routes/tripExpenses'));
app.use('/api/consignees',    require('./routes/consignees'));
app.use('/api/invoices',      require('./routes/invoices'));
app.use('/api/maintenance',   require('./routes/maintenance'));
app.use('/api/tyres',         require('./routes/tyres'));
app.use('/api/dashboard',     require('./routes/dashboard'));
app.use('/api/ai',            require('./routes/ai'));

app.get('/api/health', (_, res) => res.json({ status: 'ok', version: '4.0', time: new Date() }));
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Server error' }); });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚛 MFC Portal v4.0 running on http://localhost:${PORT}`);
  console.log(`🔍 Health: http://localhost:${PORT}/api/health`);
});
