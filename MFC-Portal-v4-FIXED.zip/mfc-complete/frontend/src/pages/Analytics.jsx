import React, { useEffect, useState } from 'react';
import { Box, Typography, TextField, MenuItem, Tabs, Tab } from '@mui/material';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import api from '../utils/api';

const fmtL = n => { const v=+n||0; return v>=100000?`₹${(v/100000).toFixed(1)}L`:v>=1000?`₹${(v/1000).toFixed(0)}K`:`₹${v}`; };
const fmt  = n => `₹${(+n||0).toLocaleString('en-IN')}`;

function Kpi({ label, value, sub, color }) {
  return (
    <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', borderLeft:`3px solid ${color||'#2563eb'}`, p:'12px 14px' }}>
      <Typography sx={{ fontSize:11, color:'#6b7a99', mb:0.3 }}>{label}</Typography>
      <Typography sx={{ fontSize:20, fontWeight:500 }}>{value}</Typography>
      {sub && <Typography sx={{ fontSize:11, color:'#6b7a99', mt:0.2 }}>{sub}</Typography>}
    </Box>
  );
}

function Legend2({ items }) {
  return (
    <Box sx={{ display:'flex', flexWrap:'wrap', gap:'12px', mb:1 }}>
      {items.map(([c,l])=>(
        <Box key={l} sx={{ display:'flex', alignItems:'center', gap:'5px' }}>
          <Box sx={{ width:10, height:10, bgcolor:c, borderRadius:'2px' }}/>
          <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{l}</Typography>
        </Box>
      ))}
    </Box>
  );
}

const MONTHS = ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'];
const COLORS  = ['#1a2744','#2563eb','#16a34a','#f59e0b','#dc2626','#7c3aed','#0891b2'];

export default function Analytics() {
  const [tab, setTab]     = useState(0);
  const [trips, setTrips] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [trucks, setTrucks]   = useState([]);

  useEffect(() => {
    api.get('/trips?limit=500').then(r=>setTrips(r.data.data||[])).catch(()=>{});
    api.get('/drivers').then(r=>setDrivers(r.data||[])).catch(()=>{});
    api.get('/trucks').then(r=>setTrucks(r.data||[])).catch(()=>{});
  }, []);

  // Build monthly revenue data from real trips
  const monthlyData = () => {
    const map = {};
    MONTHS.forEach(m => map[m] = { month:m, owned:0, brokerage:0, trips:0 });
    trips.forEach(t => {
      const m = new Date(t.trip_date).toLocaleDateString('en-GB',{month:'short'}).replace('.','');
      const key = m.charAt(0).toUpperCase()+m.slice(1,3);
      if (!map[key]) return;
      if (t.trip_type==='owned') map[key].owned += +t.freight_amount||0;
      else map[key].brokerage += +t.commission_amount||0;
      map[key].trips++;
    });
    return Object.values(map);
  };

  const ownedTrips     = trips.filter(t=>t.trip_type==='owned');
  const brokerTrips    = trips.filter(t=>t.trip_type==='brokerage');
  const totalRevenue   = ownedTrips.reduce((s,t)=>s+(+t.freight_amount||0),0);
  const totalComm      = brokerTrips.reduce((s,t)=>s+(+t.commission_amount||0),0);
  const totalTrips     = trips.length;

  // Driver stats
  const driverData = drivers.map(d => {
    const dTrips = trips.filter(t=>t.driver_id===d.id);
    return { name:d.name.split(' ')[0], trips:dTrips.length, revenue:dTrips.reduce((s,t)=>s+(+t.freight_amount||0),0) };
  }).sort((a,b)=>b.trips-a.trips).slice(0,6);

  // Route stats
  const routeMap = {};
  trips.forEach(t => {
    const key = `${t.from_location||'?'}→${t.to_location||'?'}`;
    if (!routeMap[key]) routeMap[key] = { route:key, trips:0, revenue:0 };
    routeMap[key].trips++;
    routeMap[key].revenue += +t.freight_amount||0;
  });
  const routeData = Object.values(routeMap).sort((a,b)=>b.revenue-a.revenue).slice(0,6);

  // Truck stats
  const truckData = trucks.map(t => {
    const tTrips = trips.filter(tr=>tr.truck_id===t.id);
    return { name:t.truck_number?.slice(-6)||t.id, trips:tTrips.length, revenue:tTrips.reduce((s,tr)=>s+(+tr.freight_amount||0),0) };
  }).sort((a,b)=>b.revenue-a.revenue);

  const TABS = ['Revenue','Trips','Drivers','Routes','Fleet','Profit'];
  const monthly = monthlyData();

  return (
    <Box>
      {/* Global filters */}
      <Box sx={{ display:'flex', gap:1.5, mb:2, flexWrap:'wrap' }}>
        <TextField select label="Financial year" size="small" defaultValue="2627" sx={{ minWidth:130 }}>
          <MenuItem value="2627">FY 2026-27</MenuItem>
          <MenuItem value="2526">FY 2025-26</MenuItem>
        </TextField>
        <TextField select label="Period" size="small" defaultValue="monthly" sx={{ minWidth:120 }}>
          <MenuItem value="monthly">Monthly</MenuItem>
          <MenuItem value="quarterly">Quarterly</MenuItem>
          <MenuItem value="weekly">Weekly</MenuItem>
        </TextField>
        <TextField select label="Truck" size="small" defaultValue="all" sx={{ minWidth:150 }}>
          <MenuItem value="all">All trucks</MenuItem>
          {trucks.map(t=><MenuItem key={t.id} value={t.id}>{t.truck_number}</MenuItem>)}
        </TextField>
        <TextField select label="Driver" size="small" defaultValue="all" sx={{ minWidth:150 }}>
          <MenuItem value="all">All drivers</MenuItem>
          {drivers.map(d=><MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
        </TextField>
      </Box>

      {/* Summary KPIs */}
      <Box sx={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'10px', mb:2 }}>
        <Kpi label="Own truck revenue" value={fmtL(totalRevenue)} sub="All time" color="#2563eb"/>
        <Kpi label="Brokerage commission" value={fmtL(totalComm)} sub="All time" color="#f59e0b"/>
        <Kpi label="Total trips" value={totalTrips} sub={`${ownedTrips.length} own · ${brokerTrips.length} brokerage`} color="#16a34a"/>
        <Kpi label="Avg revenue/trip" value={fmt(ownedTrips.length?totalRevenue/ownedTrips.length:0)} sub="Own trips only" color="#7c3aed"/>
      </Box>

      {/* Tab bar */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', overflow:'hidden' }}>
        <Tabs value={tab} onChange={(_,v)=>setTab(v)} sx={{ borderBottom:'0.5px solid #e2e6ef', '& .MuiTab-root':{ fontSize:12, minHeight:40, textTransform:'none', color:'#6b7a99' }, '& .Mui-selected':{ color:'#1a2744', fontWeight:500 }, '& .MuiTabs-indicator':{ bgcolor:'#1a2744' } }}>
          {TABS.map(t=><Tab key={t} label={t}/>)}
        </Tabs>

        <Box sx={{ p:'14px' }}>

          {/* REVENUE */}
          {tab===0 && (
            <Box>
              <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Monthly earnings — own trucks vs brokerage commission</Typography>
              <Legend2 items={[['#1a2744','Own trucks'],['#f59e0b','Brokerage commission']]}/>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={monthly} margin={{ top:0, right:0, left:-15, bottom:0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false}/>
                  <XAxis dataKey="month" tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                  <YAxis tick={{ fontSize:10, fill:'#6b7a99' }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                  <Tooltip formatter={(v,n)=>[`₹${(+v).toLocaleString('en-IN')}`,n]}/>
                  <Bar dataKey="owned" name="Own trucks" fill="#1a2744" radius={[3,3,0,0]}/>
                  <Bar dataKey="brokerage" name="Brokerage" fill="#f59e0b" radius={[3,3,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </Box>
          )}

          {/* TRIPS */}
          {tab===1 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Monthly trip count</Typography>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={monthly} margin={{ top:0, right:0, left:-15, bottom:0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false}/>
                      <XAxis dataKey="month" tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                      <YAxis tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                      <Tooltip/>
                      <Bar dataKey="trips" fill="#1a2744" radius={[3,3,0,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Trip type split</Typography>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={[{name:'Owned',value:ownedTrips.length},{name:'Brokerage',value:brokerTrips.length}]} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" label={({name,percent})=>`${name} ${(percent*100).toFixed(0)}%`}>
                        <Cell fill="#1a2744"/><Cell fill="#f59e0b"/>
                      </Pie>
                      <Tooltip/>
                    </PieChart>
                  </ResponsiveContainer>
                </Box>
              </Box>
            </Box>
          )}

          {/* DRIVERS */}
          {tab===2 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', mb:2 }}>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Trips per driver</Typography>
                  <ResponsiveContainer width="100%" height={Math.max(160,driverData.length*40+60)}>
                    <BarChart data={driverData} layout="vertical" margin={{ top:0, right:10, left:10, bottom:0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false}/>
                      <XAxis type="number" tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                      <YAxis dataKey="name" type="category" tick={{ fontSize:11, fill:'#374151' }} axisLine={false} tickLine={false} width={65}/>
                      <Tooltip/>
                      <Bar dataKey="trips" fill="#1a2744" radius={[0,3,3,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Revenue by driver</Typography>
                  <ResponsiveContainer width="100%" height={Math.max(160,driverData.length*40+60)}>
                    <BarChart data={driverData} layout="vertical" margin={{ top:0, right:10, left:10, bottom:0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false}/>
                      <XAxis type="number" tick={{ fontSize:10, fill:'#6b7a99' }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                      <YAxis dataKey="name" type="category" tick={{ fontSize:11, fill:'#374151' }} axisLine={false} tickLine={false} width={65}/>
                      <Tooltip formatter={v=>[`₹${(+v).toLocaleString('en-IN')}`,'']}/>
                      <Bar dataKey="revenue" fill="#2563eb" radius={[0,3,3,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </Box>
              {/* Driver table */}
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Driver','Total trips','Revenue generated','Avg per trip'].map(h=><th key={h} style={{ padding:'7px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {driverData.map((d,i)=>(
                    <tr key={d.name} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'8px 12px', fontSize:12, fontWeight:500 }}>{d.name}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{d.trips}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{fmt(d.revenue)}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{fmt(d.trips?d.revenue/d.trips:0)}</td>
                    </tr>
                  ))}
                  {!driverData.length&&<tr><td colSpan={4} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No trip data yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}

          {/* ROUTES */}
          {tab===3 && (
            <Box>
              <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Top routes by revenue</Typography>
              <ResponsiveContainer width="100%" height={Math.max(160,routeData.length*40+60)}>
                <BarChart data={routeData} layout="vertical" margin={{ top:0, right:10, left:20, bottom:0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false}/>
                  <XAxis type="number" tick={{ fontSize:10, fill:'#6b7a99' }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                  <YAxis dataKey="route" type="category" tick={{ fontSize:11, fill:'#374151' }} axisLine={false} tickLine={false} width={100}/>
                  <Tooltip formatter={v=>[`₹${(+v).toLocaleString('en-IN')}`,'']}/>
                  <Bar dataKey="revenue" fill="#1a2744" radius={[0,3,3,0]}/>
                </BarChart>
              </ResponsiveContainer>
              <table style={{ width:'100%', borderCollapse:'collapse', marginTop:14 }}>
                <thead><tr style={{ background:'#fafbfc' }}>{['Route','Trips','Total revenue','Avg per trip'].map(h=><th key={h} style={{ padding:'7px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {routeData.map(r=>(
                    <tr key={r.route} style={{ borderBottom:'0.5px solid #e2e6ef' }}>
                      <td style={{ padding:'8px 12px', fontSize:12, fontWeight:500 }}>{r.route}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{r.trips}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{fmt(r.revenue)}</td>
                      <td style={{ padding:'8px 12px', fontSize:12 }}>{fmt(r.trips?r.revenue/r.trips:0)}</td>
                    </tr>
                  ))}
                  {!routeData.length&&<tr><td colSpan={4} style={{ padding:'24px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No trip data yet.</td></tr>}
                </tbody>
              </table>
            </Box>
          )}

          {/* FLEET */}
          {tab===4 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Trips per truck</Typography>
                  <ResponsiveContainer width="100%" height={Math.max(160,truckData.length*44+60)}>
                    <BarChart data={truckData} layout="vertical" margin={{ top:0, right:10, left:10, bottom:0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false}/>
                      <XAxis type="number" tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                      <YAxis dataKey="name" type="category" tick={{ fontSize:10, fill:'#374151' }} axisLine={false} tickLine={false} width={70}/>
                      <Tooltip/>
                      <Bar dataKey="trips" fill="#1a2744" radius={[0,3,3,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
                <Box>
                  <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Revenue per truck</Typography>
                  <ResponsiveContainer width="100%" height={Math.max(160,truckData.length*44+60)}>
                    <BarChart data={truckData} layout="vertical" margin={{ top:0, right:10, left:10, bottom:0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false}/>
                      <XAxis type="number" tick={{ fontSize:10, fill:'#6b7a99' }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                      <YAxis dataKey="name" type="category" tick={{ fontSize:10, fill:'#374151' }} axisLine={false} tickLine={false} width={70}/>
                      <Tooltip formatter={v=>[`₹${(+v).toLocaleString('en-IN')}`,'']}/>
                      <Bar dataKey="revenue" fill="#2563eb" radius={[0,3,3,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </Box>
            </Box>
          )}

          {/* PROFIT */}
          {tab===5 && (
            <Box>
              <Box sx={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', mb:2 }}>
                <Kpi label="Total own revenue" value={fmtL(totalRevenue)} color="#2563eb"/>
                <Kpi label="Total brokerage commission" value={fmtL(totalComm)} color="#f59e0b"/>
                <Kpi label="Combined earnings" value={fmtL(totalRevenue+totalComm)} color="#16a34a"/>
              </Box>
              <Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', mb:0.5 }}>Monthly earnings trend</Typography>
              <Legend2 items={[['#1a2744','Own revenue'],['#f59e0b','Brokerage']]}/>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={monthly} margin={{ top:0, right:10, left:-15, bottom:0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false}/>
                  <XAxis dataKey="month" tick={{ fontSize:10, fill:'#6b7a99' }} axisLine={false} tickLine={false}/>
                  <YAxis tick={{ fontSize:10, fill:'#6b7a99' }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`} axisLine={false} tickLine={false}/>
                  <Tooltip formatter={(v,n)=>[`₹${(+v).toLocaleString('en-IN')}`,n]}/>
                  <Line type="monotone" dataKey="owned" name="Own revenue" stroke="#1a2744" strokeWidth={2} dot={{ r:3 }}/>
                  <Line type="monotone" dataKey="brokerage" name="Brokerage" stroke="#f59e0b" strokeWidth={2} dot={{ r:3 }}/>
                </LineChart>
              </ResponsiveContainer>
            </Box>
          )}

        </Box>
      </Box>
    </Box>
  );
}
