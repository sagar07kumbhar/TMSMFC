import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Grid } from '@mui/material';
import { Add } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';
import usePermissions from '../hooks/usePermissions';

function validate(f) {
  const e = {};
  if (!f.name?.trim())           e.name           = 'Name is required';
  if (!f.phone?.trim())          e.phone          = 'Phone is required';
  else if (!/^[6-9]\d{9}$/.test(f.phone)) e.phone = 'Enter valid 10-digit mobile';
  if (!f.license_number?.trim()) e.license_number = 'License number required';
  if (f.license_expiry && new Date(f.license_expiry) < new Date()) e.license_expiry = 'Cannot be in the past';
  if (f.aadhaar_number && !/^\d{12}$/.test(f.aadhaar_number)) e.aadhaar_number = 'Must be exactly 12 digits';
  return e;
}

const AADHAAR_BADGE = {
  verified:     { bg:'#dcfce7', color:'#166534', label:'Verified' },
  pending:      { bg:'#fef9c3', color:'#854d0e', label:'Pending' },
  not_verified: { bg:'#fee2e2', color:'#991b1b', label:'Not verified' },
};

const BLANK = { name:'', phone:'', license_number:'', license_expiry:'', badge_expiry:'', address:'', aadhaar_number:'', aadhaar_status:'not_verified', aadhaar_copy_uploaded:false, is_active:true };

export default function Drivers() {
  const [list, setList]         = useState([]);
  const [maxTrips, setMaxTrips] = useState(1);
  const [open, setOpen]         = useState(false);
  const [form, setForm]         = useState(BLANK);
  const [editing, setEditing]   = useState(null);
  const [errors, setErrors]     = useState({});
  const [touched, setTouched]   = useState({});
  const showToast = useToast();
  const { can, isAdmin, isStaff2 } = usePermissions();
  const showAadhaar = can('show_aadhaar');
  const canEdit = isAdmin || isStaff2;

  const load = async () => {
    try {
      const r = await api.get('/drivers');
      const drivers = r.data || [];
      setList(drivers);
      const mx = Math.max(1, ...drivers.map(d => d.trips_this_month || 0));
      setMaxTrips(mx);
    } catch {}
  };
  useEffect(() => { load(); }, []);

  const openForm = (d=null) => {
    setEditing(d?.id||null); setErrors({}); setTouched({});
    setForm(d ? { name:d.name||'', phone:d.phone||'', license_number:d.license_number||'', license_expiry:d.license_expiry?.slice(0,10)||'', badge_expiry:d.badge_expiry?.slice(0,10)||'', address:d.address||'', aadhaar_number:d.aadhaar_number||'', aadhaar_status:d.aadhaar_status||'not_verified', aadhaar_copy_uploaded:d.aadhaar_copy_uploaded||false, is_active:d.is_active??true } : BLANK);
    setOpen(true);
  };

  const save = async () => {
    const at={}; Object.keys(form).forEach(k=>at[k]=true); setTouched(at);
    const errs=validate(form); setErrors(errs);
    if (Object.keys(errs).length>0) { showToast('Please fix the errors','error'); return; }
    try {
      editing ? await api.put(`/drivers/${editing}`,form) : await api.post('/drivers',form);
      setOpen(false); load();
      showToast(editing?'Driver updated':'Driver added','success');
    } catch(e) { showToast(e.response?.data?.error||'Failed','error'); }
  };

  const f=(k,v)=>{ setForm(p=>({...p,[k]:v})); if(touched[k]){ setErrors(validate({...form,[k]:v})); } };
  const blur=k=>{ setTouched(p=>({...p,[k]:true})); setErrors(validate(form)); };

  return (
    <Box>
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px 8px 0 0', border:'0.5px solid #e2e6ef', borderBottom:'none', p:'10px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <Box>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Drivers</Typography>
          <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{list.length} registered · {list.filter(d=>d.is_active).length} active</Typography>
        </Box>
        {canEdit && <Button size="small" variant="contained" startIcon={<Add/>} onClick={()=>openForm()} sx={{ bgcolor:'#1a2744', fontSize:12 }}>Add driver</Button>}
      </Box>

      <Box sx={{ bgcolor:'#fff', border:'0.5px solid #e2e6ef', borderRadius:'0 0 8px 8px', overflow:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', minWidth:820 }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {['Driver','Phone','License no.','License expiry',...(showAadhaar?['Aadhaar']:[]),'Trips (month)','Status',''].map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef', whiteSpace:'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {list.map(d => {
              const exp = d.license_expiry;
              const days = exp ? Math.ceil((new Date(exp)-new Date())/86400000) : null;
              const ab = AADHAAR_BADGE[d.aadhaar_status]||AADHAAR_BADGE.not_verified;
              const trips = d.trips_this_month||0;
              const pct = maxTrips>0 ? Math.round((trips/maxTrips)*100) : 0;
              return (
                <tr key={d.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                  onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                  <td style={{ padding:'9px 12px' }}>
                    <div style={{ fontWeight:500, fontSize:13 }}>{d.name}</div>
                    {d.badge_expiry && <div style={{ fontSize:10, color:'#6b7a99', marginTop:2 }}>Badge: {new Date(d.badge_expiry).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>}
                  </td>
                  <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99' }}>{d.phone}</td>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>{d.license_number}</td>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>
                    {days===null?'—':days<0
                      ?<span style={{color:'#dc2626',fontWeight:500}}>Expired</span>
                      :days<=30
                        ?<span style={{color:'#d97706',fontWeight:500}}>{new Date(exp).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})} ({days}d)</span>
                        :<span>{new Date(exp).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</span>}
                  </td>
                  {showAadhaar && (
                    <td style={{ padding:'9px 12px' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                        <span style={{ display:'inline-block', padding:'2px 7px', borderRadius:20, fontSize:11, fontWeight:500, background:ab.bg, color:ab.color }}>{ab.label}</span>
                        {d.aadhaar_number && <span style={{ fontSize:10, color:'#6b7a99' }}>••••{d.aadhaar_number.slice(-4)}</span>}
                      </div>
                    </td>
                  )}
                  <td style={{ padding:'9px 12px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <span style={{ fontSize:14, fontWeight:500, minWidth:18, textAlign:'right', color: trips===0?'#9ca3af':'#1a2744' }}>{trips}</span>
                      <div style={{ flex:1, maxWidth:54, height:4, background:'#e2e8f0', borderRadius:2, overflow:'hidden' }}>
                        <div style={{ height:'100%', width:`${pct}%`, background:pct>=100?'#16a34a':'#2563eb', borderRadius:2 }}/>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding:'9px 12px' }}>
                    <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500, background:d.is_active?'#dcfce7':'#fee2e2', color:d.is_active?'#166534':'#991b1b' }}>
                      {d.is_active?'Active':'Inactive'}
                    </span>
                  </td>
                  <td style={{ padding:'9px 12px' }}>
                    {canEdit && <button onClick={()=>openForm(d)} style={{ padding:'2px 8px', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:10, cursor:'pointer', background:'#fff', color:'inherit' }}>Edit</button>}
                  </td>
                </tr>
              );
            })}
            {!list.length && <tr><td colSpan={8} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No drivers added yet.</td></tr>}
          </tbody>
        </table>
      </Box>

      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>{editing?'Edit driver':'Add new driver'}</DialogTitle>
        <DialogContent sx={{ pt:1 }}>
          <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1, mt:0.5 }}>Personal details</Typography>
          <Grid container spacing={1.5} sx={{ mb:2 }}>
            <Grid item xs={4}><TextField label="Full name *" fullWidth value={form.name} onChange={e=>f('name',e.target.value)} onBlur={()=>blur('name')} error={touched.name&&!!errors.name} helperText={touched.name&&errors.name}/></Grid>
            <Grid item xs={4}><TextField label="Phone *" fullWidth value={form.phone} onChange={e=>f('phone',e.target.value.replace(/\D/,''))} onBlur={()=>blur('phone')} error={touched.phone&&!!errors.phone} helperText={touched.phone&&errors.phone} inputProps={{maxLength:10}}/></Grid>
            <Grid item xs={4}><TextField label="Address" fullWidth value={form.address} onChange={e=>f('address',e.target.value)}/></Grid>
          </Grid>
          <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1 }}>License & badge</Typography>
          <Grid container spacing={1.5} sx={{ mb:2 }}>
            <Grid item xs={4}><TextField label="License number *" fullWidth value={form.license_number} onChange={e=>f('license_number',e.target.value)} onBlur={()=>blur('license_number')} error={touched.license_number&&!!errors.license_number} helperText={touched.license_number&&errors.license_number} placeholder="e.g. MH1420190012345"/></Grid>
            <Grid item xs={4}><TextField label="License expiry *" type="date" fullWidth value={form.license_expiry} onChange={e=>f('license_expiry',e.target.value)} onBlur={()=>blur('license_expiry')} error={touched.license_expiry&&!!errors.license_expiry} helperText={touched.license_expiry&&errors.license_expiry} InputLabelProps={{shrink:true}}/></Grid>
            <Grid item xs={4}><TextField label="Badge expiry" type="date" fullWidth value={form.badge_expiry} onChange={e=>f('badge_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
          </Grid>
          <Box sx={{ bgcolor:'#fffbeb', border:'0.5px solid #fcd34d', borderRadius:'6px', p:'12px', mb:2 }}>
            <Typography sx={{ fontSize:10, fontWeight:600, color:'#92400e', textTransform:'uppercase', letterSpacing:'0.06em', mb:1 }}>Aadhaar details</Typography>
            <Grid container spacing={1.5}>
              <Grid item xs={4}><TextField label="Aadhaar number" fullWidth value={form.aadhaar_number} onChange={e=>f('aadhaar_number',e.target.value.replace(/\D/,''))} onBlur={()=>blur('aadhaar_number')} error={touched.aadhaar_number&&!!errors.aadhaar_number} helperText={(touched.aadhaar_number&&errors.aadhaar_number)||'12 digits'} inputProps={{maxLength:12}}/></Grid>
              <Grid item xs={4}><TextField select label="Verification status" fullWidth value={form.aadhaar_status} onChange={e=>f('aadhaar_status',e.target.value)}>
                <MenuItem value="verified">Verified</MenuItem>
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="not_verified">Not verified</MenuItem>
              </TextField></Grid>
              <Grid item xs={4}><TextField select label="Copy uploaded" fullWidth value={form.aadhaar_copy_uploaded?'yes':'no'} onChange={e=>f('aadhaar_copy_uploaded',e.target.value==='yes')}>
                <MenuItem value="no">Not uploaded</MenuItem>
                <MenuItem value="yes">Uploaded</MenuItem>
              </TextField></Grid>
            </Grid>
            <Typography sx={{ fontSize:11, color:'#92400e', mt:1 }}>Only last 4 digits shown in the table.</Typography>
          </Box>
          <Grid container spacing={1.5}>
            <Grid item xs={4}><TextField select label="Status" fullWidth value={form.is_active?'active':'inactive'} onChange={e=>f('is_active',e.target.value==='active')}>
              <MenuItem value="active">Active</MenuItem>
              <MenuItem value="inactive">Inactive</MenuItem>
            </TextField></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2.5, gap:1 }}>
          <Button onClick={()=>setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={save} sx={{ bgcolor:'#1a2744', px:3 }}>{editing?'Update':'Save driver'}</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
