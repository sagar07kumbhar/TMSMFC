import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Button, CircularProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, MenuItem, Grid, Alert, Chip
} from '@mui/material';
import { Add, Edit, Delete, LockOutlined } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';
import usePermissions from '../hooks/usePermissions';

const STATUS_STYLE = {
  planned:     { bg:'#f1f5f9', color:'#475569' },
  in_progress: { bg:'#dbeafe', color:'#1e40af' },
  completed:   { bg:'#dcfce7', color:'#166534' },
  cancelled:   { bg:'#fee2e2', color:'#991b1b' },
};
const Badge = ({ label, style }) => (
  <span style={{ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:500, background:style?.bg||'#f1f5f9', color:style?.color||'#475569' }}>{label}</span>
);
const fmt = n => `₹${(+n||0).toLocaleString('en-IN')}`;

const BLANK_OWNED = {
  trip_number:'', lr_number:'', trip_date:new Date().toISOString().slice(0,10),
  trip_type:'owned', truck_id:'', driver_id:'',
  consignee_id:'', from_location:'', to_location:'',
  distance_km:'', weight_tons:'', freight_amount:'', advance_paid:'',
  detention_charges:0, kata_charges:0, loading_charges:0, unloading_charges:0,
  gst_type:'exempt', gst_rate:0, status:'planned', notes:''
};
const BLANK_BROKER = {
  trip_number:'', lr_number:'', trip_date:new Date().toISOString().slice(0,10),
  trip_type:'brokerage',
  broker_owner_name:'', broker_owner_phone:'', broker_truck_number:'', broker_driver_name:'',
  commission_percent:5,
  consignee_id:'', from_location:'', to_location:'',
  distance_km:'', weight_tons:'', freight_amount:'', advance_paid:'',
  broker_advance_paid:0, gst_type:'exempt', gst_rate:0, status:'planned', notes:''
};

function validate(form) {
  const errs = {};
  if (!form.lr_number)    errs.lr_number    = 'LR number required';
  if (!form.trip_date)    errs.trip_date    = 'Date required';
  if (!form.from_location) errs.from_location = 'From required';
  if (!form.to_location)   errs.to_location   = 'To required';
  if (!form.freight_amount || +form.freight_amount <= 0) errs.freight_amount = 'Freight amount required';
  if (form.trip_type === 'owned') {
    if (!form.truck_id)  errs.truck_id  = 'Select a truck';
    if (!form.driver_id) errs.driver_id = 'Select a driver';
  }
  if (form.trip_type === 'brokerage') {
    if (!form.broker_owner_name)   errs.broker_owner_name   = 'Owner name required';
    if (!form.broker_truck_number) errs.broker_truck_number = 'Truck number required';
  }
  return errs;
}

export default function Trips() {
  const [trips, setTrips]         = useState([]);
  const [trucks, setTrucks]       = useState([]);
  const [drivers, setDrivers]     = useState([]);
  const [consignees, setConsignees] = useState([]);
  const [filter, setFilter]       = useState('all');
  const [activeTab, setActiveTab] = useState('owned');
  const [open, setOpen]           = useState(false);
  const [form, setForm]           = useState(BLANK_OWNED);
  const [editing, setEditing]     = useState(null);
  const [lrLoading, setLrLoading] = useState(false);
  const [errors, setErrors]       = useState({});
  const [touched, setTouched]     = useState({});
  const showToast = useToast();
  const { can, isAdmin, isStaff1 } = usePermissions();

  const showFreightInList   = can('show_freight_in_list');   // admin only in table
  const showFreightInForm   = can('show_freight_amount');    // admin + staff1 in form
  const canDelete           = can('can_delete_trip');        // admin only

  const load = async () => {
    try { const r = await api.get('/trips'); setTrips(r.data.data||[]); } catch {}
    try { const r = await api.get('/trucks'); setTrucks(r.data||[]); } catch {}
    try { const r = await api.get('/drivers'); setDrivers(r.data||[]); } catch {}
    try { const r = await api.get('/consignees'); setConsignees(r.data||[]); } catch {}
  };
  useEffect(() => { load(); }, []);

  const openForm = async (trip=null, type='owned') => {
    setEditing(trip?.id||null);
    setErrors({}); setTouched({});
    if (trip) { setForm({...trip}); setActiveTab(trip.trip_type||'owned'); }
    else {
      setLrLoading(true);
      let lr_number='';
      try { const r=await api.get('/trips/next-lr'); lr_number=r.data.lr_number; } catch {}
      finally { setLrLoading(false); }
      const blank = type==='owned' ? BLANK_OWNED : BLANK_BROKER;
      setForm({...blank, trip_number:`TRIP-${Date.now().toString().slice(-6)}`, lr_number});
      setActiveTab(type);
    }
    setOpen(true);
  };

  const switchTab = (t) => {
    setActiveTab(t); setErrors({}); setTouched({});
    const blank = t==='owned' ? BLANK_OWNED : BLANK_BROKER;
    setForm(p=>({...blank, trip_number:p.trip_number, lr_number:p.lr_number, trip_date:p.trip_date, consignee_id:p.consignee_id}));
  };

  const save = async () => {
    const allTouched={}; Object.keys(form).forEach(k=>allTouched[k]=true); setTouched(allTouched);
    const errs=validate(form); setErrors(errs);
    if (Object.keys(errs).length>0) { showToast('Please fix the errors','error'); return; }
    try {
      const res = editing ? await api.put(`/trips/${editing}`,form) : await api.post('/trips',form);
      setOpen(false); load();
      if (!editing && res.data.invoice_number) showToast(`Trip saved! Invoice ${res.data.invoice_number} auto-generated`,'success');
      else showToast(editing?'Trip updated':'Trip saved','success');
    } catch(e) { showToast(e.response?.data?.error||'Failed to save','error'); }
  };

  const del = async id => {
    if (!confirm('Delete this trip?')) return;
    try { await api.delete(`/trips/${id}`); load(); showToast('Trip deleted','info'); }
    catch { showToast('Failed to delete','error'); }
  };

  const f=(k,v)=>{
    setForm(p=>({...p,[k]:v}));
    if(touched[k]){ const errs=validate({...form,[k]:v}); setErrors(errs); }
  };
  const blur=k=>{ setTouched(p=>({...p,[k]:true})); setErrors(validate(form)); };

  const filtered = filter==='all' ? trips : trips.filter(t=>t.trip_type===filter);

  const owned = () => {
    const fr=+form.freight_amount||0, exp=(+form.detention_charges||0)+(+form.kata_charges||0)+(+form.loading_charges||0)+(+form.unloading_charges||0), drv=(+form.distance_km||0)*5;
    return {fr,exp,drv,net:fr-exp-drv,due:fr-(+form.advance_paid||0)};
  };
  const broker = () => {
    const fr=+form.freight_amount||0, p=+form.commission_percent||0, comm=fr*p/100;
    return {fr,comm,p,ownerPay:fr-comm,due:fr-(+form.advance_paid||0),ownerRem:(fr-comm)-(+form.broker_advance_paid||0)};
  };

  // Table columns — freight hidden for staff1
  const cols = ['LR No.','Date','Route','Type','Vehicle','Consignee',
    ...(showFreightInList ? ['Freight','Advance','Due'] : []),
    'Status',''];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ bgcolor:'#fff', borderRadius:'8px 8px 0 0', border:'0.5px solid #e2e6ef', borderBottom:'none', p:'10px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <Box sx={{ display:'flex', gap:1 }}>
          {['all','owned','brokerage'].map(v=>(
            <Button key={v} size="small" variant={filter===v?'contained':'outlined'} onClick={()=>setFilter(v)}
              sx={{ fontSize:11.5, py:0.4, minWidth:0, bgcolor:filter===v?'#1a2744':'transparent', borderColor:'#e2e6ef', color:filter===v?'#fff':'#6b7a99' }}>
              {v==='all'?'All':v.charAt(0).toUpperCase()+v.slice(1)}
            </Button>
          ))}
        </Box>
        <Box sx={{ display:'flex', gap:1 }}>
          <Button size="small" variant="outlined" startIcon={<Add/>} onClick={()=>openForm(null,'owned')}
            sx={{ fontSize:11.5, borderColor:'#2563eb', color:'#2563eb' }}>Own trip</Button>
          {/* Only admin can add brokerage trips */}
          {isAdmin && (
            <Button size="small" variant="contained" startIcon={<Add/>} onClick={()=>openForm(null,'brokerage')}
              sx={{ fontSize:11.5, bgcolor:'#f59e0b', '&:hover':{bgcolor:'#d97706'} }}>Brokerage trip</Button>
          )}
        </Box>
      </Box>

      {/* Staff1 info banner */}
      {isStaff1 && (
        <Box sx={{ bgcolor:'#eff6ff', border:'0.5px solid #bfdbfe', borderTop:'none', p:'7px 14px', display:'flex', alignItems:'center', gap:1 }}>
          <LockOutlined sx={{ fontSize:14, color:'#2563eb' }}/>
          <Typography sx={{ fontSize:11, color:'#1e40af' }}>Financial data is hidden. Contact admin to view revenue and invoice details.</Typography>
        </Box>
      )}

      {/* Search */}
      <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderTop:'none', borderBottom:'0.5px solid #e2e6ef', p:'8px 14px' }}>
        <input placeholder="Search LR number, route, truck, consignee..." style={{ width:'100%', padding:'5px 8px', border:'0.5px solid #e2e6ef', borderRadius:5, fontSize:12, outline:'none', background:'white', color:'inherit' }}/>
      </Box>

      {/* Table */}
      <Box sx={{ bgcolor:'#fff', border:'0.5px solid #e2e6ef', borderTop:'none', borderRadius:'0 0 8px 8px', overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#fafbfc' }}>
              {cols.map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:500, color:'#6b7a99', borderBottom:'0.5px solid #e2e6ef', whiteSpace:'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(t=>(
              <tr key={t.id} style={{ borderBottom:'0.5px solid #e2e6ef' }}
                onMouseEnter={e=>e.currentTarget.style.background='#f8f9fc'}
                onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                <td style={{ padding:'9px 12px' }}><b style={{fontSize:12}}>{t.lr_number||t.trip_number}</b></td>
                <td style={{ padding:'9px 12px', fontSize:12, color:'#6b7a99' }}>{new Date(t.trip_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.from_location}→{t.to_location}</td>
                <td style={{ padding:'9px 12px' }}><Badge label={t.trip_type} style={t.trip_type==='owned'?{bg:'#dbeafe',color:'#1e40af'}:{bg:'#fef3c7',color:'#92400e'}}/></td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.truck_number||t.broker_truck_number||'-'}</td>
                <td style={{ padding:'9px 12px', fontSize:12 }}>{t.consignee_name||'-'}</td>
                {showFreightInList && <>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(t.freight_amount)}{t.trip_type==='brokerage'&&<><br/><small style={{color:'#92400e',fontSize:10}}>Comm: {fmt(t.commission_amount)}</small></>}</td>
                  <td style={{ padding:'9px 12px', fontSize:12 }}>{fmt(t.advance_paid)}</td>
                  <td style={{ padding:'9px 12px', fontSize:12, color:+t.balance_due>0?'#d97706':'#16a34a' }}>{+t.balance_due>0?fmt(t.balance_due):'—'}</td>
                </>}
                <td style={{ padding:'9px 12px' }}><Badge label={t.status.replace('_',' ')} style={STATUS_STYLE[t.status]}/></td>
                <td style={{ padding:'9px 12px', whiteSpace:'nowrap' }}>
                  <button onClick={()=>openForm(t,t.trip_type)} style={{ marginRight:5, padding:'2px 8px', border:'0.5px solid #e2e6ef', borderRadius:4, fontSize:10, cursor:'pointer', background:'#fff', color:'inherit' }}>Edit</button>
                  {canDelete && <button onClick={()=>del(t.id)} style={{ padding:'2px 8px', border:'0.5px solid #fca5a5', borderRadius:4, fontSize:10, cursor:'pointer', background:'#fff', color:'#dc2626' }}>Del</button>}
                </td>
              </tr>
            ))}
            {!filtered.length&&<tr><td colSpan={cols.length} style={{ padding:'32px', textAlign:'center', color:'#6b7a99', fontSize:12 }}>No trips found</td></tr>}
          </tbody>
        </table>
      </Box>

      {/* DIALOG */}
      <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle sx={{ fontSize:15, fontWeight:500, pb:1, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          {editing?'Edit Trip':'Add New Trip'}
          {!editing && (
            <Box sx={{ display:'flex', gap:0.5 }}>
              <Button size="small" variant={activeTab==='owned'?'contained':'outlined'} onClick={()=>switchTab('owned')}
                sx={{ fontSize:12, bgcolor:activeTab==='owned'?'#1a2744':'transparent', borderColor:'#2563eb', color:activeTab==='owned'?'#fff':'#2563eb' }}>🚛 Owned</Button>
              {isAdmin && (
                <Button size="small" variant={activeTab==='brokerage'?'contained':'outlined'} onClick={()=>switchTab('brokerage')}
                  sx={{ fontSize:12, bgcolor:activeTab==='brokerage'?'#f59e0b':'transparent', borderColor:'#f59e0b', color:activeTab==='brokerage'?'#fff':'#92400e' }}>🤝 Brokerage</Button>
              )}
            </Box>
          )}
        </DialogTitle>
        <DialogContent sx={{ pt:1 }}>
          {activeTab==='brokerage' && <Alert severity="info" sx={{ mb:2, fontSize:12 }}><b>Brokerage:</b> You collect full freight, deduct your commission, transfer rest to owner. No expenses on your side.</Alert>}

          <Grid container spacing={2}>
            <Grid item xs={12} md={activeTab==='owned'?8:7}>

              {/* LR & Route */}
              <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderRadius:'6px', p:'12px', mb:1.5 }}>
                <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>LR & Route</Typography>
                <Grid container spacing={1.5}>
                  <Grid item xs={6}><TextField label="LR Number *" fullWidth value={form.lr_number} onChange={e=>f('lr_number',e.target.value)} onBlur={()=>blur('lr_number')} error={touched.lr_number&&!!errors.lr_number} helperText={touched.lr_number&&errors.lr_number} InputProps={{ endAdornment: lrLoading?<CircularProgress size={14}/>:null }} sx={{ '& .MuiOutlinedInput-root':{bgcolor:'rgba(37,99,235,0.04)'} }}/></Grid>
                  <Grid item xs={6}><TextField label="LR Date *" type="date" fullWidth value={form.trip_date} onChange={e=>f('trip_date',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
                  <Grid item xs={5}><TextField label="From *" fullWidth value={form.from_location} onChange={e=>f('from_location',e.target.value)} onBlur={()=>blur('from_location')} error={touched.from_location&&!!errors.from_location} helperText={touched.from_location&&errors.from_location}/></Grid>
                  <Grid item xs={5}><TextField label="To *" fullWidth value={form.to_location} onChange={e=>f('to_location',e.target.value)} onBlur={()=>blur('to_location')} error={touched.to_location&&!!errors.to_location} helperText={touched.to_location&&errors.to_location}/></Grid>
                  <Grid item xs={2}><TextField label="KM" type="number" fullWidth value={form.distance_km} onChange={e=>f('distance_km',e.target.value)}/></Grid>
                  <Grid item xs={4}><TextField label="Weight (tons)" type="number" fullWidth value={form.weight_tons} onChange={e=>f('weight_tons',e.target.value)}/></Grid>
                  <Grid item xs={8}><TextField select label="Consignee" fullWidth value={form.consignee_id} onChange={e=>f('consignee_id',e.target.value)}>
                    {consignees.length===0?<MenuItem disabled>Add consignees first</MenuItem>:consignees.map(c=><MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                  </TextField></Grid>
                </Grid>
              </Box>

              {/* Owned: truck + driver */}
              {activeTab==='owned' && (
                <Box sx={{ bgcolor:'#eff6ff', border:'0.5px solid #bfdbfe', borderRadius:'6px', p:'12px', mb:1.5 }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#1e40af', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>Vehicle & Driver</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}><TextField select label="Truck *" fullWidth value={form.truck_id} onChange={e=>f('truck_id',e.target.value)} onBlur={()=>blur('truck_id')} error={touched.truck_id&&!!errors.truck_id} helperText={touched.truck_id&&errors.truck_id}>
                      {trucks.length===0?<MenuItem disabled>Add trucks first</MenuItem>:trucks.map(t=><MenuItem key={t.id} value={t.id}>{t.truck_number}</MenuItem>)}
                    </TextField></Grid>
                    <Grid item xs={6}><TextField select label="Driver *" fullWidth value={form.driver_id} onChange={e=>f('driver_id',e.target.value)} onBlur={()=>blur('driver_id')} error={touched.driver_id&&!!errors.driver_id} helperText={touched.driver_id&&errors.driver_id}>
                      {drivers.length===0?<MenuItem disabled>Add drivers first</MenuItem>:drivers.map(d=><MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
                    </TextField></Grid>
                  </Grid>
                </Box>
              )}

              {/* Brokerage: owner details */}
              {activeTab==='brokerage' && (
                <Box sx={{ bgcolor:'#fffbeb', border:'0.5px solid #fcd34d', borderRadius:'6px', p:'12px', mb:1.5 }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#92400e', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>External owner details</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}><TextField label="Owner name *" fullWidth value={form.broker_owner_name} onChange={e=>f('broker_owner_name',e.target.value)} onBlur={()=>blur('broker_owner_name')} error={touched.broker_owner_name&&!!errors.broker_owner_name} helperText={touched.broker_owner_name&&errors.broker_owner_name}/></Grid>
                    <Grid item xs={6}><TextField label="Owner phone" fullWidth value={form.broker_owner_phone} onChange={e=>f('broker_owner_phone',e.target.value)}/></Grid>
                    <Grid item xs={6}><TextField label="Truck number *" fullWidth value={form.broker_truck_number} onChange={e=>f('broker_truck_number',e.target.value)} onBlur={()=>blur('broker_truck_number')} error={touched.broker_truck_number&&!!errors.broker_truck_number} helperText={touched.broker_truck_number&&errors.broker_truck_number}/></Grid>
                    <Grid item xs={6}><TextField label="Driver name" fullWidth value={form.broker_driver_name} onChange={e=>f('broker_driver_name',e.target.value)}/></Grid>
                  </Grid>
                </Box>
              )}

              {/* Freight — visible to admin+staff1 in form */}
              {showFreightInForm && (
                <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderRadius:'6px', p:'12px' }}>
                  <Typography sx={{ fontSize:10, fontWeight:600, color:'#6b7a99', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.2 }}>Freight & billing</Typography>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}><TextField label="Freight ₹ *" type="number" fullWidth value={form.freight_amount} onChange={e=>f('freight_amount',e.target.value)} onBlur={()=>blur('freight_amount')} error={touched.freight_amount&&!!errors.freight_amount} helperText={touched.freight_amount&&errors.freight_amount}/></Grid>
                    <Grid item xs={6}><TextField label="Advance received ₹" type="number" fullWidth value={form.advance_paid} onChange={e=>f('advance_paid',e.target.value)}/></Grid>
                    {activeTab==='owned' && <>
                      <Grid item xs={3}><TextField label="Detention ₹" type="number" fullWidth value={form.detention_charges} onChange={e=>f('detention_charges',e.target.value)}/></Grid>
                      <Grid item xs={3}><TextField label="Kata ₹" type="number" fullWidth value={form.kata_charges} onChange={e=>f('kata_charges',e.target.value)}/></Grid>
                      <Grid item xs={3}><TextField label="Loading ₹" type="number" fullWidth value={form.loading_charges} onChange={e=>f('loading_charges',e.target.value)}/></Grid>
                      <Grid item xs={3}><TextField label="Unloading ₹" type="number" fullWidth value={form.unloading_charges} onChange={e=>f('unloading_charges',e.target.value)}/></Grid>
                    </>}
                    {activeTab==='brokerage' && <>
                      <Grid item xs={4}><TextField label="Commission %" type="number" fullWidth value={form.commission_percent} onChange={e=>f('commission_percent',e.target.value)}/></Grid>
                      <Grid item xs={4}><TextField label="Advance to owner ₹" type="number" fullWidth value={form.broker_advance_paid} onChange={e=>f('broker_advance_paid',e.target.value)}/></Grid>
                      <Grid item xs={4}><TextField select label="Owner pay status" fullWidth value={form.broker_payment_status||'pending'} onChange={e=>f('broker_payment_status',e.target.value)}>
                        <MenuItem value="pending">Pending</MenuItem>
                        <MenuItem value="advance_paid">Advance paid</MenuItem>
                        <MenuItem value="settled">Settled</MenuItem>
                      </TextField></Grid>
                    </>}
                    <Grid item xs={4}><TextField select label="GST type" fullWidth value={form.gst_type} onChange={e=>f('gst_type',e.target.value)}>
                      <MenuItem value="exempt">Exempt</MenuItem>
                      <MenuItem value="cgst_sgst">CGST+SGST</MenuItem>
                      <MenuItem value="igst">IGST</MenuItem>
                    </TextField></Grid>
                    <Grid item xs={4}><TextField label="GST %" type="number" fullWidth value={form.gst_rate} onChange={e=>f('gst_rate',e.target.value)}/></Grid>
                    <Grid item xs={4}><TextField select label="Status" fullWidth value={form.status} onChange={e=>f('status',e.target.value)}>
                      {['planned','in_progress','completed','cancelled'].map(s=><MenuItem key={s} value={s}>{s.replace('_',' ')}</MenuItem>)}
                    </TextField></Grid>
                  </Grid>
                </Box>
              )}

              {/* Status only for staff1 — no freight shown */}
              {!showFreightInForm && (
                <Box sx={{ bgcolor:'#fafbfc', border:'0.5px solid #e2e6ef', borderRadius:'6px', p:'12px' }}>
                  <Grid container spacing={1.5}>
                    <Grid item xs={6}><TextField select label="Status" fullWidth value={form.status} onChange={e=>f('status',e.target.value)}>
                      {['planned','in_progress','completed','cancelled'].map(s=><MenuItem key={s} value={s}>{s.replace('_',' ')}</MenuItem>)}
                    </TextField></Grid>
                    <Grid item xs={6}><TextField label="Notes" fullWidth value={form.notes} onChange={e=>f('notes',e.target.value)}/></Grid>
                  </Grid>
                </Box>
              )}
            </Grid>

            {/* Calculator — only for admin and staff1 who can see freight */}
            {showFreightInForm && (
              <Grid item xs={12} md={activeTab==='owned'?4:5}>
                <Box sx={{ bgcolor:'#1a2744', borderRadius:'8px', p:'14px', color:'#fff' }}>
                  <Typography sx={{ fontSize:11, fontWeight:600, color:'rgba(255,255,255,0.6)', textTransform:'uppercase', letterSpacing:'0.06em', mb:1.5 }}>
                    {activeTab==='owned'?'Profit calculator':'Commission calculator'}
                  </Typography>
                  {activeTab==='owned' && (() => {
                    const c=owned();
                    return <>
                      {[['Freight',fmt(c.fr)],['Expenses',fmt(c.exp)],[`Driver extra (${form.distance_km||0}km×₹5)`,fmt(c.drv)]].map(([l,v])=>(
                        <Box key={l} sx={{ display:'flex', justifyContent:'space-between', py:'4px', fontSize:12 }}><span style={{color:'rgba(255,255,255,0.6)'}}>{l}</span><span>{v}</span></Box>
                      ))}
                      <Box sx={{ borderTop:'1px solid rgba(255,255,255,0.15)', mt:1, pt:1, display:'flex', justifyContent:'space-between', fontSize:14, fontWeight:600 }}>
                        <span>Net profit</span><span style={{color:c.net>=0?'#4ade80':'#f87171'}}>{fmt(c.net)}</span>
                      </Box>
                      <Box sx={{ display:'flex', justifyContent:'space-between', mt:0.5, fontSize:12 }}>
                        <span style={{color:'rgba(255,255,255,0.6)'}}>Balance due</span><span style={{color:'#fbbf24'}}>{fmt(c.due)}</span>
                      </Box>
                    </>;
                  })()}
                  {activeTab==='brokerage' && (() => {
                    const c=broker();
                    return <>
                      <Box sx={{ display:'flex', justifyContent:'space-between', py:'4px', fontSize:12 }}><span style={{color:'rgba(255,255,255,0.6)'}}>Freight collected</span><span>{fmt(c.fr)}</span></Box>
                      <Box sx={{ borderTop:'1px solid rgba(255,255,255,0.1)', my:0.8 }}/>
                      <Box sx={{ display:'flex', justifyContent:'space-between', py:'4px', fontSize:13, fontWeight:600 }}><span style={{color:'#4ade80'}}>Your commission ({c.p}%)</span><span style={{color:'#4ade80'}}>{fmt(c.comm)}</span></Box>
                      <Box sx={{ display:'flex', justifyContent:'space-between', py:'4px', fontSize:12 }}><span style={{color:'rgba(255,255,255,0.6)'}}>Pay to owner</span><span style={{color:'#93c5fd'}}>{fmt(c.ownerPay)}</span></Box>
                      <Box sx={{ bgcolor:'rgba(245,158,11,0.15)', border:'1px solid rgba(245,158,11,0.3)', borderRadius:'5px', p:'8px', my:1, fontSize:11, color:'#fbbf24' }}>No diesel/toll/expenses on your side</Box>
                      <Box sx={{ borderTop:'1px solid rgba(255,255,255,0.15)', pt:1 }}>
                        <Box sx={{ display:'flex', justifyContent:'space-between', fontSize:12, mb:0.5 }}><span style={{color:'rgba(255,255,255,0.6)'}}>Balance due from consignee</span><span style={{color:'#fbbf24'}}>{fmt(c.due)}</span></Box>
                        <Box sx={{ display:'flex', justifyContent:'space-between', fontSize:12 }}><span style={{color:'rgba(255,255,255,0.6)'}}>Still owe to owner</span><span style={{color:c.ownerRem>0?'#f87171':'#4ade80'}}>{fmt(Math.max(0,c.ownerRem))}</span></Box>
                      </Box>
                    </>;
                  })()}
                  {!editing && +form.freight_amount>0 && (
                    <Box sx={{ mt:1.5, p:'8px', bgcolor:'rgba(255,255,255,0.08)', borderRadius:'5px', fontSize:11, color:'rgba(255,255,255,0.7)' }}>
                      Invoice will auto-generate on save
                    </Box>
                  )}
                </Box>
              </Grid>
            )}
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px:3, pb:2.5, gap:1 }}>
          <Button onClick={()=>setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
          <Button variant="contained" onClick={save} sx={{ bgcolor:'#1a2744', px:3 }}>
            {editing?'Update trip':'Save trip'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
