import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Grid, LinearProgress, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem } from '@mui/material';
import { Add, Edit } from '@mui/icons-material';
import api from '../utils/api';
import { useToast } from '../components/Toast';
import usePermissions from '../hooks/usePermissions';

const docChip = date => {
  if (!date) return <span style={{fontSize:10,color:'#6b7a99'}}>N/A</span>;
  const days = Math.ceil((new Date(date)-new Date())/86400000);
  if (days<0)   return <span style={{display:'inline-block',padding:'2px 6px',borderRadius:20,fontSize:10,fontWeight:500,background:'#fee2e2',color:'#991b1b'}}>Expired</span>;
  if (days<=30) return <span style={{display:'inline-block',padding:'2px 6px',borderRadius:20,fontSize:10,fontWeight:500,background:'#fef9c3',color:'#854d0e'}}>{days}d</span>;
  return <span style={{display:'inline-block',padding:'2px 6px',borderRadius:20,fontSize:10,fontWeight:500,background:'#dcfce7',color:'#166534'}}>Valid</span>;
};

export default function Fleet() {
  const [trucks, setTrucks]   = useState([]);
  const [open, setOpen]       = useState(false);
  const [form, setForm]       = useState({});
  const [editing, setEditing] = useState(null);
  const showToast = useToast();
  const { can, isAdmin } = usePermissions();

  const showLoan = can('show_loan_emi'); // admin only

  const load = () => api.get('/trucks').then(r => setTrucks(r.data));
  useEffect(() => { load(); }, []);

  const openForm = (t=null) => {
    setEditing(t?.id||null);
    setForm(t||{ truck_number:'', truck_type:'', wheel_count:'10', make:'', model:'', year:new Date().getFullYear(), loan_amount:0, loan_emi:0, loan_tenure_months:0, loan_paid_emis:0 });
    setOpen(true);
  };

  const save = async () => {
    if (!form.truck_number) { showToast('Truck number is required','error'); return; }
    try {
      editing ? await api.put(`/trucks/${editing}`,form) : await api.post('/trucks',form);
      setOpen(false); load();
      showToast(editing?'Truck updated':'Truck added','success');
    } catch { showToast('Failed to save','error'); }
  };

  const f=(k,v)=>setForm(p=>({...p,[k]:v}));

  return (
    <Box>
      <Box sx={{ display:'flex', justifyContent:'space-between', alignItems:'center', mb:2 }}>
        <Box>
          <Typography sx={{ fontSize:13, fontWeight:500 }}>Fleet management</Typography>
          <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{trucks.length} trucks registered</Typography>
        </Box>
        {isAdmin && (
          <Button variant="contained" size="small" startIcon={<Add/>} onClick={()=>openForm()} sx={{ bgcolor:'#1a2744', fontSize:12 }}>Add truck</Button>
        )}
      </Box>

      <Grid container spacing={1.5}>
        {trucks.map(t => {
          const pct = t.loan_tenure_months ? Math.min(100,((t.loan_paid_emis||0)/t.loan_tenure_months)*100) : 100;
          const cleared = t.loan_tenure_months===0 || pct>=100;
          return (
            <Grid item xs={12} md={6} lg={4} key={t.id}>
              <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'14px' }}>
                <Box sx={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', mb:1 }}>
                  <Box>
                    <Typography sx={{ fontSize:14, fontWeight:600 }}>{t.truck_number}</Typography>
                    <Typography sx={{ fontSize:11, color:'#6b7a99' }}>{t.make} {t.model} — {t.year} · {t.wheel_count}W</Typography>
                  </Box>
                  <Box sx={{ display:'flex', alignItems:'center', gap:1 }}>
                    <span style={{display:'inline-block',padding:'2px 8px',borderRadius:20,fontSize:11,fontWeight:500,background:'#dcfce7',color:'#166534'}}>Active</span>
                    {isAdmin && <button onClick={()=>openForm(t)} style={{border:'0.5px solid #e2e6ef',borderRadius:4,padding:'2px 7px',fontSize:10,cursor:'pointer',background:'#fff',color:'inherit'}}>Edit</button>}
                  </Box>
                </Box>

                {/* Loan EMI — admin only */}
                {showLoan && (
                  <Box sx={{ mb:1.5 }}>
                    <Box sx={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'#6b7a99', mb:0.5 }}>
                      <span>Loan EMI</span>
                      <span style={{color:cleared?'#16a34a':'inherit'}}>
                        {cleared ? 'Cleared ✓' : `₹${(t.loan_emi||0).toLocaleString('en-IN')}/mo · ${(t.loan_tenure_months||0)-(t.loan_paid_emis||0)} left`}
                      </span>
                    </Box>
                    <LinearProgress variant="determinate" value={pct} sx={{ height:5, borderRadius:3, bgcolor:'#e2e8f0', '& .MuiLinearProgress-bar':{ bgcolor: cleared?'#16a34a':'#2563eb' } }}/>
                  </Box>
                )}

                {/* For non-admin: just show truck type badge instead of loan */}
                {!showLoan && (
                  <Box sx={{ mb:1.5 }}>
                    <span style={{display:'inline-block',padding:'2px 8px',borderRadius:4,fontSize:11,background:'#f1f5f9',color:'#475569'}}>{t.truck_type||`${t.wheel_count}-Wheeler`}</span>
                  </Box>
                )}

                {/* Documents — all roles */}
                <Box sx={{ display:'flex', gap:'6px', flexWrap:'wrap' }}>
                  {[['RC',t.rc_expiry],['PUC',t.puc_expiry],['Fitness',t.fitness_expiry],['Ins.',t.insurance_expiry],['Permit',t.permit_expiry]].map(([l,d])=>(
                    <Box key={l} sx={{ display:'flex', alignItems:'center', gap:'3px' }}>
                      <span style={{fontSize:10,color:'#6b7a99'}}>{l}</span>{docChip(d)}
                    </Box>
                  ))}
                </Box>
              </Box>
            </Grid>
          );
        })}
        {!trucks.length && (
          <Grid item xs={12}>
            <Box sx={{ bgcolor:'#fff', borderRadius:'8px', border:'0.5px solid #e2e6ef', p:'32px', textAlign:'center', color:'#6b7a99', fontSize:13 }}>
              No trucks added yet.{isAdmin?' Click "+ Add truck" to get started.':''}
            </Box>
          </Grid>
        )}
      </Grid>

      {/* Add/Edit dialog — admin only */}
      {isAdmin && (
        <Dialog open={open} onClose={()=>setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle sx={{ fontSize:15, fontWeight:500 }}>{editing?'Edit Truck':'Add Truck'}</DialogTitle>
          <DialogContent>
            <Grid container spacing={1.5} sx={{ mt:0.5 }}>
              <Grid item xs={6}><TextField label="Truck Number *" fullWidth value={form.truck_number||''} onChange={e=>f('truck_number',e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="Type" fullWidth value={form.truck_type||''} onChange={e=>f('truck_type',e.target.value)} placeholder="14-Wheeler Heavy"/></Grid>
              <Grid item xs={4}><TextField select label="Wheels" fullWidth value={form.wheel_count||'10'} onChange={e=>f('wheel_count',e.target.value)}>
                {['4','6','10','14'].map(w=><MenuItem key={w} value={w}>{w} Wheel</MenuItem>)}
              </TextField></Grid>
              <Grid item xs={4}><TextField label="Make" fullWidth value={form.make||''} onChange={e=>f('make',e.target.value)}/></Grid>
              <Grid item xs={4}><TextField label="Year" type="number" fullWidth value={form.year||''} onChange={e=>f('year',e.target.value)}/></Grid>
              <Grid item xs={4}><TextField label="RC Expiry" type="date" fullWidth value={form.rc_expiry||''} onChange={e=>f('rc_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
              <Grid item xs={4}><TextField label="PUC Expiry" type="date" fullWidth value={form.puc_expiry||''} onChange={e=>f('puc_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
              <Grid item xs={4}><TextField label="Fitness Expiry" type="date" fullWidth value={form.fitness_expiry||''} onChange={e=>f('fitness_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
              <Grid item xs={4}><TextField label="Insurance Expiry" type="date" fullWidth value={form.insurance_expiry||''} onChange={e=>f('insurance_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
              <Grid item xs={4}><TextField label="Permit Expiry" type="date" fullWidth value={form.permit_expiry||''} onChange={e=>f('permit_expiry',e.target.value)} InputLabelProps={{shrink:true}}/></Grid>
              <Grid item xs={12}><Typography sx={{ fontSize:11, fontWeight:500, color:'#6b7a99', textTransform:'uppercase', mt:0.5 }}>Loan Details (admin only)</Typography></Grid>
              <Grid item xs={6}><TextField label="Loan Amount ₹" type="number" fullWidth value={form.loan_amount||''} onChange={e=>f('loan_amount',e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="EMI ₹/month" type="number" fullWidth value={form.loan_emi||''} onChange={e=>f('loan_emi',e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="Tenure (months)" type="number" fullWidth value={form.loan_tenure_months||''} onChange={e=>f('loan_tenure_months',e.target.value)}/></Grid>
              <Grid item xs={6}><TextField label="EMIs Paid" type="number" fullWidth value={form.loan_paid_emis||''} onChange={e=>f('loan_paid_emis',e.target.value)}/></Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ px:3, pb:2 }}>
            <Button onClick={()=>setOpen(false)} sx={{ color:'#6b7a99' }}>Cancel</Button>
            <Button variant="contained" onClick={save} sx={{ bgcolor:'#1a2744' }}>Save</Button>
          </DialogActions>
        </Dialog>
      )}
    </Box>
  );
}
