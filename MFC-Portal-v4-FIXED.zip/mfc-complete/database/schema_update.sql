-- ============================================================
-- MFC Portal — Schema updates
-- Run this AFTER the main schema.sql
-- ============================================================

USE mfc_db;

-- Owner payments table (for brokerage ledger)
CREATE TABLE IF NOT EXISTS owner_payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_id INT NOT NULL,
  owner_name VARCHAR(255) NOT NULL,
  owner_phone VARCHAR(20),
  truck_number VARCHAR(50),
  freight_amount DECIMAL(10,2) DEFAULT 0,
  commission_amount DECIMAL(10,2) DEFAULT 0,
  payable_amount DECIMAL(10,2) DEFAULT 0,
  advance_paid DECIMAL(10,2) DEFAULT 0,
  balance_due DECIMAL(10,2) DEFAULT 0,
  status ENUM('pending','advance_paid','settled') DEFAULT 'pending',
  notes TEXT,
  settled_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE
);

-- Add aadhaar fields to drivers (if not already present)
ALTER TABLE drivers
  ADD COLUMN IF NOT EXISTS aadhaar_number VARCHAR(12) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS aadhaar_status ENUM('verified','pending','not_verified') DEFAULT 'not_verified',
  ADD COLUMN IF NOT EXISTS aadhaar_copy_uploaded BOOLEAN DEFAULT FALSE;

-- Truck summary view (revenue + maintenance per truck)
CREATE OR REPLACE VIEW truck_summary AS
SELECT
  t.id,
  t.truck_number,
  t.truck_type,
  t.make,
  t.model,
  t.year,
  t.wheel_count,
  -- Revenue from trips
  COALESCE((SELECT SUM(freight_amount) FROM trips WHERE truck_id=t.id AND status='completed'), 0) AS total_revenue,
  COALESCE((SELECT COUNT(*) FROM trips WHERE truck_id=t.id), 0) AS total_trips,
  COALESCE((SELECT SUM(distance_km) FROM trips WHERE truck_id=t.id), 0) AS total_km,
  -- Maintenance costs
  COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='servicing'), 0) AS servicing_cost,
  COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='fuel'), 0) AS fuel_cost,
  COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id AND log_type='repair'), 0) AS repair_cost,
  COALESCE((SELECT SUM(cost) FROM tyre_logs WHERE truck_id=t.id AND event_type='new_fit'), 0) AS tyre_cost,
  COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id), 0) AS total_maintenance_cost,
  -- Net contribution
  COALESCE((SELECT SUM(freight_amount) FROM trips WHERE truck_id=t.id AND status='completed'), 0) -
  COALESCE((SELECT SUM(cost) FROM maintenance_logs WHERE truck_id=t.id), 0) AS net_contribution
FROM trucks t
WHERE t.is_active = 1;

-- Driver trip count view
CREATE OR REPLACE VIEW driver_monthly_trips AS
SELECT
  d.id AS driver_id,
  d.name AS driver_name,
  COUNT(t.id) AS trips_this_month,
  COALESCE(SUM(t.freight_amount), 0) AS revenue_this_month
FROM drivers d
LEFT JOIN trips t ON t.driver_id = d.id
  AND MONTH(t.trip_date) = MONTH(CURDATE())
  AND YEAR(t.trip_date) = YEAR(CURDATE())
  AND t.status != 'cancelled'
WHERE d.is_active = 1
GROUP BY d.id, d.name;
