-- ============================================================
-- MFC Portal — Role update migration
-- Run this after schema.sql + schema_update.sql
-- ============================================================

USE mfc_db;

-- Update users table to support 3 roles
ALTER TABLE users
  MODIFY COLUMN role ENUM('admin', 'staff1', 'staff2') DEFAULT 'staff1';

-- Add display_name for role clarity
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS display_name VARCHAR(100) DEFAULT NULL;

-- Seed staff users (passwords are 'staff123' hashed with bcrypt)
-- Admin: admin@mfc.com / admin123 (already exists)

-- Staff 1 — Operations (trips, drivers, consignees)
INSERT INTO users (name, email, password_hash, role, display_name) VALUES
('Rahul Sharma', 'staff1@mfc.com',
 '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhu.',
 'staff1', 'Operations Staff')
ON DUPLICATE KEY UPDATE role='staff1';

-- Staff 2 — Fleet & Maintenance
INSERT INTO users (name, email, password_hash, role, display_name) VALUES
('Vijay Patil', 'staff2@mfc.com',
 '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhu.',
 'staff2', 'Fleet & Maintenance Staff')
ON DUPLICATE KEY UPDATE role='staff2';

-- ============================================================
-- Default credentials:
-- Admin:   admin@mfc.com  / admin123
-- Staff 1: staff1@mfc.com / staff123
-- Staff 2: staff2@mfc.com / staff123
-- ============================================================
